import requests
import pytest
from .config import Log
from .api_e2e.api_library.login import LoginPage


@pytest.fixture(scope="session")
def basic_auth():
    Log.info("Fetching access Token")
    _, access_token = LoginPage().login()
    yield access_token
