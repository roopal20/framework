import os
import json
import random
import string
import time
from datetime import timedelta, datetime
from uuid import uuid4


import xlsxwriter

from ...config import (SESSION, true_value, course_type_list, new_session_endpoint, course_session_key,
                       create_event_endpoint, count_session_endpoint, get_venues_endpoint, venues_names,
                       course_id_key, course_type_key, get_course_id_wm_endpoint, update_event_endpoint, event_types,
                       sync_user_endpoint, create_user_endpoint, delete_user_endpoint, get_course_of_id_sync_lp,
                       count_session_endpoint_sync_user, program_id_sync_users, sync_user_failed_program_id,
                       sync_user_failed_course_id, webinar_management_endpoint, count_session_endpoint_sync_user_failed,
                       sync_user_failed_endpoint, get_course_of_id_sync_lp_failed_endpoint, pass_value, client_value,
                       sync_user_enrollment, get_course_of_id_sync_lp_enrollment,
                       count_session_endpoint_sync_user_enrollment, event_name_text, manage_users_file_url)

from ...resources.ops_portal_base_page import OpsPortalBase, ADMIN_BASE_URL
from ...resources.utils import build_request_headers
from ...api_e2e.api_library.user_management import UserManagement


class WorkshopManagement(OpsPortalBase):

    def __init__(self):
        super().__init__()
        self.user_management = UserManagement()

    def create_new_session(self, session_type, access_token):
        course_id_response = self.get_course_id(get_course_id_wm_endpoint, course_type_list[0], access_token)
        if len(course_id_response) == 0:
            raise Exception("There is no ILT course in your using LP!")
        payload = self.get_payload_for_session(session_type, session_name='', session_des='', number_of_events=0)
        url = f"{new_session_endpoint}{course_id_response[0]}/session"
        response = self._post(url, payload, cookie='', token=access_token)
        return response, payload

    def get_payload_for_session(self, session_type, session_name="", session_des="", number_of_events=0):
        if session_name == "":
            session_name = self.random_word(7)
        if session_type == "Manual":
            payload = {"session_name": session_name,
                       "session_description": session_des,
                       "enrolled_users_count": "",
                       "max_enrollments": 1000000000,
                       "instructors": [],
                       "session_completion": 3
                       }
        else:
            payload = {"session_name": session_name,
                       "session_description": session_des,
                       "enrolled_users_count": "",
                       "max_enrollments": 1000000000,
                       "instructors": [], "session_completion": 2,
                       "number_of_events": number_of_events}
        return payload

    @staticmethod
    def update_session(endpoint, access_token, session_name, session_description='', enrolled_users_count=''):

        payload = {"session_name": session_name,
                   "session_description": session_description,
                   "enrolled_users_count": enrolled_users_count,
                   "max_enrollments": 1000000000,
                   "instructors": [],
                   "session_completion": 3
                   }
        request_header = build_request_headers(access_token)
        response = SESSION.put(endpoint, json=payload, headers=request_header)
        return response, payload

    @staticmethod
    def delete_session(endpoint, access_token):
        request_headers = build_request_headers(access_token)
        response = SESSION.delete(endpoint, headers=request_headers)
        return response

    def create_session_with_empty_payload(self, access_token):
        course_id_response = self.get_course_id(get_course_id_wm_endpoint, course_type_list[0], access_token)
        if len(course_id_response) == 0:
            raise Exception("There is no ILT course in your using LP!")
        payload = {"Session_names": "testing"}
        url = f"{new_session_endpoint}{course_id_response[0]}/session"
        response = self._post(url, {}, cookie='', token=access_token)
        return response, payload

    def get_course_id(self, app_url, type_of_course, access_token):
        response = self._get(app_url, access_token)
        response_body = self.get_content(response)
        return self.get_list_of_json_key(response_body["courses"], course_id_key, course_type_key, type_of_course)

    def get_count_of_session(self, course_id_url, session_url, access_token):
        course_id_response = self.get_course_id(course_id_url, course_type_list[0], access_token)
        response = self._get(f"{session_url}{course_id_response[0]}", access_token)
        response_body = self.get_content(response)
        return response_body[course_session_key]

    def get_value_of_session_id(self, app_url, access_token):
        course_id_response = self.get_course_id(get_course_id_wm_endpoint, course_type_list[0], access_token)
        response = self.get_response_of_sessions(f"{app_url}{course_id_response[0]}", access_token)
        response_body = self.get_content(response)
        return response_body[course_session_key]

    def create_event(self, access_token, event_type, list_of_session):
        if len(list_of_session) == 0:
            raise Exception("There is no session in ILT course")
        location_id = self.get_location_id(access_token, venues_names[0])  # update method
        url = f"{create_event_endpoint}{list_of_session[0]['id']}/event"
        payload = self.get_payload_for_event(event_type, event_name='', location_id=location_id[0])
        response = self._post(url, payload, cookie='', token=access_token)
        return response, payload

    def update_event(self, updated_event_name, location_name, event_type, access_token):
        before_add_event = self.get_count_of_session(get_course_id_wm_endpoint, count_session_endpoint, access_token)
        if len(before_add_event) == 0:
            raise Exception("There is no session in ILT course")

        response, event_payload = self.create_event(access_token, event_types[0], before_add_event)
        response_body = self.get_content(response)
        location_id = self.get_location_id(access_token, location_name)
        update_url = f'{update_event_endpoint}{response_body["data"]["event_id"]}'
        payload = self.get_payload_for_event(event_type, event_name=updated_event_name, location_id=location_id[0])
        requests_headers = build_request_headers(access_token)
        update_response = SESSION.put(update_url, json=payload, headers=requests_headers)
        return update_response, payload

    def create_event_with_character_limit(self, access_token, event_type, list_of_session):
        if len(list_of_session) == 0:
            raise Exception("There is no session in ILT course")
        location_id = self.get_location_id(access_token, venues_names[0])  # update method
        url = f"{create_event_endpoint}{list_of_session[0]['id']}/event"
        payload = self.get_payload_for_event(event_type, event_name=event_name_text, location_id=location_id[0])
        response = self._post(url, payload, cookie='', token=access_token)
        return response, payload

    def get_payload_for_event(self, event_type, event_name='', location_id=0):
        if event_name == '':
            event_name = self.random_word(8)
        if event_type == "Video":
            payload = {"event_name": event_name, "event_start_date": f'{self.set_current_date()}',
                       "event_start_time": self.set_start_time(), "event_end_time": self.set_endTime(),
                       "timezone": "Asia/Aqtau",
                       "video_conference": True, "custom_url": "https://admin-qa.mckinseyaccelerate.com/",
                       "allow_join_completion": True, "allow_recording_completion": True,
                       "participants_advance_join_time": None, "instructors_advance_join_time": None}
        else:
            payload = {"event_name": event_name, "event_start_date": f'{self.set_current_date()}',
                       "event_start_time": self.set_start_time(), "event_end_time": self.set_endTime(),
                       "timezone": "Asia/Aqtau", "video_conference": False, "location_id": location_id}
        return payload

    def get_location_id(self, access_token, venue_names):
        response = self._get(get_venues_endpoint, access_token)
        response_body = self.get_content(response)
        return self.get_list_of_json_key(response_body['users'], "id", "name", venue_names)

    @staticmethod
    def get_response_of_sessions(app_url, access_token):
        requests_header = build_request_headers(access_token)
        response = SESSION.get(app_url, headers=requests_header)
        return response

    @staticmethod
    def get_response_of_url(endpoint, access_token):
        requests_header = build_request_headers(access_token)
        response = SESSION.get(endpoint, headers=requests_header)
        return response

    @staticmethod
    def get_instructors(app_url, access_token):
        requests_headers = build_request_headers(access_token)
        response = SESSION.get(app_url, headers=requests_headers)
        return response

    @staticmethod
    def verify_session_have_empty(value_of_sessions):
        return value_of_sessions == 0

    @staticmethod
    def set_endTime():
        current_time = datetime.now()
        result = current_time + timedelta(minutes=25)
        return result.time().strftime('%H:%M:%S')

    @staticmethod
    def set_start_time():
        current_time = datetime.now()
        return current_time.time().strftime('%H:%M:%S')

    @staticmethod
    def set_current_date():
        current_date = datetime.now()
        return current_date.date()

    @staticmethod
    def validate_updated_count(before_add_session, after_add_session):
        return len(before_add_session) < len(after_add_session)

    @staticmethod
    def random_word(length):
        letters = string.ascii_lowercase
        return "".join(random.choice(letters) for i in range(length))

    @staticmethod
    def validate_session_id_and_value_is_int(response_body, session_key):
        items_values = response_body.values()
        values = list(items_values)
        data_values = values[1]
        session_id = list(data_values.keys())
        session_id_value = data_values.get(session_id[0])
        if session_key == session_id[0] and true_value == isinstance(session_id_value, int):
            return true_value

    @staticmethod
    def delete_event(delete_endpoint, access_token):
        requests_headers = build_request_headers(access_token)
        response = SESSION.delete(delete_endpoint, headers=requests_headers)
        return response

    def compare_payload(self, given_payload, response):
        given_values = given_payload.values()
        response_values = response.values()
        for item in given_values:
            return self.verify_value_exist_in_a_list(item, response_values)

    def create_manage_workshop_users_file(self):
        number_of_user = 3
        start = 1
        end = start + number_of_user
        first_name = 'ws_'
        last_name = 'user'
        random_val = uuid4().hex[0:3]
        upload_file_name = 'manage_workshop.xlsx'
        student_file = os.path.abspath(os.path.join(os.curdir, upload_file_name))
        workbook = xlsxwriter.Workbook(student_file)
        worksheet = workbook.add_worksheet('manage workshop')
        worksheet.write('A1', 'Username')

        for val in range(end):
            if val % 2 == 0:
                email = f'{first_name}{last_name}{val + 1}{random_val}@mailinator.com'
                worksheet.write(val + 1, 0, email)
            else:
                email = f'{first_name}{last_name}{val + 1}{random_val}@mailinator.com'
                worksheet.write(val + 1, 0, email)

        workbook.close()

    def validate_manage_users_file(self, token):

        files = {('file', open('manage_workshop.xlsx', 'rb'))}
        request_headers = build_request_headers(token)
        response = self.session.post(manage_users_file_url, files=files, headers=request_headers)
        print(response.text)

    def upload_manage_users_file(self, token):

        self.create_manage_workshop_users_file()
        self.validate_manage_users_file(token)

        files = {('file', open('manage_workshop.xlsx', 'rb'))}

        params = {
            'program_id': sync_user_failed_program_id,
            'course_id': sync_user_failed_course_id
        }
        request_headers = build_request_headers(token)
        response_put_request = self.session.put(webinar_management_endpoint, data=params, headers=request_headers,
                                                files=files)
        resp = json.loads(response_put_request.text)
        t_id = resp['transaction_id']
        self.user_management.user_uploading_got_completed(t_id, token)
        url = f'{ADMIN_BASE_URL}api/report/xlsx/{t_id}'
        response = self._get(url, token=token)
        with open('download_WS.xlsx', 'wb') as out_file:
            out_file.write(response.content)

        return response

    def get_response_of_sync_user(self, access_token, retry_hit):
        for x in range(retry_hit):
            time.sleep(15)
            response = self.hit_sync_user_api(access_token)
            if response.text != 'null\n':
                break
        return response

    def hit_sync_user_api(self, access_token):
        session_id = self.get_count_of_session(get_course_of_id_sync_lp, count_session_endpoint_sync_user, access_token)
        payload = {
            "session_ids": [session_id[0]['id']]
        }
        response = self._post(sync_user_endpoint, payload, cookie='', token=access_token)
        return response

    def create_test_user(self, access_token):
        payload = {"primary_experience": "Landing Page 0",
                   "user_id_start": 1,
                   "users_count": 5,
                   "is_default_experience": False,
                   "branch_id": "Default",
                   "learning_plans": []}
        response = self._post(create_user_endpoint, payload, cookie='', token=access_token)
        return response

    @staticmethod
    def delete_test_user(transaction_id, list_of_users, access_token):
        payload = {
            "users": list_of_users
        }
        requests_header = build_request_headers(access_token)
        delete_url = f'{delete_user_endpoint}{transaction_id}/delete'
        response = SESSION.put(delete_url, json=payload, headers=requests_header)
        return response

    def hit_sync_user_failed_api(self, access_token):
        session_id = self.get_count_of_session(get_course_of_id_sync_lp_failed_endpoint,
                                               count_session_endpoint_sync_user_failed, access_token)
        payload = {
            "session_ids": [session_id[0]['id']]
        }
        response = self._post(sync_user_failed_endpoint, payload, cookie='', token=access_token)
        return response

    def upload_participants_file(self, access_token, p_id, email=None, client_name=client_value,
                                 single_client=True, password=pass_value, number_of_user=3, sheet_name='manage users',
                                 group_work=''):
        self.user_management.create_participants_file(
            email, client_name=client_name, password=password, number_of_user=number_of_user,
            sheet_name=sheet_name, single_client=single_client, group_work=group_work
        )

        post_url = f'{ADMIN_BASE_URL}api/v2/automation/course_ops/auto_enrollment'
        params = {
            'program_id': p_id,
            'is_single_client_program': single_client
        }
        files = {'file': open('users_enrollment.xlsx', 'rb').read()}
        return self.session.post(post_url, files=files, headers=self._get_headers(access_token), data=params)

    def hit_sync_user_enrollment_check_api(self, access_token):
        session_id = self.get_count_of_session(get_course_of_id_sync_lp_enrollment,
                                               count_session_endpoint_sync_user_enrollment, access_token)
        payload = {
            "session_ids": [session_id[0]['id']]
        }
        response = self._post(sync_user_enrollment, payload, cookie='', token=access_token)
        return response
