import logging
import random
import re
import string
import time
import xlsxwriter
from openpyxl import Workbook, load_workbook
import uuid
from datetime import datetime
from ...resources import PROGRAM_ID_NO
from ...resources.ops_portal_base_page import *


class UserManagement(OpsPortalBase):

    def create_participants_file(self, email, password, client_name, number_of_user, sheet_name, single_client, group_work):
        start = 1
        end = start + number_of_user
        first_name = 'ntst_'
        last_name = 'user'
        random_val = uuid.uuid4().hex[0:6]
        upload_file_name = 'users_enrollment.xlsx'
        student_file = os.path.abspath(os.path.join(os.curdir, upload_file_name))
        workbook = xlsxwriter.Workbook(student_file)
        worksheet = workbook.add_worksheet(sheet_name)
        worksheet.write('A1', 'username')
        worksheet.write('B1', 'Firstname')
        worksheet.write('C1', 'Lastname')
        worksheet.write('D1', 'Email')
        worksheet.write('E1', 'Password')
        worksheet.write('F1', 'force password change')
        worksheet.write('G1', 'client name')
        worksheet.write('H1', 'client id')
        worksheet.write('I1', 'Groupwork')
        worksheet.write('J1', 'primary experience')
        worksheet.write('K1', 'language')
        worksheet.write('L1', 'Role')
        worksheet.write('M1', 'custom field 1')
        worksheet.write('N1', 'custom field 2')
        worksheet.write('O1', 'custom field 3')
        worksheet.write('P1', 'custom field 4')
        for val in range(end):
            if email:
                email_value = email
            else:
                email_value = f'{first_name}{last_name}{val + 1}{random_val}@mailinator.com'
            worksheet.write(val + 1, 0, email_value)
            worksheet.write(val + 1, 1, first_name)
            worksheet.write(val + 1, 2, f'{last_name}{val + 1}{random_val}')
            worksheet.write(val + 1, 3, email_value)
            worksheet.write(val + 1, 4, password)
            worksheet.write(val + 1, 5, 'No')
            if single_client:
                worksheet.write(val + 1, 6, client_name)
                worksheet.write(val + 1, 7, "R10_Arbisoft_Rls10")
                if 'Test_Automation_Assignment' in group_work:
                    if val % 2 == 0:
                        worksheet.write(val + 1, 8, f'Group 01 - {group_work}')
                    else:
                        worksheet.write(val + 1, 8, f'Group 02 - {group_work}')
                else:
                    worksheet.write(val + 1, 8, '')
            else:
                if val % 2 == 0:
                    worksheet.write(val + 1, 6, client_name)
                    worksheet.write(val + 1, 7, "R10_Arbisoft_Rls10")
                    worksheet.write(val + 1, 8, '')
                else:
                    worksheet.write(val + 1, 6, 'Arbisoft')
                    worksheet.write(val + 1, 7, 'Release10_Arbisoft')
                    worksheet.write(val + 1, 8, '')

            worksheet.write(val + 1, 9, 'Landing Page 3')
            worksheet.write(val + 1, 10, '')
            worksheet.write(val + 1, 11, random.choices(["Observer", "Participant"])[0])
            worksheet.write(val + 1, 12, '')
            worksheet.write(val + 1, 13, '')
            worksheet.write(val + 1, 14, '')
            worksheet.write(val + 1, 15, '')

        workbook.close()

    def create_groups(self, token, prog_id, num_of_groups=5):
        url = f'{ADMIN_BASE_URL}api/automation/course_ops/groupwork_groups'
        params = {
            "program_id": int(prog_id),
            "assignment_name": f"submit::{self._get_random_strings()}[GW]",
            "starting_group_number": 1,
            "num_of_groups": num_of_groups
        }
        return self.session.post(url=url, json=params, headers=self._get_headers(token))

    def upload_participants_file(
            self, token, p_id=program_id, email=None, client_name=client_value,
            single_client=True, password=pass_value, number_of_user=2, sheet_name='manage users', group_work=''
    ):
        self.create_participants_file(
            email, client_name=client_name, password=password, number_of_user=number_of_user,
            sheet_name=sheet_name, single_client=single_client, group_work=group_work
        )
        if p_id:
            post_url = f'{ADMIN_BASE_URL}api/dat/validate/course_ops/auto_enrollment?program_id={p_id}'
        else:
            post_url = f'{ADMIN_BASE_URL}api/v2/automation/course_ops/auto_enrollment'
        params = {
            'program_id': program_id,
            'is_single_client_program': single_client,
            'wave_id': program_wave_id
        }
        files = {'file': open('users_enrollment.xlsx', 'rb').read()}
        time.sleep(2)
        return self.session.post(post_url, files=files, headers=self._get_headers(token), data=params)

    def validate_upload_unenroll_file(self, token, sheet_name, users, upload=False):
        self.create_un_enrollment_file(sheet_name, users)
        post_url = f'{ADMIN_BASE_URL}api/dat/validate/course_ops/bulk_unenrollment'
        if upload:
            post_url = f'{ADMIN_BASE_URL}api/automation/course_ops/bulk_unenrollment'
        params = {
            'program_id': program_id
        }
        files = {('file', open('unenroll_users.xlsx', 'rb'))}
        return self.session.post(post_url, files=files, headers=self._get_headers(token), data=params)

    def read_an_existing_file(self):
        un_enrollment_file = 'users_enrollment.xlsx'
        wb = load_workbook(filename=un_enrollment_file)
        sheet_ranges = wb['manage users']
        un_enrollment_ws = Workbook()
        un_enrollment_ws1 = un_enrollment_ws.active
        count = 0
        return sheet_ranges, un_enrollment_ws, un_enrollment_ws1, count

    def create_un_enrollment_file(self, sheet_name, users):
        sheet_ranges, un_enrollment_ws, un_enrollment_ws1, count = self.read_an_existing_file()
        if sheet_name == 'bulk unenroll' and users != "":
            un_enrollment_ws1.title = sheet_name
            for cell in sheet_ranges['A']:
                un_enrollment_ws1.cell(count + 1, 1, cell.value)
                count = count + 1
        elif sheet_name == 'bulk unenroll' and users == '':
            un_enrollment_ws1.title = sheet_name
            un_enrollment_ws1.cell(1, 1, 'username')
        else:
            un_enrollment_ws1.title = sheet_name
            for cell in sheet_ranges['A']:
                un_enrollment_ws1.cell(count + 1, 1, cell.value)
                count = count + 1
        un_enrollment_ws.save(filename='unenroll_users.xlsx')
        un_enrollment_ws.close()

    def task_completed(self, t_id, token):
        url = f'{mod_base_url}progress/{t_id}'
        return self.session.get(url=url, headers=self._get_headers(token))

    def user_uploading_got_completed(self, transaction_id, token, retry=0):
        time.sleep(2)
        if retry >= 150:
            return
        response = self.task_completed(transaction_id, token)
        resp = self.get_content(response)
        logging.info(resp)
        if resp.get('done') and response.status_code == STATUS_CODE_GOOD:
            time.sleep(2)
            return resp
        else:
            return self.user_uploading_got_completed(transaction_id, token, retry=retry + 1)

    def user_enrollment(self, token, prog_id=PROGRAM_ID_NO):
        return self.session.get(url=f'{ADMIN_BASE_URL}api/automation/course_ops/auto_enrollment/'f'{prog_id}',
                                    headers=self._get_headers(token))

    def validate_errors_details(self, response_body):
        errors = response_body["errors"]
        for error in errors:
            return self.compare_expected_and_actual_result(error, message_key, "Invalid email id")

    def verify_error_message_for_invalid_sheet_name(self, response_body, index=0, message="Missing manage users sheet(s)"):
        error_message = response_body["errors"][index]
        return self.compare_expected_and_actual_result(error_message, message_key, message)

    def upload_user_report(self, token, tr_id):
        return self.session.get(url=f'{ADMIN_BASE_URL}api/report/{tr_id}', headers=self._get_headers(token))

    def upload_user_prog(self, token, prg_id):
        return self.session.get(url=f'{ADMIN_BASE_URL}api/automation/course_ops/auto_enrollment/{prg_id}',
                                headers=self._get_headers(token))

    def validate_user_uploading_response(self, response, t_id, status):
        self.compare_expected_and_actual_result(response, transaction_id_key, t_id)
        if not response[status] in ["PROCESSING", "COMPLETED"]:
            raise Exception(FAILED_TO_MATCH_VALUES.format(response[status], "PROCESSING or COMPLETED"))
        return True

    def validate_user_details(self, response, k_values):
        keys = [success_key, errors_key, total_key]
        return self.compare_expected_and_actual_results(response, keys, k_values)

    def validate_existing_user_failure_details(self, response):
        return self.compare_expected_and_actual_results(
            response["errors"][0], [column_key, message_key], [username_value, error_message]
        )

    def created_new_users_details(self, response_body):
        data = response_body['data'][0]
        self.verify_key_exist_with_valid_value_type(data, transaction_id_key, int)
        keys = ["completed", "existing_user_success_count", "existing_user_total",
                "new_user_success_count", "new_user_total"]
        return self.compare_expected_and_actual_results(data, keys, [true_value, 0, 0, 6, 6])

    def validate_group_work_details(self, response):
        assignments = response["assignments"]
        for assignment in assignments:
            self.compare_expected_and_actual_result(assignment["groups"][0], "result", "Groupwork group created.")
            self.verify_key_exist_with_valid_value_type(assignment, "assignment_name")
            self.compare_expected_and_actual_result(assignment, "overall_success", true_value)
            self.verify_key_exist_with_valid_value_type(assignment, "highest_group_number", int)
            self.verify_key_exist_with_valid_value_type(assignment, "lowest_group_number", int)
        return True

    def report_api_response(self, transaction_id, basic_auth):
        return self._get(url=f'{ADMIN_BASE_URL}api/report/{transaction_id}', token=basic_auth)

    def validate_un_enrollment_details(self, response, t_id):
        steps = response["steps"]
        keys = ["transaction_id", "title", "subtitle", "overall_success"]
        exp_values = [t_id, config_id, "All users are unenrolled without any errors.", true_value]
        self.compare_expected_and_actual_results(response["meta"], keys, exp_values)
        results = []
        for step in steps:
            if step.get("key") in ["gw_removal"] and step.get("success") is false_value:
                results.append(True)
            elif step.get("key") in ["wc_removal", "lp_removal"] and step.get("success") is true_value:
                results.append(True)
        return len(set(results)) == 1

    def validate_group_work_failure_message(self, response):
        actual_message = json.loads(response["message"].replace("'", '"'))["num_of_groups"][0]
        return self.compare_expected_and_actual_values(
            actual_message, 'Must be greater than or equal to 1 and less than or equal to 200.'
        )

    def create_bulk_update_accounts_file(self, sheet_name='bulk update accounts', active='yes'):
        sheet_ranges, bulk_enrollment_ws, bulk_enrollment_ws1, count = self.read_an_existing_file()
        dest_filename = 'bulk_update_accounts.xlsx'
        bulk_enrollment_ws1.title = sheet_name
        bulk_enrollment_ws1.cell(1, 1, 'username')
        bulk_enrollment_ws1.cell(1, 2, 'active')
        for cell in sheet_ranges['A']:
            bulk_enrollment_ws1.cell(count + 2, 1, cell.value)
            bulk_enrollment_ws1.cell(count + 2, 2, active)
            count = count + 1
        bulk_enrollment_ws1.delete_rows(2, 1)
        bulk_enrollment_ws.save(filename=dest_filename)
        bulk_enrollment_ws.close()

    def upload_bulk_update_accounts_file(self, token, upload=False, sheet_name_value="bulk update accounts", active="yes"):
        self.create_bulk_update_accounts_file(sheet_name=sheet_name_value, active=active)
        post_url = f'{ADMIN_BASE_URL}api/dat/validate/course_ops/user_statuses'
        if upload:
            post_url = f'{ADMIN_BASE_URL}api/automation/course_ops/user_statuses'

        params = {
            'program_id': PROGRAM_ID_NO,
            'program_type': 'course_ops',
            'sub_program_type': 'user_statuses'
        }

        files = {('file', open('bulk_update_accounts.xlsx', 'rb'))}
        return self.session.post(post_url, files=files, headers=self._get_headers(token), data=params)

    def get_transaction(self, token):
        url = f'{ADMIN_BASE_URL}api/report/program/{PROGRAM_ID_NO}'
        response = self.session.get(url, headers=self._get_headers(token))
        resp = self.get_content(response)
        return resp['activities_status']['course_ops']['user_management']['user_statuses']['transaction_ids'][0]

    def get_webinar_enrollments(self, token):
        url = f'{ADMIN_BASE_URL}api/enrollments/webinar/439?update=false'
        return self.session.get(url, headers=self._get_headers(token))

    def validate_webinar_details(self, response):
        keys = ["enrolled", "waitlisted"]
        return self.verify_keys_exist_with_valid_value_type(response["data"], keys, int)
