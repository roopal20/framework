import uuid
import _codecs
import codecs
import re

from bs4 import BeautifulSoup
from ...resources.ops_portal_base_page import OpsPortalBase
from ...resources import (ADMIN_BASE_URL, MCKID_BASE_URL, NONCE_URL, LOGIN_URL, CLIENT_ID, EMAIL, PASSWORD, AUTHORIZATION_KEY)


class LoginPage(OpsPortalBase):

    """
    Base class for page objects.
    """

    def __init__(self, *args, **kwargs):
        """
        Initialize the Task set.
        """
        super().__init__()

    def get_state_token(self, response):
        html_doc = response.text
        soup = BeautifulSoup(html_doc, 'html.parser')
        scripts_data = soup.find_all('script')
        for data in scripts_data:
            if "var stateToken" in data.get_text():
                script_text = data.get_text()
                break
        reg = re.findall(r"var\sstateToken\s=\s\'(.*?)\';", script_text)
        st_token = reg[0]
        es_token = _codecs.escape_decode(st_token)
        st_es_token = es_token[0]
        ust_token = codecs.decode(st_es_token)
        state_token = ust_token.translate({ord("'"): None})
        return state_token

    def redirect_to_mck_id_hub(self, email, client_id, authorization_key):
        random_string = str(uuid.uuid4().node)

        url = f'{MCKID_BASE_URL}/oauth2/{authorization_key}/v1/authorize?client_id={client_id}&' \
              f'redirect_uri={ADMIN_BASE_URL}auth/callback&scope=profile+openid+email&state=.&' \
              f'response_type=id_token+token&nonce={random_string}&login_hint={email}'

        response = self._get(url, token='', verify_response_string='stateToken', email=EMAIL)
        self._check_response(response, EMAIL)
        cookie = response.headers['set-Cookie']
        dt_val = re.findall(r'DT=(\w+)', cookie)
        dt = dt_val[0]
        state_token = self.get_state_token(response)
        return state_token, dt

    def refresh_state(self, st_token):

        url = f'{MCKID_BASE_URL}/signin/refresh-auth-state/{st_token}'
        response = self._get(url, st_token, verify_response_string='stateToken', email=EMAIL)
        self._check_response(response, EMAIL)

    def nonce_device(self, retry=0):
        if retry >= 10:
            return

        url = NONCE_URL

        response = self._post(url, params='', cookie='', token='', verify_response_string='nonce', email=EMAIL)
        self._check_response(response, EMAIL)
        resp = response.headers
        cookie = resp['set-Cookie']

        if 'JSESSIONID' in cookie:
            id_js = cookie.split('ID=')[1].strip()
            js_session_token = id_js.split(';')[0].strip()
            return js_session_token
        else:
            return self.nonce_device(retry=retry + 1)

    def redirect_ops(self, token):

        link = f"{MCKID_BASE_URL}/login/step-up/redirect?stateToken={token}"

        response = self.session.head(link, allow_redirects=True)
        self._check_response(response, EMAIL)
        return response.url

    def get_access_token(self, res_url):
        id_token = re.findall(r'access_token=(.*?)&', res_url)
        access_token = id_token[0]
        return access_token

    def login(self):
        """
        Authenticate the user.
        """
        st_token, dt = self.redirect_to_mck_id_hub(EMAIL, CLIENT_ID, AUTHORIZATION_KEY)
        self.refresh_state(st_token)
        js_id = self.nonce_device()

        cookie = {'cookie': f't=default; DT={dt}; oktaStateToken={st_token}; JSESSIONID={js_id}'}

        params = {
            'username': EMAIL,
            'password': PASSWORD,
            "stateToken": st_token
        }

        url = LOGIN_URL

        login_resp = self._post(url, params, cookie, token='', verify_response_string='stateToken', email=EMAIL)

        resp_url = self.redirect_ops(st_token)
        token_login = self.get_access_token(resp_url)

        return login_resp, token_login
