from test.mcka_ops_portal_api.config import *
from test.mcka_ops_portal_api.resources.ops_portal_base_page import OpsPortalBase

from ...resources.utils import build_request_headers, random_word


class ContentManagement(OpsPortalBase):

    def __init__(self):
        super().__init__()

    def get_response_of_view_component(self, access_token):
        response = self._get(view_component_endpoint, access_token)
        return response

    def refresh_content_management(self, access_token):
        response = self._get(refresh_content_endpoint, access_token)
        return response

    def copy_component(self, access_token, new_component_code=''):
        request_headers = build_request_headers(access_token)
        if new_component_code:
            copy_component_payload.update(new_component_code)
        else:
            new_component_name = f'copied {random_word(9)}'
            copy_component_payload.update({"new_component_code": f'{new_component_name} - {content_management_lp_code}'})
            copy_component_payload["new_component_title"] = new_component_name
        response = SESSION.post(cm_copy_component_endpoint, headers=request_headers, json=copy_component_payload)
        return response, copy_component_payload

    @staticmethod
    def validate_copy_component(access_token, new_component_code=''):
        request_headers = build_request_headers(access_token)
        if new_component_code:
            copy_component_payload.update(new_component_code)
        else:
            new_component_name = f'copied {random_word(9)}'
            copy_component_payload.update({"new_component_code": f'{new_component_name} - {content_management_lp_code}'})
            copy_component_payload["new_component_title"] = new_component_name
        response = SESSION.post(validate_copy_component_endpoint, headers=request_headers, json=copy_component_payload)
        return response

    def get_value_of_view_component_data(self, response_body, required_key, nested_required_key=''):
        data = response_body['data']
        if len(data) is None:
            raise Exception("Data List is empty")

        for item in data:
            value_of_key = item[required_key]
            if isinstance(value_of_key, list):
                value_of_key = self.get_list_of_json_key(value_of_key, nested_required_key)
            return value_of_key

    @staticmethod
    def verify_languages(response_body, languages):
        if languages == response_body:
            return False
        return True

    def update_program(self, access_token, payload_data=''):
        updated_component_name = ''
        if not payload_data:
            updated_component_name = f'copied {random_word(9)}'
            update_program_payload_data = {
                "additional_fields": [
                    {"id": "14", "key": "Portfolio", "slug": "portfolio", "value": "Digital and Analytics (DnA)"}
                ],
                "code": f"{updated_component_name} - {content_management_lp_code}",
                "credits": "0.00",
                "description": "Join this optional webinar to review the course goals, expectations, and syllabus.",
                "id": update_content_management_course,
                "is_published": 0,
                "lang_label": "English",
                "name": updated_component_name
            }
        else:
            update_program_payload_data = payload_data
        response = self._put(update_program, update_program_payload_data, cookie='', token=access_token)
        return response, [updated_component_name, f"{updated_component_name} - {content_management_lp_code}"] \
            if updated_component_name else response
