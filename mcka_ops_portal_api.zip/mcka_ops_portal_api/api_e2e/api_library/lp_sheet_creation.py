from cgi import test
import requests
from uuid import uuid4
import json
import os
import xlsxwriter
from ...resources.utils import build_request_headers
from ...config import SESSION, Log


class LPCreation(object):

    """
    Base class for page objects.
    """

    def __init__(self, *args, **kwargs):
        """
        Initialize the Task set.
        """
        # self.lp_file = os.path.abspath(os.path.join(f'{os.curdir}/test/mcka_ops_portal_api/resources/excel_upload', '/lp_data.xlsx'))
        self.lp_file = 'lp_data.xlsx'
        self.validate_file_url = "api/dat/validate/course_prod/program_creation"
        self.create_new_lp_url = "api/automation/course_prod/program_creation"
        self.user_info_url = 'api/user'
        self.user_environment_info_url = 'api/environment'

    def user_environment_info(self, app_url, access_token):
        url = f'{app_url}{self.user_environment_info_url}'
        request_headers = build_request_headers(access_token)
        response = SESSION.get(url, headers=request_headers)
        return response

    def create_learning_plan_file(self, pre_fix, post_fix, course_type, lp_name, lp_desc, lp_level, expert_name, connected,
                                  ch_type, ch_empty, ch_sort):
        number_of_rows = 5
        start = 1
        end = start + number_of_rows
        random_val = uuid4().hex[0:3]
        upload_file_name = '/lp_data.xlsx'
        # upload_lp_file = os.path.abspath(os.path.join(f'{os.curdir}/test/mcka_ops_portal_api/resources/excel_upload', upload_file_name))
        upload_lp_file = 'lp_data.xlsx'
        workbook = xlsxwriter.Workbook(upload_lp_file)
        worksheet = workbook.add_worksheet('Learning Plan')
        worksheet1 = workbook.add_worksheet('Channel')
        worksheet2 = workbook.add_worksheet('Catalog')
        worksheet.write('A1', 'LP_config_id')
        worksheet.write('B1', 'LP_name')
        worksheet.write('C1', 'LP_desc')
        worksheet.write('D1', 'LP_icon')
        worksheet.write('E1', 'LP_level')
        worksheet.write('F1', 'course_name')
        worksheet.write('G1', 'course_type')
        worksheet.write('H1', 'course_icon')
        worksheet.write('I1', 'course_desc')
        worksheet.write('J1', 'course_code')
        worksheet.write('K1', 'metadata')
        worksheet.write('L1', 'connected')
        worksheet.write('M1', 'RTL')
        worksheet.write('N1', 'lp_metadata')
        my_dict = {
            "Portfolio": "Leadership and Reskilling",
            "Offering": "McKinsey Management Program",
            "Program": "MMP Business Strategy"
        }
        channel_content_dict = {"Test PDF - May22": "pdf", "Oil Frame": "pdf", "TBD": "docx", "Impact matrix": "pdf",
                                "PDF 3": "pdf"}
        ccn_k = list(channel_content_dict.keys())
        cct_v = list(channel_content_dict.values())
        for val in range(end):
            if val % 2 == 0:
                worksheet.write(val + 1, 0, f'TEST_AUTO{random_val}_MAY22')
                worksheet.write(val + 1, 1, f'{lp_name}')
                worksheet.write(val + 1, 2, f'{lp_desc}')
                worksheet.write(val + 1, 3, '134jh')
                worksheet.write(val + 1, 4, f'{lp_level}')
                worksheet.write(val + 1, 5, f'Scorm - Course - {val}')
                worksheet.write(val + 1, 6, f'{course_type}')
                worksheet.write(val + 1, 7, 'Kickoff_Thumb_L_BG.png')
                worksheet.write(val + 1, 8, 'Build your strategic decision-making skills by deepening your '
                                            'understanding and exploring frameworks for building and evaluating '
                                            'strategies.')
                worksheet.write(val + 1, 9, f'Course - {val} - TEST_AUTO{random_val}_{post_fix}')
                worksheet.write(val + 1, 10, json.dumps(my_dict))
                worksheet.write(val + 1, 11, f'{connected}')
                worksheet.write(val + 1, 12, 'No')
                worksheet.write(val + 1, 13, '')
            else:
                worksheet.write(val + 1, 0, f'TEST_AUTO{random_val}_MAY22')
                worksheet.write(val + 1, 1, 'Test Automation Program')
                worksheet.write(val + 1, 2, 'This is a LP for the KS automation program')
                worksheet.write(val + 1, 3, '134jh')
                worksheet.write(val + 1, 4, 'Landing Page 3')
                worksheet.write(val + 1, 5, f'ILT - Course - {val}')
                worksheet.write(val + 1, 6, 'classroom')
                worksheet.write(val + 1, 7, 'Courses_Thumb_L_BG.png')
                worksheet.write(val + 1, 8, 'Join this optional webinar to review the course goals, expectations, and '
                                            'syllabus')
                worksheet.write(val + 1, 9, f'Course - {val} - TEST_AUTO{random_val}_{post_fix}')
                worksheet.write(val + 1, 10, json.dumps(my_dict))
                worksheet.write(val + 1, 11, 'no')
                worksheet.write(val + 1, 12, 'No')
                worksheet.write(val + 1, 13, '')

            worksheet1.write('A1', 'LP_config_id')
            worksheet1.write('B1', 'channel_name')
            worksheet1.write('C1', 'channel_desc')
            worksheet1.write('D1', 'channel_icon')
            worksheet1.write('E1', 'channel_icon_fg')
            worksheet1.write('F1', 'channel_icon_bg')
            worksheet1.write('G1', 'channel_type')
            worksheet1.write('H1', 'channel_sort')
            worksheet1.write('I1', 'expert_name')
            worksheet1.write('J1', 'channel_upload_permissions')
            worksheet1.write('K1', 'channel_content_name')
            worksheet1.write('L1', 'channel_content_type_id')
            worksheet1.write('M1', 'channel_content_type')
            worksheet1.write('N1', 'metadata')
            if ch_empty == 1:
                for val1 in range(end):
                    if val1 % 2 == 0:
                        worksheet1.write(val1 + 1, 0, f'TEST_AUTO{random_val}_MAY22')
                        worksheet1.write(val1 + 1, 1, f'Channel - {pre_fix}_AUTO{random_val}_{post_fix}')
                        worksheet1.write(val1 + 1, 2, 'Channel - description')
                        worksheet1.write(val1 + 1, 3, 'zmdi zmdi-view-dashboard')
                        worksheet1.write(val1 + 1, 4, '#ffffff')
                        worksheet1.write(val1 + 1, 5, '#333333')
                        worksheet1.write(val1 + 1, 6, f'{ch_type}')
                        worksheet1.write(val1 + 1, 7, f'{ch_sort}')
                        worksheet1.write(val1 + 1, 8, f'{expert_name}')
                        worksheet1.write(val1 + 1, 9, 'everyone_with_expert_permissions')
                        worksheet1.write(val1 + 1, 10, f'TBD {val1}')
                        worksheet1.write(val1 + 1, 11, '1')
                        worksheet1.write(val1 + 1, 12, 'docx')
                        worksheet1.write(val1 + 1, 13, '')
                    else:
                        worksheet1.write(val1 + 1, 0, f'TEST_AUTO{random_val}_MAY22')
                        worksheet1.write(val1 + 1, 1, f'Channel - {pre_fix}_AUTO{random_val}_{post_fix}')
                        worksheet1.write(val1 + 1, 2, 'Channel - description')
                        worksheet1.write(val1 + 1, 3, 'zmdi zmdi-view-dashboard')
                        worksheet1.write(val1 + 1, 4, '#ffffff')
                        worksheet1.write(val1 + 1, 5, '#333333')
                        worksheet1.write(val1 + 1, 6, 'custom')
                        worksheet1.write(val1 + 1, 7, 'date_desc')
                        worksheet1.write(val1 + 1, 8, 'mckinsey@example.com')
                        worksheet1.write(val1 + 1, 9, 'everyone_with_expert_permissions')
                        worksheet1.write(val1 + 1, 10, f'Test PDF - {post_fix} {val1}')
                        worksheet1.write(val1 + 1, 11, '1')
                        worksheet1.write(val1 + 1, 12, 'pdf')
                        worksheet1.write(val1 + 1, 13, '')

            worksheet2.write('A1', 'LP_config_id')
            worksheet2.write('B1', 'catalog_code')
            worksheet2.write('C1', 'catalog_name')
            worksheet2.write('D1', 'catalog_desc')
            worksheet2.write('E1', 'catalog_course_code')
            worksheet2.write('F1', 'catalog_course_name')
            worksheet2.write('G1', 'metadata')

        workbook.close()

    def upload_learning_plan_file(self, app_url, access_token, pre_fix, post_fix, course_type, lp_name, lp_desc, lp_level, expert_name, connected, ch_type, ch_empty, ch_sort, url_type="Replication"):
        Log.info(pre_fix)
        self.create_learning_plan_file(pre_fix=pre_fix, post_fix=post_fix, course_type=course_type,
                                       lp_name=lp_name, lp_desc=lp_desc, lp_level=lp_level,
                                       expert_name=expert_name, connected=connected, ch_type=ch_type, ch_empty=ch_empty,
                                       ch_sort=ch_sort)

        if url_type == "Replication":
            post_url = f'{app_url}{self.validate_file_url}'
        else:
            post_url = f'{app_url}{self.create_new_lp_url}'
        requests_headers = build_request_headers(access_token)

        files = {'file': open(self.lp_file, 'rb').read()}

        response = SESSION.post(post_url, files=files, headers=requests_headers)

        return response
