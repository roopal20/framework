import os
import time
import uuid
import random

import xlsxwriter
from openpyxl import Workbook, load_workbook
from test.mcka_ops_portal_api.config import *

from test.mcka_ops_portal_api.resources import ADMIN_BASE_URL
from test.mcka_ops_portal_api.resources.ops_portal_base_page import OpsPortalBase


class GroupWork(OpsPortalBase):
    users_enrollment_file_name = 'gw_users_enrollment.xlsx'
    unenroll_users_file_name = 'gw_unenroll_users.xlsx'
    update_groups_file_name = 'gw_update.xlsx'

    def __init__(self):
        super().__init__()

    def get_lp_without_assignment_and_groups(self, access_token):
        response = self._get(without_assignment_and_groups_endpoint, access_token)
        return response

    def get_lp_without_groups_and_with_assignment(self, access_token):
        response = self.session.get(without_groups_and_with_assignment_endpoint, access_token)
        print(response.text)
        return response

    def get_lp_with_groups_and_assignment(self, access_token):
        return self._get(with_groups_and_assignment_endpoint, access_token)

    def upload_participants_file(
            self, token, p_id='', email=None, client_name=client_value, single_client=True, password=pass_value,
            number_of_user=2, sheet_name='manage users'):
        self.create_participants_file(
            email, client_name=client_name, password=password, number_of_user=number_of_user,
            sheet_name=sheet_name, single_client=single_client)
        if p_id:
            post_url = f'{ADMIN_BASE_URL}api/dat/validate/course_ops/auto_enrollment?program_id={p_id}'
        else:
            post_url = f'{ADMIN_BASE_URL}api/v2/automation/course_ops/auto_enrollment'
        params = {
            'program_id': enrolled_session_program_id,
            'is_single_client_program': single_client,
            'wave_id': wave_id
        }
        files = {'file': open(self.users_enrollment_file_name, 'rb').read()}
        time.sleep(2)
        return self.session.post(post_url, files=files, headers=self._get_headers(token), data=params)

    def upload_user_report(self, token, tr_id):
        return self.session.get(url=f'{ADMIN_BASE_URL}api/report/{tr_id}', headers=self._get_headers(token))

    def validate_upload_unenroll_file(self, token, sheet_name, users, upload=False):
        self.create_un_enrollment_file(sheet_name)
        post_url = f'{ADMIN_BASE_URL}api/dat/validate/course_ops/bulk_unenrollment'
        if upload:
            post_url = f'{ADMIN_BASE_URL}api/automation/course_ops/bulk_unenrollment'
        params = {
            'program_id': enrolled_session_program_id
        }
        files = {('file', open(self.unenroll_users_file_name, 'rb'))}
        return self.session.post(post_url, files=files, headers=self._get_headers(token), data=params)

    def validate_group_work_details(self, response):
        assignments = response["assignments"]
        for assignment in assignments:
            assert self.compare_expected_and_actual_result(response[assignments_key][0], assignment_name_key,
                                                           group_assignment_name)
            # self.verify_key_exist_with_valid_value_type(assignment, "assignment_name")
            self.compare_expected_and_actual_result(assignment, "overall_success", true_value)
            self.verify_key_exist_with_valid_value_type(assignment, "highest_group_number", int)
            self.verify_key_exist_with_valid_value_type(assignment, "lowest_group_number", int)
        return True

    def validate_group_work_failure_message(self, response):
        actual_message = json.loads(response["message"].replace("'", '"'))["num_of_groups"][0]
        return self.compare_expected_and_actual_values(
            actual_message, 'Must be greater than or equal to 1 and less than or equal to 2000.'
        )

    def create_participants_file(self, email, password, client_name, number_of_user, sheet_name, single_client):
        start = 1
        end = start + number_of_user
        first_name = 'ntst_'
        last_name = 'user'
        random_val = uuid.uuid4().hex[0:3]
        upload_file_name = self.users_enrollment_file_name
        student_file = os.path.abspath(os.path.join(os.curdir, upload_file_name))
        workbook = xlsxwriter.Workbook(student_file)
        worksheet = workbook.add_worksheet(sheet_name)
        worksheet.write('A1', 'username')
        worksheet.write('B1', 'Firstname')
        worksheet.write('C1', 'Lastname')
        worksheet.write('D1', 'Email')
        worksheet.write('E1', 'Password')
        worksheet.write('F1', 'force password change')
        worksheet.write('G1', 'client name')
        worksheet.write('H1', 'client id')
        worksheet.write('I1', 'Groupwork')
        worksheet.write('J1', 'primary experience')
        worksheet.write('K1', 'language')
        worksheet.write('L1', 'Role')
        worksheet.write('M1', 'custom field 1')
        worksheet.write('N1', 'custom field 2')
        worksheet.write('O1', 'custom field 3')
        worksheet.write('P1', 'custom field 4')
        for val in range(end):
            if email:
                email_value = email
            else:
                email_value = f'{first_name}{last_name}{val + 1}{random_val}@mailinator.com'
            worksheet.write(val + 1, 0, email_value)
            worksheet.write(val + 1, 1, first_name)
            worksheet.write(val + 1, 2, f'{last_name}{val + 1}{random_val}')
            worksheet.write(val + 1, 3, email_value)
            worksheet.write(val + 1, 4, password)
            worksheet.write(val + 1, 5, 'No')
            if single_client:
                worksheet.write(val + 1, 6, client_name)
                worksheet.write(val + 1, 7, "R10_Arbisoft_Rls10")
                if 'Test_Automation_Assignment' in new_group_work:
                    if val % 2 == 0:
                        worksheet.write(val + 1, 8, f'Group 01 - {new_group_work}')
                    else:
                        worksheet.write(val + 1, 8, f'Group 02 - {new_group_work}')
                else:
                    worksheet.write(val + 1, 8, '')
            else:
                if val % 2 == 0:
                    worksheet.write(val + 1, 6, client_name)
                    worksheet.write(val + 1, 7, "R10_Arbisoft_Rls10")
                    worksheet.write(val + 1, 8, '')
                else:
                    worksheet.write(val + 1, 6, 'Arbisoft')
                    worksheet.write(val + 1, 7, 'Release10_Arbisoft')
                    worksheet.write(val + 1, 8, '')

            worksheet.write(val + 1, 9, 'Landing Page 3')
            worksheet.write(val + 1, 10, '')
            worksheet.write(val + 1, 11, random.choices(["Observer", "Participant"])[0])
            worksheet.write(val + 1, 12, '')
            worksheet.write(val + 1, 13, '')
            worksheet.write(val + 1, 14, '')
            worksheet.write(val + 1, 15, '')

        workbook.close()

    def create_groups(self, token, prog_id, num_of_groups=2):
        url = f'{ADMIN_BASE_URL}api/automation/course_ops/groupwork_groups/bulk'
        params = {
            "program_id": prog_id,
            "starting_group_number": 202,
            "num_of_groups": num_of_groups}
        return self.session.post(url=url, json=params, headers=self._get_headers(token))

    def create_un_enrollment_file(self, sheet_name):
        sheet_ranges, un_enrollment_ws, un_enrollment_ws1, count = self.read_an_existing_file()
        un_enrollment_ws1.title = sheet_name
        users = []
        for cell in sheet_ranges['A']:
            users.append(cell.value)
            un_enrollment_ws1.cell(count + 1, 1, cell.value)
            count = count + 1
        un_enrollment_ws.save(filename=self.unenroll_users_file_name)
        un_enrollment_ws.close()
        return users

    def get_enrollment_users(self):
        sheet_ranges, _, _, _ = self.read_an_existing_file()
        users = []
        for cell in sheet_ranges['A']:
            users.append(cell.value)
        return users[1:]

    def read_an_existing_file(self):
        un_enrollment_file = self.users_enrollment_file_name
        wb = load_workbook(filename=un_enrollment_file)
        sheet_ranges = wb['manage users']
        un_enrollment_ws = Workbook()
        un_enrollment_ws1 = un_enrollment_ws.active
        count = 0
        return sheet_ranges, un_enrollment_ws, un_enrollment_ws1, count

    def create_gw_update_accounts_file(self, user_email, group_name, ta_name, ta_email):
        u_file_name = self.update_groups_file_name
        wb = xlsxwriter.Workbook(u_file_name)
        ws = wb.add_worksheet('Groupwork File')
        ws.write('A1', 'Group Name')
        ws.write('B1', 'TA Name')
        ws.write('C1', 'TA Email')
        ws.write('D1', 'GC Username')

        for val in range(1, 3):
            if val % 2 == 0:
                ws.write(val, 0, f'Group 01 - {group_name}')
                ws.write(val, 1, ta_name)
                ws.write(val, 2, ta_email)
                ws.write(val, 3, user_email)
            else:
                ws.write(val, 0, f'Group 02 - {new_group_work}')
                ws.write(val, 1, 'ta2_name')
                ws.write(val, 2, 'ta2_email@test.com')
                ws.write(val, 3, 'ntst_user2997@mailinator.com')

        wb.close()

    def get_group_details(self, access_token, group_program_id=enrolled_session_program_id):
        params = {"program_id": group_program_id}
        return self._post(f'{ADMIN_BASE_URL}api/dat/course_ops/groupwork_groups/groups?page=1&search=&search_type=group_name&all_groups_info=false',
                          params, cookie='', token=access_token)

    @staticmethod
    def get_group_number_and_users_email(response_body):
        return response_body["groups"][0]["group_members"][0]["email"], response_body["groups"][1]["group_number"]

    def move_users(self, access_token, email_id, other_group_number):
        params_move_users = {"program_id": enrolled_session_program_id,
                             "new_group_number": other_group_number,
                             "email": email_id
                             }
        return self._put(f'{ADMIN_BASE_URL}api/groupwork_management/move_user',
                         params_move_users, cookie='', token=access_token)

    def validate_user_moved(self, response_body, email_id, other_group_number):
        self.compare_expected_and_actual_result(response_body, )

    def group_gc(self, access_token, email, group_number, gc_assign):
        params_group_gc = {"program_id": enrolled_session_program_id,
                           "group_number": group_number,
                           "email": email,
                           "gc_assign": gc_assign
                           }
        return self._put(f'{ADMIN_BASE_URL}api/groupwork_management/update_gc',
                         params_group_gc, cookie='', token=access_token)

    def assign_group_ta(self, access_token, group_number, ta_email, ta_name):
        params_group_ta = {"program_id": enrolled_session_program_id,
                           "group_number": group_number,
                           "email": ta_email,
                           "name": ta_name}
        return self._put(
            f'{ADMIN_BASE_URL}api/groupwork_management/update_ta', params_group_ta, cookie='',
            token=access_token)

    def remove_group_user(self, access_token, email_id, group_number):
        params = {"program_id": enrolled_session_program_id, "group_number": group_number, "email": email_id}
        return self._post(f'{ADMIN_BASE_URL}api/groupwork_management/remove_member',
                          params, cookie='', token=access_token)

    def validate_remove_group_user(self, access_token, email_id, group_number):
        params = {"program_id": enrolled_session_program_id, "group_number": group_number, "email": email_id}
        return self._post(f'{ADMIN_BASE_URL}api/dat/course_ops/groupwork_groups/groups?page=1&search={email_id}'
                          f'&search_type=group_member&all_groups_info=false', params, cookie='', token=access_token)

    def search_user(self, access_token, search='', search_type='', all_groups_info=False):
        search_url = f'{ADMIN_BASE_URL}api/dat/course_ops/groupwork_groups/groups?page=1&search={search}&search_type=' \
            f'{search_type}&all_groups_info={all_groups_info}'

        return self._post(search_url, params='', cookie='', token=access_token)

    def upload_group_coordinators_and_ta_groupwork_info(self, access_token):
        response_group_users = self.get_group_details(access_token)
        response_group_users_body = self.get_content(response_group_users)
        email_id, _ = self.get_group_number_and_users_email(response_group_users_body)
        self.create_gw_update_accounts_file(email_id, group_name=new_group_work, ta_name='ta_name',
                                            ta_email='ta_email@email.com')
        url = f'{ADMIN_BASE_URL}api/automation/course_ops/upload_groupwork_roles'
        files = {('file', open(self.update_groups_file_name, 'rb'))}
        params = {"program_id": enrolled_session_program_id}
        return self.session.post(url, params, files=files, headers=self._get_headers(access_token))

    def validate_upload_group_coordinators_and_ta_groupwork_info(self, access_token):
        self.create_gw_update_accounts_file(user_email='abc', group_name='test', ta_name='', ta_email='')
        url = f'{ADMIN_BASE_URL}api/dat/validate/course_ops/upload_groupwork_roles'
        files = {('file', open(self.update_groups_file_name, 'rb'))}
        params = {"program_id": enrolled_session_program_id}
        return self.session.post(url, params, files=files, headers=self._get_headers(access_token))

    def user_uploading_got_completed(self, transaction_id, token, retry=0):
        time.sleep(2)
        if retry >= 150:
            return
        response = self.task_completed(transaction_id, token)
        resp = self.get_content(response)
        if resp.get('done') and response.status_code == STATUS_CODE_GOOD:
            time.sleep(2)
            return resp
        else:
            return self.user_uploading_got_completed(transaction_id, token, retry=retry + 1)

    def task_completed(self, t_id, access_token):
        url = f'{mod_base_url}progress/{t_id}'
        return self.session.get(url=url, headers=self._get_headers(access_token))

    def validate_user_uploading_response(self, response, transaction_id, status):
        self.compare_expected_and_actual_result(response, transaction_id_key, transaction_id)
        if not response[status] in ["PROCESSING", "COMPLETED", ]:
            raise Exception(FAILED_TO_MATCH_VALUES.format(response[status], "PROCESSING or COMPLETED"))
        return True

    def check_if_pending(self, details, transaction_id, status, access_token):
        if details[status] == "PENDING":
            response = self.complete_now_process_queue(transaction_id, access_token)
            if not STATUS_CODE_GOOD == response.status_code:
                raise Exception(FAILED_TO_MATCH_VALUES.format(STATUS_CODE_GOOD, response.status_code))
            return True
        else:
            return self.validate_user_uploading_response(details, transaction_id, status=transaction_status_key)

    def complete_now_process_queue(self, transaction_id, access_token):
        payload = {
            "transaction_id": transaction_id,
            "should_append_config_ids": true_value,
            "should_use_excel_data_for_password_change": true_value,
            "update_name": true_value,
            "update_lang": true_value
        }
        response = self._put(
            f'{ADMIN_BASE_URL}api/v2/automation/course_ops/auto_enrollment/{transaction_id}', payload, cookie='',
            token=access_token
        )
        return response

    def report_api_response(self, transaction_id, access_token):
        return self._get(url=f'{ADMIN_BASE_URL}api/report/{transaction_id}', token=access_token)

    def validate_un_enrollment_details(self, response, transaction_id):
        steps = response["steps"]
        keys = ["transaction_id", "title", "subtitle", "overall_success"]
        exp_values = [transaction_id, enrolled_session_program_name, "All users are unenrolled without any errors.",
                      true_value]
        self.compare_expected_and_actual_results(response["meta"], keys, exp_values)
        results = []
        for step in steps:
            if step.get("key") in ["gw_removal"] and step.get("success") is false_value:
                results.append(True)
            elif step.get("key") in ["wc_removal", "lp_removal"] and step.get("success") is true_value:
                results.append(True)
        return len(set(results)) == 1

    def download_latest_groupwork_data_file(self, access_token):
        response = self._get(
            f'{ADMIN_BASE_URL}api/groupwork_management/roles_download/{enrolled_session_program_id}', access_token)
        with open(f'groupwork{enrolled_session_program_id}.xlsx', 'wb') as out_file:
            out_file.write(response.content)
        return response

    def validate_list_response(self, response_body):
        data_info = response_body[data_key]
        for data in data_info:
            self.verify_key_exist_with_valid_value_type(data, 'id', int)
            self.verify_key_exist_with_valid_value_type(data, transaction_id_key, int)
            self.compare_expected_and_actual_result(data, success_key, true_value)
        return self.verify_key_exist_with_valid_value_type(data_info[0], 'triggered_by')

    def validate_uploaded_new_users_in_group_works(self, response_body, transaction_id):
        assert self.compare_expected_and_actual_result(response_body, transaction_id_key, transaction_id)
        assert self.compare_expected_and_actual_result(response_body, status_key, completed_message)
        assert self.compare_expected_and_actual_result(response_body, filename_key, file_text)
        assert self.compare_expected_and_actual_result(response_body, failed_key, 0)

        assert self.compare_expected_and_actual_result(response_body[new_users_key], success_key, 3)
        assert self.compare_expected_and_actual_result(response_body[new_users_key], failed_key, 0)
        assert self.compare_expected_and_actual_result(response_body[new_users_key], errors_key, [])
        assert self.compare_expected_and_actual_result(response_body[new_users_key], total_key, 3)

        assert self.compare_expected_and_actual_result(response_body[existing_users_key], logged_in_key, 0)
        assert self.compare_expected_and_actual_result(response_body[existing_users_key], never_logged_in_key, 0)
        assert self.compare_expected_and_actual_result(response_body[existing_users_key], errors_key, [])
        assert self.compare_expected_and_actual_result(response_body[existing_users_key], total_key, 0)
        assert self.compare_expected_and_actual_result(response_body[existing_users_key], inactive_users_key, 0)
        assert self.compare_expected_and_actual_result(response_body[existing_users_key], done_key, true_value)
        assert self.compare_expected_and_actual_result(response_body[existing_users_key], success_key, 0)

        assert self.verify_key_exist_with_valid_value_type(response_body, created_at_key)
        assert self.verify_key_exist_with_valid_value_type(response_body, transaction_id_key)
        return True

    def validate_emails_in_json(self, response, values_list, no_of_groups):
        for val in values_list:
            if not self.check_value(response, no_of_groups, val):
                return False
        return True

    @staticmethod
    def check_value(response, no_of_groups, val):
        for index in range(no_of_groups):
            for member in response[index]['group_members']:
                if member['email'] == val:
                    return True
        return False
