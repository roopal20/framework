import requests
import json
import re
import time

from openpyxl import load_workbook
from ...resources import DOCEBO_LMS_URL, LP_CONFIG_ID, ASSIGNMENT_COURSE_ID, ASSIGNMENT_LO_ID
from ...resources.ops_portal_base_page import *


class DoceboLogin(object):

    """
    Base class for page objects.
    """

    def __init__(self):
        """
        Initialize the Task set.
        """
        super(DoceboLogin, self).__init__()
        self.session = requests.Session()
        self.BASE_URL = DOCEBO_LMS_URL

    def post_headers(self, token, cookie):
        headers = {
            'accept': 'application/json, text/plain, */*',
            'accept-language': 'en-GB,en-US;q=0.9,en;q=0.8',
            'accept-encoding': 'gzip, deflate, br',
            'content-type': 'application/json; charset=UTF-8',
            'authorization': f'Bearer {token}',
            'referer': self.BASE_URL
        }
        if cookie:
            headers.update(cookie)
        return headers

    def get_headers(self):
        return {
            'accept': 'application/json, text/plain, */*',
            'accept-language': 'en-GB,en-US;q=0.9,en;q=0.8',
            'accept-encoding': 'gzip, deflate, br',
            'content-type': 'application/json; charset=UTF-8',
            'referer': self.BASE_URL,
            'cookie': 'r=use1-staging; cookie_privacy_policy=accepted'
        }

    def login(self, username):
        """
        Authenticate the user.
        :param username: The user's username.
        :param password: The user's password.
        """
        post_url = f'{self.BASE_URL}manage/v1/user/login?lang=en'
        params = {
            "username": username,
            "password": "OneAcademy!1",
            "rememberMe": "",
            "client_timezone": -18000,
            "client_timezone_textual": "Asia/Karachi"
        }

        response = self.session.post(post_url, json=params, headers=self.get_headers())
        res_txt = json.loads(response.text)
        data = res_txt['data']
        token = data['access_token']

        return token

    def get_cookie(self, token):

        cookie_url = f'{self.BASE_URL}manage/v1/cdn-cookies/urls'

        cookie_response = self.session.get(cookie_url, headers=self.post_headers(token, cookie=''))

        cookie_res_txt = json.loads(cookie_response.text)
        data = cookie_res_txt['data']
        cookie_token_url = data['creation_url']

        cfp_value = re.findall(r'CloudFront-Policy=(.*?)&', cookie_token_url)[0]
        cfs_value = re.findall(r'CloudFront-Signature=(.*?)&', cookie_token_url)[0]
        cfk_value = re.findall(r'CloudFront-Key-Pair-Id=(.*)', cookie_token_url)[0]

        ops_url = f'{self.BASE_URL}lms/index.php?r=site/openSessionViaToken'
        ops_resp = self.session.get(ops_url, headers=self.post_headers(token, cookie=''))

        awsa_value = ops_resp.cookies['AWSALB']
        awsc_value = ops_resp.cookies['AWSALBCORS']

        cookie = {'cookie': f'r=use1-staging; cookie_privacy_policy=accepted; CloudFront-Policy={cfp_value}; '
                            f'CloudFront-Signature={cfs_value}; CloudFront-Key-Pair-Id={cfk_value}; '
                            f'AWSALB={awsa_value}; AWSALBCORS={awsc_value}; hydra_access_token={token};'}

        return cookie

    def get_notifications(self, token, cookie):

        notify_url = f'{self.BASE_URL}notifications/v1/notification/notifications'
        self.session.get(notify_url, headers=self.post_headers(token, cookie))

    def policy_track(self, token, cookie):
        policy_params = {"policy": {"id": 1, "answer": True, "sub_policies": []}}

        policy_url = f'{self.BASE_URL}manage/v1/policy/track'
        self.session.post(policy_url, json=policy_params, headers=self.post_headers(token, cookie))

    def terms_track(self, token, cookie):
        terms_params = {
            "tc": {
                "id": 1,
                "answer": True
            }
        }

        policy_url = f'{self.BASE_URL}manage/v1/termsandconditions/track'
        self.session.post(policy_url, json=terms_params, headers=self.post_headers(token, cookie))

    def get_lp(self, token, cookie):
        lp_url = f'{self.BASE_URL}learn/v1/lp/{LP_CONFIG_ID}'
        self.session.get(lp_url, headers=self.post_headers(token, cookie))

    def get_course(self, token, cookie):
        course_url = f'{self.BASE_URL}learn/v1/courses/{ASSIGNMENT_COURSE_ID}?get_all_sessions=1'
        self.session.get(course_url, headers=self.post_headers(token, cookie))

    def upload_file(self, token, cookie):
        upload_url = f'{self.BASE_URL}manage/v1/upload/presigned_url?operation=write&filename=test.pdf&' \
                     f'mime=application/pdf&collection=deliverable'
        time.sleep(1)
        sub_resp = self.session.get(upload_url, headers=self.post_headers(token, cookie))
        res_txt = json.loads(sub_resp.text)
        data = res_txt['data']
        filename_hashed = data['filename_hashed']
        return filename_hashed

    def upload_file_url(self, token, cookie, filename_hashed):
        upload_url = f'{self.BASE_URL}manage/v1/upload/presigned_url?operation=read&filename={filename_hashed}&' \
                     f'mime=pdf&collection=deliverable&keep_original_filename=true'
        self.session.get(upload_url, headers=self.post_headers(token, cookie))

    def user_uploading_assignment_got_completed(self, token, cookie, file_id, retry=0):
        time.sleep(1)
        if retry >= 150:
            return
        file_id = self.upload_file(token, cookie)
        self.upload_file_url(token, cookie, file_id)
        resp = self.submit_file_url(token, cookie, file_id)
        logging.info(resp)

        if resp.get('id'):
            time.sleep(1)
            return resp
        else:
            return self.user_uploading_assignment_got_completed(token, cookie, file_id, retry=retry + 1)

    def submit_file_url(self, token, cookie, filename_hashed):
        upload_url = f'{self.BASE_URL}learn/v1/lo/{ASSIGNMENT_LO_ID}/track'
        file_name = 'test.pdf'
        file_path = os.path.abspath(os.path.join(f'{os.curdir}/test/mcka_ops_portal_api/resources/excel_upload/', file_name))
        payload = {
            "track": {
                "type": "submission",
                "submission": {
                    "id": None,
                    "learner_reply": "",
                    "name": "test",
                    "description": "",
                    "files": [
                        {
                            "url": f"{filename_hashed}",
                            "filename": f'{file_name}'
                        }
                    ],
                    "video_url": ""
                }
            }
        }
        time.sleep(1)
        sub_resp = self.session.post(upload_url, json=payload,
                                     headers=self.post_headers(token, cookie))

        resp = json.loads(sub_resp.text)
        if sub_resp.status_code == 403:
            data = self.user_uploading_assignment_got_completed(token, cookie, filename_hashed, retry=0)
            return data
        elif sub_resp.status_code == 200:
            data = resp['data']['acknowledge']
            return data

    def reading_an_existing_file(self):
        student_file = 'users_enrollment.xlsx'
        wb = load_workbook(filename=student_file)
        sheet_ranges = wb['manage users']
        count = 0
        users_info = []
        for cell in sheet_ranges['A']:
            count = count + 1
            users_info.append(cell.value)

        return users_info

    def docebo_lms_login(self):
        users_info = self.reading_an_existing_file()
        token = self.login(username=users_info[1])
        cookie = self.get_cookie(token)
        self.policy_track(token, cookie)
        self.terms_track(token, cookie)
        self.get_notifications(token, cookie)
        self.get_lp(token, cookie)
        self.get_course(token, cookie)
        file_id = self.upload_file(token, cookie)
        self.upload_file_url(token, cookie, file_id)
        resp = self.submit_file_url(token, cookie, file_id)
        return resp
