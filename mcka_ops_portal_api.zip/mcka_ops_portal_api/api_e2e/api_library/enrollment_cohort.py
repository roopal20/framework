import json
import time
import uuid

import xlsxwriter
from openpyxl import Workbook, load_workbook

from ...resources.ops_portal_base_page import *

from test.mcka_ops_portal_api.resources import ADMIN_BASE_URL
from test.mcka_ops_portal_api.api_e2e.api_library.groupwork import GroupWork


class EnrollmentCohort(OpsPortalBase):
    groupwork = GroupWork()
    ec_users_enrollment_file_name = 'ec_users_enrollment.xlsx'
    transfer_users_file_name = 'transfer_cohort_users.xlsx'

    def get_wave_details(self, access_token, wc_id):
        url = f'{ADMIN_BASE_URL}api/wave_management/waves/details/{wc_id}'
        return self._get(url, access_token)

    def get_wave_cohorts(self, access_token):
        url = f'{ADMIN_BASE_URL}api/wave_management/waves/{enrolled_session_program_id}'
        return self._get(url, access_token)

    def create_wave_cohort(self, access_token, ec_code, wave_name, experience_type='Single Client'):
        create_wave_cohort_endpoint = f'{ADMIN_BASE_URL}api/wave_management/waves/{enrolled_session_program_id}'
        create_wave_cohort_params = {
            "ec_code": ec_code,
            "wave_name": wave_name,
            "description": "",
            "start_date": None,
            "end_date": None,
            "expiration_date": None,
            "client_id": "",
            "experience_type": experience_type,
            "cst_email": "",
            "order_id": "",
            "pdt_id": "",
            "near_target": None,
            "created_by": EMAIL
        }
        response = self._post(create_wave_cohort_endpoint, create_wave_cohort_params, cookie='', token=access_token)
        return response

    def edit_wave_cohort(self, access_token, wave_id, new_ec_code, new_wave_name, new_experience_type):
        create_wave_cohort_endpoint = f'{ADMIN_BASE_URL}api/wave_management/waves/{enrolled_session_program_id}'
        create_wave_cohort_params = {
            "ec_code": new_ec_code,
            "wave_name": new_wave_name,
            "description": "",
            "start_date": None,
            "end_date": None,
            "expiration_date": None,
            "client_id": "",
            "experience_type": new_experience_type,
            "cst_email": "",
            "order_id": "",
            "pdt_id": "",
            "near_target": None,
            "wave_id": wave_id
        }
        response = self._put(create_wave_cohort_endpoint, create_wave_cohort_params, cookie='', token=access_token)
        return response

    def get_enrollment_cohort_waves(self, access_token, p_id):
        url = f'{ADMIN_BASE_URL}api/wave_management/waves/{p_id}'
        return self._get(url, access_token)

    def get_wave_details_user(self, access_token, w_id):
        url = f'{ADMIN_BASE_URL}api/wave_management/waves/users/{w_id}?page=1&page_size=10'
        return self._get(url, access_token)

    def get_waves_details(self, access_token, w_id):
        url = f'{ADMIN_BASE_URL}api/wave_management/waves/details/{w_id}'
        return self._get(url, access_token)

    def get_waves_components_details(self, access_token, w_id):
        url = f'{ADMIN_BASE_URL}api/wave_management/wave/components/{w_id}'
        return self._get(url, access_token)

    def get_overview_components_details(self, access_token, p_id):
        url = f'{ADMIN_BASE_URL}api/overview/components/{p_id}?update=false&content_management=true'
        return self._get(url, access_token)

    def update_component_due_date(self, access_token, w_id):
        url = f'{ADMIN_BASE_URL}api/wave_management/wave/components/{w_id}'
        payload = {
            "components": [
                {
                    "course_id": 18690,
                    "due_date": "31-03-2023"
                },
                {
                    "course_id": 18689,
                    "due_date": None
                },
                {
                    "course_id": 18691,
                    "due_date": None
                }
            ]
        }
        return self._post(url, payload, cookie='', token=access_token)

    def get_programs_report_api(self, access_token, p_id):
        url = f'{ADMIN_BASE_URL}api/report/program/{p_id}'
        return self._get(url, access_token)

    def delete_wave_cohort(self, access_token, del_wave_id):
        url = f'{ADMIN_BASE_URL}api/wave_management/wave/{del_wave_id}'
        return self.session.delete(url, headers=self._get_headers(token=access_token))

    def upload_participants_file(
            self, token, email=None, client_name=client_value, single_client=True, password=pass_value,
            number_of_user=2, sheet_name='manage users'):
        self.create_participants_file(
            email, client_name=client_name, password=password, number_of_user=number_of_user,
            sheet_name=sheet_name, single_client=single_client)
        response = self.validate_upload_participants_file(token, enrolled_session_program_id)
        post_url = f'{ADMIN_BASE_URL}api/v2/automation/course_ops/auto_enrollment'
        params = {
            'program_id': enrolled_session_program_id,
            'is_single_client_program': single_client,
            'wave_id': wave_id
        }
        files = {'file': open(self.ec_users_enrollment_file_name, 'rb').read()}
        time.sleep(2)
        return self.session.post(post_url, files=files, headers=self._get_headers(token), data=params)

    def create_transfer_users_file(self, sheet_name='transfer cohort users', target_ec_code='', ec_code='', ec_code_column=True,
                                   valid_sheet=True):
        sheet_ranges, ws, ws1, count = self.reading_an_existing_file()
        dest_filename = self.transfer_users_file_name

        if valid_sheet:
            ws1.title = sheet_name
            for cell in sheet_ranges['A']:
                print(cell.value)
                ws1.cell(count + 1, 1, cell.value)
                ws1.cell(count + 1, 2, target_ec_code)
                count = count + 1
            ws1.cell(1, 2, 'target cohort ec_code')
        else:
            if ec_code == '' and sheet_name == 'transfer cohort users':
                ws1.title = sheet_name
                ws1.cell(1, 1, 'username')
                ws1.cell(1, 2, 'target cohort ec_code')
            elif ec_code == 'test' and sheet_name == 'abc':
                ws1.title = sheet_name
                ws1.cell(1, 1, 'username')
                ws1.cell(1, 2, 'target cohort ec_code')
            elif ec_code == 'abc' and sheet_name == 'transfer cohort users' and ec_code_column is False:
                ws1.title = sheet_name
                for cell in sheet_ranges['A']:
                    ws1.cell(count + 1, 1, cell.value)
                    ws1.cell(count + 1, 2, 'abc')
                    count = count + 1
                ws1.cell(1, 2, 'targ')
            elif ec_code == 'abc' and sheet_name == 'transfer cohort users' and ec_code_column is True:
                ws1.title = sheet_name
                for cell in sheet_ranges['A']:
                    ws1.cell(count + 1, 1, cell.value)
                    # ws1.cell(count + 1, 2, 'abc')
                    count = count + 1
                ws1.cell(1, 2, 'target cohort ec_code')

        ws.save(filename=dest_filename)
        ws.close()

    def reading_an_existing_file(self):
        student_file = self.ec_users_enrollment_file_name
        wb = load_workbook(filename=student_file)
        sheet_ranges = wb['manage users']
        ws = Workbook()
        ws1 = ws.active
        count = 0
        return sheet_ranges, ws, ws1, count

    def validate_transfer_users_file(self, token):
        url = f'{ADMIN_BASE_URL}api/dat/validate/course_ops/transfer_cohort_users'
        files = {('file', open(self.transfer_users_file_name, 'rb'))}
        return self.session.post(url, files=files, headers=self._get_headers(token))

    def upload_transfer_users_file(self, token, p_id):
        url = f'{ADMIN_BASE_URL}api/wave_management/transfer_users/{p_id}'
        payload = {'program_id': p_id}
        files = {('file', open(self.transfer_users_file_name, 'rb'))}
        return self.session.post(url, files=files, json=payload, headers=self._get_headers(token=token))

    def user_uploading_got_completed(self, transaction_id, access_token, retry=0):
        time.sleep(2)
        if retry >= 150:
            return
        response = self.task_completed(transaction_id, access_token)
        resp = self.get_content(response)
        if resp.get('done') and response.status_code == STATUS_CODE_GOOD:
            time.sleep(2)
            return resp
        else:
            return self.user_uploading_got_completed(transaction_id, access_token, retry=retry + 1)

    def upload_user_report(self, token, tr_id):
        return self._get(f'{ADMIN_BASE_URL}api/report/{tr_id}', token)

    def task_completed(self, t_id, access_token):
        url = f'{mod_base_url}progress/{t_id}'
        return self.session.get(url=url, headers=self._get_headers(access_token))

    def validate_wave_cohort_details(self, response, new_wave_id, ec_code, wave_name, experience_type):
        self.compare_expected_and_actual_result(response, success_key, true_value)
        self.compare_expected_and_actual_result(response[data_key], wave_id_key, new_wave_id)
        self.compare_expected_and_actual_result(response[data_key], ec_code_key, ec_code)
        self.compare_expected_and_actual_result(response[data_key], wave_name_key, wave_name)
        self.compare_expected_and_actual_result(response[data_key], experience_type_key, experience_type)
        return True

    def create_participants_file(self, email, password, client_name, number_of_user, sheet_name, single_client):
        start = 1
        end = start + number_of_user
        first_name = 'ntst_'
        last_name = 'user'
        random_val = uuid.uuid4().hex[0:4]
        upload_file_name = self.ec_users_enrollment_file_name
        student_file = os.path.abspath(os.path.join(os.curdir, upload_file_name))
        workbook = xlsxwriter.Workbook(student_file)
        worksheet = workbook.add_worksheet(sheet_name)
        worksheet.write('A1', 'username')
        worksheet.write('B1', 'Firstname')
        worksheet.write('C1', 'Lastname')
        worksheet.write('D1', 'Email')
        worksheet.write('E1', 'Password')
        worksheet.write('F1', 'force password change')
        worksheet.write('G1', 'client name')
        worksheet.write('H1', 'client id')
        worksheet.write('I1', 'Groupwork')
        worksheet.write('J1', 'primary experience')
        worksheet.write('K1', 'language')
        worksheet.write('L1', 'Role')
        worksheet.write('M1', 'custom field 1')
        worksheet.write('N1', 'custom field 2')
        worksheet.write('O1', 'custom field 3')
        worksheet.write('P1', 'custom field 4')
        for val in range(end):
            if email:
                email_value = email
            else:
                email_value = f'{first_name}{last_name}{val + 1}{random_val}@mailinator.com'
            worksheet.write(val + 1, 0, email_value)
            worksheet.write(val + 1, 1, first_name)
            worksheet.write(val + 1, 2, f'{last_name}{val + 1}{random_val}')
            worksheet.write(val + 1, 3, email_value)
            worksheet.write(val + 1, 4, password)
            worksheet.write(val + 1, 5, 'No')
            if single_client:
                worksheet.write(val + 1, 6, client_name)
                worksheet.write(val + 1, 7, "R10_Arbisoft_Rls10")
                if 'Test_Automation_Assignment' in new_group_work:
                    if val % 2 == 0:
                        worksheet.write(val + 1, 8, f'Group 01 - {new_group_work}')
                    else:
                        worksheet.write(val + 1, 8, f'Group 02 - {new_group_work}')
                else:
                    worksheet.write(val + 1, 8, '')
            else:
                if val % 2 == 0:
                    worksheet.write(val + 1, 6, client_name)
                    worksheet.write(val + 1, 7, "R10_Arbisoft_Rls10")
                    worksheet.write(val + 1, 8, '')
                else:
                    worksheet.write(val + 1, 6, 'Arbisoft')
                    worksheet.write(val + 1, 7, 'Release10_Arbisoft')
                    worksheet.write(val + 1, 8, '')

            worksheet.write(val + 1, 9, 'Landing Page 3')
            worksheet.write(val + 1, 10, '')
            worksheet.write(val + 1, 11, random.choices(["Observer", "Participant"])[0])
            worksheet.write(val + 1, 12, '')
            worksheet.write(val + 1, 13, '')
            worksheet.write(val + 1, 14, '')
            worksheet.write(val + 1, 15, '')

        workbook.close()

    def check_if_pending(self, details, transaction_id, status, access_token):
        if details[status] == "PENDING":
            response = self.complete_now_process_queue(transaction_id, access_token)
            if not STATUS_CODE_GOOD == response.status_code:
                raise Exception(FAILED_TO_MATCH_VALUES.format(STATUS_CODE_GOOD, response.status_code))
            return True
        else:
            return self.validate_user_uploading_response(details, transaction_id, status=transaction_status_key)

    def validate_user_uploading_response(self, response, transaction_id, status):
        self.compare_expected_and_actual_result(response, transaction_id_key, transaction_id)
        if not response[status] in ["PROCESSING", "COMPLETED", ]:
            raise Exception(FAILED_TO_MATCH_VALUES.format(response[status], "PROCESSING or COMPLETED"))
        return True

    def complete_now_process_queue(self, transaction_id, access_token):
        payload = {
            "transaction_id": transaction_id,
            "should_append_config_ids": true_value,
            "should_use_excel_data_for_password_change": true_value,
            "update_name": true_value,
            "update_lang": true_value
        }
        response = self._put(
            f'{ADMIN_BASE_URL}api/v2/automation/course_ops/auto_enrollment/{transaction_id}', payload, cookie='',
            token=access_token
        )
        return response

    def validate_upload_participants_file(self, token, p_id='', single_client=True):
        post_url = f'{ADMIN_BASE_URL}api/dat/validate/course_ops/auto_enrollment?program_id={p_id}'
        params = {
            'program_id': enrolled_session_program_id,
            'is_single_client_program': single_client,
            'wave_id': wave_id
        }
        files = {'file': open(self.ec_users_enrollment_file_name, 'rb').read()}
        time.sleep(2)
        return self.session.post(post_url, files=files, headers=self._get_headers(token), data=params)

    def validate_uploaded_new_users_in_group_works(self, response_body, transaction_id):
        assert self.compare_expected_and_actual_result(response_body, transaction_id_key, transaction_id)
        assert self.compare_expected_and_actual_result(response_body, status_key, completed_message)
        assert self.compare_expected_and_actual_result(response_body, filename_key, file_text)
        assert self.compare_expected_and_actual_result(response_body, failed_key, 0)

        assert self.compare_expected_and_actual_result(response_body[new_users_key], success_key, 3)
        assert self.compare_expected_and_actual_result(response_body[new_users_key], failed_key, 0)
        assert self.compare_expected_and_actual_result(response_body[new_users_key], errors_key, [])
        assert self.compare_expected_and_actual_result(response_body[new_users_key], total_key, 3)

        assert self.compare_expected_and_actual_result(response_body[existing_users_key], logged_in_key, 0)
        assert self.compare_expected_and_actual_result(response_body[existing_users_key], never_logged_in_key, 0)
        assert self.compare_expected_and_actual_result(response_body[existing_users_key], errors_key, [])
        assert self.compare_expected_and_actual_result(response_body[existing_users_key], total_key, 0)
        assert self.compare_expected_and_actual_result(response_body[existing_users_key], inactive_users_key, 0)
        assert self.compare_expected_and_actual_result(response_body[existing_users_key], done_key, true_value)
        assert self.compare_expected_and_actual_result(response_body[existing_users_key], success_key, 0)

        assert self.verify_key_exist_with_valid_value_type(response_body, created_at_key)
        assert self.verify_key_exist_with_valid_value_type(response_body, transaction_id_key)
        return True
