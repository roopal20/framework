import random
import re
import string
import time
import uuid
from datetime import datetime

from ...config import *

from ...resources.ops_portal_base_page import *
from ..api_library.replications import Replication


class ModifyProgramCode(Replication):
    def __init__(self):
        super().__init__()
        self.config_id = None

    def edit_program_code(self, url, token, p_id=program_id):
        self.config_id = self.get_unique_config_id()
        params = {
            new_config_id_key: self.config_id,
            program_id_key: p_id,
        }
        return self.session.post(url, json=params, headers=self._get_headers(token))

    def final_edit_program_code(self, t_id, p_id, token):
        params = {
            program_id_key: p_id,
            "retry": "false",
            transaction_id_key: t_id,
        }
        return self.session.post(url=edit_program_final, json=params, headers=self._get_headers(token))

    @staticmethod
    def get_enrolment_details(response_body):
        body = response_body["data"]
        enrolled_users = body["enrolled_users"]
        Log.info(f'got value {enrolled_users} in key enrolled_users')
        participant_users = body["participant_users"]
        Log.info(f'got value {participant_users} in key participant_users')
        return enrolled_users, participant_users

    def verify_enrollment_details(self, response_body):
        enrolled_users, participant_users = self.get_enrolment_details(response_body)
        self.compare_expected_and_actual_values(enrolled_users, 0)
        return self.compare_expected_and_actual_values(participant_users, 0)

    def validate_modify_program_code_summary(self, response_body):
        for index, summary_data in enumerate(response_body):
            self.verify_key_exist_with_valid_value_type(summary_data, "component")
            self.verify_key_exist_with_valid_value_type(summary_data, "new_name")
            self.verify_key_exist_with_valid_value_type(summary_data, "old_name")
            return self.verify_value_not_exist(summary_data, "success", None)

    def validate_modification_details(self, response_body):
        Log.info(self.config_id)
        return self.compare_expected_and_actual_result(response_body, "config_id", self.config_id)
