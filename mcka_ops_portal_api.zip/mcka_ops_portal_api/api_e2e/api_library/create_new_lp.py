import requests
import os

from ...resources.utils import build_request_headers

from ...config import SESSION, Log


class CreateNewLP:

    def __init__(self):
        self.validate_file_url = "api/dat/validate/course_prod/program_creation"
        self.create_new_lp_url = ""
        self.file_path = os.path.abspath(os.path.join(f'{os.curdir}/test/mcka_ops_portal_api/resources/excel_upload/lp_course_name_blank.xlsx'))

    def validate_lp_upload_file(self, app_url, access_token):
        Log.info(app_url)
        Log.info(self.file_path)
        Log.info(access_token)
        Log.info("Reading upload learning plan file")
        lp_upload_file = {"file": open(self.file_path, "rb").read()}
        requests_headers = build_request_headers(access_token)
        Log.debug(f"Request headers:{requests_headers}")
        response = SESSION.post(f"{app_url}{self.validate_file_url}", files=lp_upload_file, headers=requests_headers)
        Log.debug(f"Response received in validate_lp_upload_file class:{response}")
        return response
