from curses import meta
import logging
import random
import re
import string
import time
import xlsxwriter
from openpyxl import Workbook, load_workbook
from urllib import response
from ...resources import DMF_URL, DNA_URL
from ...resources.ops_portal_base_page import *


class AssignmentManagement(OpsPortalBase):

    def get_refresh_link_status(self, token):
        url = f'{ADMIN_BASE_URL}api/assignment_management/{program_id}?update=true'
        return self.session.get(url, headers=self._get_headers(token))

    def validate_refresh_link_details(self, response_body):
        data_info = response_body[data_key]
        self.verify_key_exist_with_valid_value_type(data_info, 'lp_config')
        self.verify_key_exist_with_valid_value_type(data_info, 'courses_data', list)
        self.compare_expected_and_actual_result(data_info, 'lp_config', config_id)
        assignment_info = data_info['courses_data'][2]['assignment_data'][0]
        self.verify_key_exist_with_valid_value_type(assignment_info, 'attempts', int)
        self.verify_key_exist_with_valid_value_type(assignment_info, 'id', int)
        self.compare_expected_and_actual_result(assignment_info, name_key, assignment_name)

        return self.verify_key_exist_with_valid_value_type(data_info['courses_data'][0], 'id', int)

    def get_download_new_assignments(self, token):
        return self.session.get(DNA_URL, headers=self._get_headers(token))

    def get_download_all_assignments(self, token):
        return self.session.get(DAA_URL, headers=self._get_headers(token))

    def task_completed(self, t_id, token):
        url = f'{mod_base_url}progress/{t_id}'
        return self.session.get(url=url, headers=self._get_headers(token))

    def downloading_got_completed(self, transaction_id, token, retry=0):
        time.sleep(2)
        if retry >= 150:
            return
        response = self.task_completed(transaction_id, token)
        resp = self.get_content(response)
        logging.info(resp)
        if resp.get('done') and response.status_code == STATUS_CODE_GOOD:
            time.sleep(2)
            return resp
        else:
            return self.downloading_got_completed(transaction_id, token, retry=retry + 1)

    def get_s3_url(self, transaction_id, basic_auth):
        return self._get(url=f'{ADMIN_BASE_URL}api/assignment_management/{transaction_id}/s3_url', token=basic_auth)

    def get_list(self, basic_auth):
        return self._get(url=f'{ADMIN_BASE_URL}api/assignment_management/{program_id}/list', token=basic_auth)

    def get_download_metadata_file(self, token):
        return self.session.get(DMF_URL, headers=self._get_headers(token))

    def download_metadata_file(self, token):
        response = self.session.get(DMF_URL, headers=self._get_headers(token))
        with open(metadata_file, 'wb') as out_file:
            out_file.write(response.content)
        return response

    def download_new_assignments_file(self, url):
        response = self.session.get(url)
        with open('download_new_assignments.zip', 'wb') as out_file:
            out_file.write(response.content)
        return response

    def download_all_assignments_file(self, url):
        response = self.session.get(url)
        with open('download_all_assignments.zip', 'wb') as out_file:
            out_file.write(response.content)
        return response

    def validate_list_response(self, response_body):
        data_info = response_body[data_key]
        for data in data_info:
            self.verify_key_exist_with_valid_value_type(data, 'id', int)
            self.verify_key_exist_with_valid_value_type(data, transaction_id_key, int)
            self.compare_expected_and_actual_result(data, success_key, true_value)
        return self.verify_key_exist_with_valid_value_type(data_info[0], 'triggered_by')

    def write_metadata_file(self, instructor_name, grade_val, g_status):
        student_file = metadata_file

        wb = load_workbook(student_file)
        sheet_ranges = wb['metadata']

        for cell in sheet_ranges['J']:
            cell.value = instructor_name
        for cell in sheet_ranges['K']:
            cell.value = grade_val
        for cell in sheet_ranges['L']:
            cell.value = g_status

        sheet_ranges['J1'] = 'instructor username'
        sheet_ranges['K1'] = 'grade value'
        sheet_ranges['L1'] = 'grade status'
        wb.save(student_file)

    def validate_evaluation_file(self, token, file_name):
        url = f'{ADMIN_BASE_URL}api/dat/validate/course_ops/upload_grade?update=false'
        files = {('file', open(file_name, 'rb'))}
        response = self.session.post(url, files=files, headers=self._get_headers(token))
        return response

    def validate_modify_grades_file(self, token, file_name):
        url = f'{ADMIN_BASE_URL}api/dat/validate/course_ops/modify_grade?update=true'
        files = {('file', open(file_name, 'rb'))}
        response = self.session.post(url, files=files, headers=self._get_headers(token))
        return response

    def upload_evaluation_file(self, token, file_name):
        url = f'{ADMIN_BASE_URL}api/automation/course_ops/upload_grade/{program_id}'
        files = {('file', open(file_name, 'rb'))}
        response = self.session.post(url, files=files, headers=self._get_headers(token))
        return response

    def upload_modify_grades_file(self, token, file_name):
        url = f'{ADMIN_BASE_URL}api/automation/course_ops/modify_grade/{program_id}'
        files = {('file', open(file_name, 'rb'))}
        response = self.session.put(url, files=files, headers=self._get_headers(token))
        return response

    def get_list_of_uploaded_grades(self, token):
        url = f'{ADMIN_BASE_URL}api/assignment_management/{program_id}/list_for_upload_grade'
        response = self.session.get(url, headers=self._get_headers(token))
        return response

    def validate_file_uploading_response(self, response, t_id, status):
        self.compare_expected_and_actual_result(response, transaction_id_key, t_id)
        if not response[status] in ["PROCESSING", "COMPLETED"]:
            raise Exception(FAILED_TO_MATCH_VALUES.format(response[status], "PROCESSING or COMPLETED"))
        return True

    def validate_data_response(self, response_body):
        data_info = response_body[data_key]
        for data in data_info:
            self.verify_key_exist_with_valid_value_type(data, transaction_id_key, int)
            self.verify_key_exist_with_valid_value_type(data, 'failed_rows', int)
            self.verify_key_exist_with_valid_value_type(data, 'total_rows', int)
            self.verify_key_exist_with_valid_value_type(data, 'passed_rows', int)
        return self.verify_key_exist_with_valid_value_type(data_info[0], 'triggered_by')

    def get_pending_rows_from_metadata_file(self):
        student_file = metadata_file

        wb = load_workbook(student_file)
        sheet_ranges = wb['metadata']

        pending_rows = []
        for row in sheet_ranges.values:
            pending_rows.append(row)

        # wb.save(student_file)
        return pending_rows

    def update_pending_rows_file(self, pending_rows, instructor_info, grade_info, status_info, flag=0):
        student_file = validate_metadata_file
        xwb = xlsxwriter.Workbook(student_file)
        xws = xwb.add_worksheet('metadata')

        xws.write_row(0, 0, pending_rows[0])
        xws.write_row(1, 0, pending_rows[-3])
        xws.write_row(2, 0, pending_rows[-2])
        xws.write_row(3, 0, pending_rows[-1])

        xws.write('J2', instructor_info)
        xws.write('J3', instructor_info)
        xws.write('J4', instructor_info)

        xws.write('K2', grade_info)
        xws.write('K3', grade_info)
        xws.write('K4', grade_info)

        xws.write('L2', status_info)
        xws.write('L3', status_info)
        xws.write('L4', status_info)

        if flag == 1:
            xws.write('L2', status_info)
            xws.write('L3', 'failed')
            xws.write('L4', 'failed')

        xwb.close()
