import logging
import random
import re
import string
import time
import uuid
from datetime import datetime

from test.mcka_ops_portal_api.conftest import basic_auth
from ...resources import PROGRAM_ID_NO
from ...resources.ops_portal_base_page import *


class LtiJournal(OpsPortalBase):
    def __init__(self):
        super().__init__()
        self.courses = None
        self.lp = None

    def get_response(self, keyword, value, basic_auth):
        response = self._get(rep_base_url + keyword + value, basic_auth)
        return response

    def get_lti_token(self, url, basic_auth):
        response = self._get(url=url, token=basic_auth)
        resp = self.get_content(response)
        lti_token = resp['token']
        return lti_token

    def get_lti_journal_api(self, lti_auth):
        return self._get_lti(existing_lti_url, lti_auth)

    def get_content_with_invalid_config_id(self, basic_auth):
        url = f'{ADMIN_BASE_URL}api/overview/content/lp/{invalid_value}'
        return self._get(url, basic_auth)

    def create_an_lti_lp(self, token):
        url = f'{LTI_BASE_URL}api/learning-plans/'
        payload = {
            "learning_plan_id": lti_docebo_lp_id, "learning_plan_code": f'{enrolled_session_program_name}',
            "program_name": lti_program_name, "journal_title": lti_journal_title,
            "description": "This is test journal description",
            "modified_by": f"{USER_NAME}", "created_by": f"{USER_NAME}"
        }
        return self._post_lti(url=url, params=payload, token=token)

    def edit_an_lti_lp(self, token, lti_lp_id):
        random_string = str(uuid.uuid4().hex[0:4])
        url = f'{LTI_BASE_URL}api/learning-plans/{lti_lp_id}'
        payload = {
            "learning_plan_id": lti_docebo_lp_id, "learning_plan_code": f'{enrolled_session_program_name}',
            "program_name": lti_program_name, "journal_title": lti_journal_title,
            "description": f"This is test journal description {random_string}",
            "modified_by": f"{USER_NAME}", "created_by": f"{USER_NAME}"
        }
        return self._patch_lti(url=url, params=payload, token=token)

    def delete_an_lti_journal(self, basic_auth, lti_lp_id):
        url = f'{ADMIN_BASE_URL}api/lti/journal/lp/{lti_lp_id}'
        return self._delete(url=url, token=basic_auth)

    def validate_lp_details_from_scorms(self, response_body, lp_id=lp_config_id, c_id=config_id):
        lp_keys = ["name", "description"]
        lp_details = response_body["data"]["learning_plan"]
        self.compare_expected_and_actual_result(lp_details, "id", lp_id)
        Log.info("lp id in json matched with actual id provided")

        self.compare_expected_and_actual_result(lp_details, "code", c_id)
        Log.info("code key exist with value as config id that we have saved")

        self.verify_keys_exist_with_valid_value_type(lp_details, lp_keys)
        Log.info("lp name and description key exist and have valid data available and of type string")

        return lp_details

    def validate_existing_lti_lps_response(self, response_body):
        lps_info = response_body[data_key]['items']
        for lp in lps_info:
            lps_info_keys_string = ["learning_plan_code", "journal_id", "program_name", "journal_title", "modified_by", 'created', 'created_by', "description", 'modified', "last_refresh"]
            lps_info_keys_int = ["id", "learning_plan_id"]
            self.verify_keys_exist_with_valid_value_type(lp, lps_info_keys_string)
            self.verify_keys_exist_with_valid_value_type(lp, lps_info_keys_int, int)
            self.verify_key_exist_with_valid_value_type(lp, 'is_replicated', bool)

        return self.verify_key_exist_with_valid_value_type(lps_info[0], 'id', int)

    def validate_newly_created_lti_lp_response(self, response_body):
        lps_info = response_body[data_key]

        lps_info_keys_string = ["learning_plan_code", "journal_id", "program_name", "journal_title", "modified_by", 'created', 'created_by', "description", 'modified', "last_refresh"]
        lps_info_keys_int = ["id", "learning_plan_id"]
        self.verify_keys_exist_with_valid_value_type(lps_info, lps_info_keys_string)
        self.verify_keys_exist_with_valid_value_type(lps_info, lps_info_keys_int, int)
        self.verify_key_exist_with_valid_value_type(lps_info, 'is_replicated', bool)

        return self.verify_key_exist_with_valid_value_type(lps_info, 'id', int)

    def validate_components_info_response(self, response_body):
        components_info = response_body[data_key]['components']
        for component in components_info:
            component_info_keys_string = ["title", "course_type", "code", "page_id"]
            component_info_keys_int = ["id", "docebo_id", "program_id", "course_sequence_num_in_lp"]
            self.verify_keys_exist_with_valid_value_type(component, component_info_keys_string)
            self.verify_keys_exist_with_valid_value_type(component, component_info_keys_int, int)
            self.verify_key_exist_with_valid_value_type(component, 'connected', bool)
            self.verify_key_exist_with_valid_value_type(component, 'is_exisiting_page', bool)

        return self.verify_key_exist_with_valid_value_type(components_info[0], 'id', int)

    def validate_newly_created_page_response(self, response_body):
        pages_info = response_body[data_key]

        pages_info_keys_string = ["journal_title", "course_code", "page_id", "course_title", "modified", 'created', 'created_by', "description", 'modified_by', "journal_type"]
        pages_info_keys_int = ["id", 'course_id', "lp", "training_material_id", "course_sequence_num_in_lp"]
        self.verify_keys_exist_with_valid_value_type(pages_info, pages_info_keys_string)
        self.verify_keys_exist_with_valid_value_type(pages_info, pages_info_keys_int, int)

        return self.verify_key_exist_with_valid_value_type(pages_info, 'id', int)

    def validate_training_materials_response(self, response_body):
        pages_info = response_body[data_key]

        pages_info_keys_string = ["journal_title", "course_code", "page_id", "course_title", "modified", 'created', 'created_by', "description", 'modified_by', "journal_type"]
        pages_info_keys_int = ["id", 'course_id', "training_material_id", "course_sequence_num_in_lp"]
        self.verify_keys_exist_with_valid_value_type(pages_info, pages_info_keys_string)
        self.verify_keys_exist_with_valid_value_type(pages_info, pages_info_keys_int, int)

        return self.verify_key_exist_with_valid_value_type(pages_info, 'id', int)

    def validate_newly_created_prompt_response(self, response_body):
        prompts_info = response_body[data_key]

        prompts_info_keys_string = ["prompt", "prompt_id", "modified", 'created', 'created_by', 'modified_by']
        prompts_info_keys_int = ["id", 'journal_page']
        self.verify_keys_exist_with_valid_value_type(prompts_info, prompts_info_keys_string)
        self.verify_keys_exist_with_valid_value_type(prompts_info, prompts_info_keys_int, int)
        self.verify_key_exist_with_valid_value_type(prompts_info, 'is_required', bool)

        return self.verify_key_exist_with_valid_value_type(prompts_info, 'id', int)

    def get_lp_content_library_details(self, lti_auth):
        url = f'{LTI_BASE_URL}api/learning-plans/{lti_lp_id}'
        return self._get_lti(url, lti_auth)

    def get_lp_journal_pages_search_details(self, lti_auth):
        url = f'{LTI_BASE_URL}api/journal-pages/?lp_id={lti_lp_id}&search='
        return self._get_lti(url, lti_auth)

    def get_refresh_components(self, basic_auth):
        url = f'{ADMIN_BASE_URL}api/lti/journal/lp/{lti_lp_id}/components?update=true'
        return self._get(url, basic_auth)

    def create_a_new_page(self, basic_auth, course_payload, j_type="standard"):
        url = f'{ADMIN_BASE_URL}api/lti/journal/create/page'
        payload = {
            "course": course_payload, "page_title": "New Page Test", "page_description": "Page Description",
            "journal_type": j_type, "journal_id": f"{lti_lp_id}", "modified_by": f"{USER_NAME}",
            "created_by": f"{USER_NAME}"
        }
        return self._post(url=url, params=payload, cookie='', token=basic_auth)

    def get_journal_pages_tms_count(self, lti_auth, page_id):
        url = f'{LTI_BASE_URL}api/journal-pages/{page_id}?search='
        return self._get_lti(url, lti_auth)

    def edit_newly_created_page(self, basic_auth, course_payload, page_id, tm_id, j_type="standard"):
        random_string = str(uuid.uuid4().node)
        url = f'{ADMIN_BASE_URL}api/lti/journal/{page_id}'

        payload = {
            "course": course_payload, "page_title": "New Page Test", "page_description": f"Page Description {random_string}",
            "journal_type": j_type, "journal_id": lti_lp_id, "modified_by": f"{USER_NAME}", "created_by": f"{USER_NAME}",
            "training_material_id": tm_id
        }
        return self._put(url=url, params=payload, cookie='', token=basic_auth)

    def get_journal_pages_prompts(self, lti_auth, page_id):
        url = f'{LTI_BASE_URL}api/journal-prompts/?page_id={page_id}&search='
        return self._get_lti(url, lti_auth)

    def delete_newly_created_page(self, basic_auth, page_id):
        url = f'{ADMIN_BASE_URL}api/lti/journal/{page_id}'
        return self._delete(url, basic_auth)

    def create_a_new_prompt(self, lti_auth, sequence, page_id, is_required=True):
        url = f'{LTI_BASE_URL}api/journal-prompts/'
        payload = {
            "prompt": "This is a test prompt one", "journal_page": f"{page_id}", "sequence_number": sequence + 1,
            "is_required": is_required, "modified_by": f"{USER_NAME}", "created_by": f"{USER_NAME}"
        }
        return self._post_lti(url, payload, lti_auth)

    def edit_newly_created_prompt(self, lti_auth, sequence, prompt_id, page_id, is_required=True):
        random_string = str(uuid.uuid4().node)
        url = f'{LTI_BASE_URL}api/journal-prompts/{prompt_id}'
        payload = {
            "prompt": f"This is a test prompt one {random_string}", "journal_page": f"{page_id}",
            "sequence_number": sequence, "is_required": is_required, "modified_by": f"{USER_NAME}"
        }
        return self._put_lti(url, payload, lti_auth)

    def delete_prompt(self, lti_auth, prompt_id):
        url = f'{LTI_BASE_URL}api/journal-prompts/{prompt_id}'
        return self._delete_lti(url, lti_auth)
