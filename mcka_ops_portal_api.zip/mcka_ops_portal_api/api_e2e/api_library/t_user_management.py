import json

from ...resources.ops_portal_base_page import *

from test.mcka_ops_portal_api.resources import ADMIN_BASE_URL


class TUserManagement(OpsPortalBase):

    def get_program_report(self, access_token, program_id):
        url = f'{ADMIN_BASE_URL}api/report/program/{program_id}'
        response = self._get(url, access_token)
        return response

    def create_test_user_management(self, access_token, user_id_start):
        create_test_user_management_endpoint = f'{ADMIN_BASE_URL}api/automation/course_prod/test_users_creation/{enrolled_session_program_id}'
        create_test_user_management_params = {
            "primary_experience": "Landing Page 0",
            "user_id_start": user_id_start,
            "users_count": 2,
            "is_default_experience": False,
            "branch_id": "Default",
            "learning_plans": []}
        response = self._post(create_test_user_management_endpoint, create_test_user_management_params, cookie='',
                              token=access_token)
        return response

    def create_new_test_user_management(self, access_token, user_id_start, transaction_id):
        create_new_test_user_management_endpoint = \
            f'{ADMIN_BASE_URL}api/automation/course_prod/test_users_creation/{transaction_id}'
        create_new_test_user_management_params = {
            "primary_experience": "Landing Page 0",
            "user_id_start": user_id_start,
            "users_count": 2,
            "branch_id": "Default"
        }
        response = self._put(create_new_test_user_management_endpoint, create_new_test_user_management_params,
                             cookie='', token=access_token)
        return response

    def create_test_user_with_new_learning_plan_exp(self, access_token, transaction_id, user_id_start,
                                                    primary_exp='Landing Page 1', lp=[]):
        create_test_user_learng_ex_endpoint = \
            f'{ADMIN_BASE_URL}api/automation/course_prod/test_users_creation/{transaction_id}'
        create_new_test_user_management_lex_params = {
            "primary_experience": primary_exp,
            "learning_plans": lp,
            "user_id_start": user_id_start,
            "users_count": 2,
            "branch_id": "Default"
        }
        response = self._put(create_test_user_learng_ex_endpoint, create_new_test_user_management_lex_params, cookie='',
                             token=access_token)
        return response

    def create_test_user_with_new_learning_plan(self, access_token, transaction_id, user_id_start,
                                                primary_exp='Landing Page 1'):
        create_test_user_with_new_lp_endpoint = \
            f'{ADMIN_BASE_URL}api/automation/course_prod/test_users_creation/{transaction_id}'
        create_test_user_with_new_lp_params = {
            "primary_experience": primary_exp,
            "learning_plans": ["REP_TEST_OCT22"],
            "user_id_start": user_id_start,
            "users_count": 2,
            "branch_id": "Default"
        }
        response = self._put(create_test_user_with_new_lp_endpoint, create_test_user_with_new_lp_params, cookie='',
                             token=access_token)
        return response

    def get_api_report_transaction_id(self, access_token, transaction_id):
        report_t_id_endpoint = f'{ADMIN_BASE_URL}api/report/{transaction_id}'
        response = self._get(report_t_id_endpoint, access_token)
        return response

    @staticmethod
    def get_users_and_users_count(response, primary_exp='Landing Page 0'):
        users_info = response['data'][primary_exp]
        users = []
        for i in users_info:
            users.append(i['user'])
        users_count = len(users)
        return users, users_count

    def delete_users(self, access_token, user_, transaction_id):
        delete_users_endpoint = \
            f'{ADMIN_BASE_URL}api/automation/course_prod/test_users_creation/{transaction_id}/delete'
        delete_users_params = {
            "users": user_
        }
        response = self._put(delete_users_endpoint, delete_users_params, cookie='', token=access_token)
        return response

    def deactivate_users(self, access_token, user_, transaction_id):
        deactivate_users_endpoint = \
            f'{ADMIN_BASE_URL}api/automation/course_prod/test_users_creation/{transaction_id}/deactivate'
        deactivate_users_params = {
            "users": user_
        }
        response = self._put(deactivate_users_endpoint, deactivate_users_params, cookie='', token=access_token)
        return response

    def activate_users(self, access_token, user_, transaction_id):
        activate_users_endpoint = \
            f'{ADMIN_BASE_URL}api/automation/course_prod/test_users_creation/{transaction_id}/activate'
        activate_users_params = {
            "users": user_
        }
        response = self._put(activate_users_endpoint, activate_users_params, cookie='', token=access_token)
        return response

    def update_users_password(self, access_token, user_, transaction_id):
        url = f'{ADMIN_BASE_URL}api/automation/course_prod/test_users_creation/{transaction_id}/update'
        params = {
            "users": user_,
            "reset": True,
            "language": ""
        }
        response = self._put(url, params, cookie='', token=access_token)
        return response

    def validate_created_updated_users_response(self, users_response, user_id_start, status_value, new_lp='',
                                                branch_name='Demo', additionally_enrolled_in=''):
        for index, user in enumerate(users_response):
            if new_lp:
                self.compare_expected_and_actual_result(
                    user, user_key, f'Test{index+user_id_start}-{enrolled_session_program_name}-{new_lp}@mckinsey.com')
            else:
                self.compare_expected_and_actual_result(
                    user, user_key, f'Test{index + user_id_start}-{enrolled_session_program_name}@mckinsey.com')
            self.compare_expected_and_actual_result(user, password_key, pass_value)
            self.compare_expected_and_actual_result(user, language_key, en_lang)
            self.compare_expected_and_actual_result(user, branch_key, branch_name)
            self.compare_expected_and_actual_result(user, 'additionally enrolled in', additionally_enrolled_in)
            self.compare_expected_and_actual_result(user, status_key, status_value)

        return True
