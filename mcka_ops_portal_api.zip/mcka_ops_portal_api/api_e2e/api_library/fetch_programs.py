import requests
from ...resources.utils import build_request_headers

from ...config import SESSION, Log


class FetchPrograms:

    def __init__(self):
        self.fetchProgram_url = "api/program/course_prod"

    def fetch_all_programs(self, app_url, access_token):
        payload = {'search': "", 'page': 0,
                   'stage': "STAGE_IN_BUILD,STAGE_LAUNCHED,STAGE_LAUNCH_PREP,STAGE_QA,STAGE_REPLICATED,STAGE_UNKNOWN"}
        Log.debug(f"Fetch Programs Payload :{payload}")
        requests_headers = build_request_headers(access_token)
        Log.debug(f"Request headers:{requests_headers}")
        response = SESSION.get(f"{app_url}{self.fetchProgram_url}", params=payload, headers=requests_headers)
        Log.debug(f"Response in fetchProgram class:{response}")
        return response
