import logging
import random
import re
import string
import time
import uuid
from datetime import datetime
from ...resources import PROGRAM_ID_NO
from ...resources.ops_portal_base_page import *


class Replication(OpsPortalBase):
    def __init__(self):
        super().__init__()
        self.courses = None
        self.lp = None

    def get_response(self, keyword, value, basic_auth):
        response = self._get(rep_base_url + keyword + value, basic_auth)
        return response

    @staticmethod
    def get_keyword_from_config_id():
        return config_id[len(config_id) // 2:]

    def validate_lp_details_from_scorms(self, response_body, lp_id=lp_config_id, c_id=config_id):
        lp_keys = ["name", "description"]
        random_string_f, random_string_s = self._get_random_strings()
        current_month, current_year = self.get_current_month_and_year()
        lp_details = response_body["data"]["learning_plan"]
        self.compare_expected_and_actual_result(lp_details, "id", lp_id)
        Log.info("lp id in json matched with actual id provided")

        self.compare_expected_and_actual_result(lp_details, "code", c_id)
        Log.info("code key exist with value as config id that we have saved")

        self.verify_keys_exist_with_valid_value_type(lp_details, lp_keys)
        Log.info("lp name and description key exist and have valid data available and of type string")
        lp_details.update({'code': f"{random_string_f}_{random_string_s}_{current_month}{current_year}"})
        return lp_details

    def validate_courses_details_from_scorms(self, response_body, c_id=config_id):
        course_keys = ["image", "course_id", "course_name"]
        courses = response_body["data"]["courses"]
        for course_key, course in zip(course_keys, courses):
            self.verify_value_exist_in_a_list(course["course_type"], course_types)
            Log.info('course_type key exist for each course and have either e-learning or classroom as type')
            self.compare_expected_and_actual_result(course, "course_code", c_id)
            Log.info("course_code key exist for each course and have config id of program in it")
            self.verify_key_exist_with_valid_value_type(course, course_key)
            Log.info("each course contains image, course_id and course_name")
        return courses

    def validate_parent_id_details(self, lo_details):
        keys = ["new_project_id", "original_project_id"]
        k_values = [new_project_id, new_project_id]
        return self.compare_expected_and_actual_results(lo_details, keys, k_values)

    def validate_lo_details(self, response_body):
        course_lo = response_body["data"]["courses"][0]["lo"][0]
        self.verify_key_exist_with_valid_value_type(course_lo, "id")
        self.compare_expected_and_actual_results(
            course_lo, ["new_project_id", "original_project_id"], [new_project_id, new_project_id]
        )
        return self.compare_expected_and_actual_results(course_lo, parent_id_keys, parent_id_values)

    def validate_lo_details_from_each_course(self, response_body, parent_id):
        courses = response_body["data"]["courses"]
        for course in courses:
            course_lo = course["lo"][0]
            course.update({'isCourseValidated': true_value})
            course.update({'selected': true_value})
            course_lo.update({"selected": true_value})
            course_lo.update({"isValidating": false_value})
            if course['course_type'] == "classroom":
                course_lo.update({"new_project_id": new_project_id})
                course_lo.update({"isScorm": true_value})
                if parent_id:
                    course_lo.update({"elucidatSelect": "parent"})
                else:
                    course_lo.update({"elucidatSelect": "new"})
                course_lo.update({"elucidatInput": new_project_id})
            else:
                course_lo.update({"isScorm": false_value})

        return courses

    def validate_default_channel_details(self, response_body):
        channel = response_body["data"][0]
        channel_keys = ["channel_id", "docebo_id"]
        self.verify_keys_exist_with_valid_value_type(channel, channel_keys, int)
        Log.info("both channel id and docebo ids exist having valid int values")
        Log.info(channel["name"])
        return self.compare_expected_and_actual_result(channel, "name", channel_name)

    def validate_default_channel_assets(self, response_body):
        assets = response_body["data"][0]["training_materials"]
        for each_asset in assets:
            self.verify_value_exist_in_a_list(each_asset["type"], assets_types)
            self.verify_key_exist_with_valid_value_type(each_asset, "name")

        return True

    def validate_program_information(self, response_body):
        keys = [test_users_key, default_experience_key, experience_key]
        values_to_match = [0, default_experience_value, landing_page_value]
        return self.compare_expected_and_actual_results(response_body, keys, values_to_match)

    def verify_no_channel_found(self, response_body):
        return self.verify_value_not_exist(response_body, "data", [])

    @staticmethod
    def get_current_month_and_year():
        current_month = datetime.now().strftime('%B')
        current_year = datetime.now().strftime('%Y')
        return current_month, current_year

    def get_unique_config_id(self):
        current_month, current_year = self.get_current_month_and_year()
        random_string_f, random_string_s = self._get_random_strings()
        return f'{random_string_f}_{random_string_s}_{current_month}{current_year}'

    def start_replication(self, token, lp_id, course_id, s_cid, prog_id, channel_exist, new_channel_name,
                          ch_id=channel_id_value, ch_name=source_channel_name, link_assets=False):
        current_month, current_year = self.get_current_month_and_year()
        random_string_f, random_string_s = self._get_random_strings()

        if channel_exist is False:
            channel_info = {}

        else:
            channel_info = {
                "channel_id": ch_id,
                "source_channel_name": ch_name,
                "add_visibility_only": false_value,
                "new_channel_name": new_channel_name,
                "link_assets": link_assets
            }

        payload = {
            "channel_config": channel_info,
            "courses": course_id,
            "destination_cid": f"[DELETE]{random_string_f}_{random_string_s}_{current_month}{current_year}",
            "learning_plan": lp_id,
            "isScormValidated": false_value,
            "program_id": prog_id,
            "selectAll": true_value,
            "source_cid": s_cid
        }
        url = rep_base_url + 'dat/' + 'replicate'
        return self.session.post(url, json=payload, headers=self._get_headers(token))

    def task_completed(self, t_id, token, modification=False):
        if modification:
            url = f'{mod_base_url}progress/{t_id}'
        else:
            url = f'{rep_base_url}progress/{t_id}'
        return self.session.get(url=url, headers=self._get_headers(token))

    @staticmethod
    def get_program_id(response_body):
        return response_body['program_id']

    def replication_completed(self, task_key, token, retry=0, modification=False):
        time.sleep(2)
        if retry >= 150:
            return
        response = self.task_completed(task_key, token, modification=modification)
        resp = self.get_content(response)
        logging.info(resp)
        if resp.get('done') and response.status_code == STATUS_CODE_GOOD:
            time.sleep(2)
            return resp
        else:
            return self.replication_completed(task_key, token, retry=retry + 1, modification=modification)

    def verify_replicated_program_details(self, response_body):
        keys = ["percentage", "estimated_time_left"]
        values = [100, 0]
        self.compare_expected_and_actual_results(response_body, keys, values)
        return self.verify_key_exist_with_valid_value_type(response_body, "replicated_program_id", int)

    def verify_channel_details(self, response_body):
        return self.verify_value_not_exist(response_body['report'], "channels", {})

    def verify_no_course_available(self, response_body):
        return self.verify_value_not_exist(response_body['data'], "courses", [])

    def verify_channel_content_is_empty(self, response_body):
        return self.verify_value_not_exist(response_body['report'], "channel_content", [])

    def verify_channel_got_created(self, response_body, new_channel_name=source_channel_name):
        response = response_body['report']['channels']
        keys = ["source_channel_name", "status", "channel_name"]
        k_values = [source_channel_name, "SUCCESS", new_channel_name]
        self.compare_expected_and_actual_results(response, keys, k_values)
        return self.verify_key_exist_with_valid_value_type(response, "docebo_id", int)

    def verify_channel_got_created_with_content(self, response_body):
        channel_content_info = response_body['report']['channel_content']
        for channel_content in channel_content_info:
            channel_content_keys_string = ['channel_content_name', 'channel_content_type', 'status']
            keys = ["status", 'linked_status', 'metadata_success', 'in_progress']
            k_values = ["SUCCESS", true_value, true_value, false_value]
            self.compare_expected_and_actual_results(channel_content, keys, k_values)
            self.verify_keys_exist_with_valid_value_type(channel_content, channel_content_keys_string)
            self.verify_value_exist_in_a_list(channel_content['channel_content_type'], assets_types_info)
            self.verify_value_exist_in_a_list(channel_content['asset_id'], assets_ids)
            self.verify_value_exist_in_a_list(channel_content['channel_content_type_id'], assets_types_ids)
        return self.verify_key_exist_with_valid_value_type(channel_content_info[0], 'channel_id', int)

    def verify_similar_id_exist(self, response_body):
        return self.verify_value_exist_in_a_list(config_id.upper(), response_body['similarIds'])

    def generate_transaction_id(self, basic_auth, lp_id, con_id, p_id, channel_exist=False,
                                new_channel_name="", link_assets=False, parent_id=False
                                ):
        response = self.get_response(f'docebo/{lp_id}', scorm_api, basic_auth)
        response_body = self.get_content(response)
        self.courses = courses_details = self.validate_lo_details_from_each_course(response_body, parent_id)

        self.lp = lp_details = self.validate_lp_details_from_scorms(
            response_body, lp_id=lp_id, c_id=con_id
        )
        rep_response = self.start_replication(
            token=basic_auth, course_id=courses_details,
            lp_id=lp_details, prog_id=p_id, s_cid=con_id, channel_exist=channel_exist, new_channel_name=new_channel_name,
            link_assets=link_assets
        )
        rep_response_body = self.get_content(rep_response)
        Log.info(rep_response_body)
        status_code = self.get_status_code(rep_response)
        Log.info(f"status code: {status_code}")
        if STATUS_CODE_GOOD == status_code:
            return self.get_transaction_id(rep_response_body)

    @staticmethod
    def get_program_id_from_rep_success(response_body):
        return response_body['replicated_program_id']

    def create_channel_name(self):
        random_string = str(uuid.uuid4().node)
        random_string_f, random_string_s = self._get_random_strings()
        current_month, current_year = self.get_current_month_and_year()
        return re.findall(r'\w+', f"Channel_{random_string_f}_{random_string_s}_"
                                  f"{current_month}{current_year}_{random_string}")[0]

    def validate_replication_details(self, response_body, p_id):
        for item in response_body['items']:
            if item.get(PROGRAM_ID) == p_id:
                self.verify_entry(item, replicated_key, true_value)
                return self.compare_expected_and_actual_result(item, stage_key, stage_value)

    def validate_lp_details(self, response_body):
        process = len(response_body['process']) == 9
        Log.info(f"process count match or not: {process}")
        lp = response_body['report']['learning_plan']
        self.verify_entry(lp, success_key, true_value)
        Log.info("lp got replicated successfully")
        expected_lp = {
            "id": lp["original_docebo_id"],
            "name": lp["name"],
            "description": lp["description"],
            "code": lp["code"]
        }
        Log.info(expected_lp)
        Log.info(self.lp)
        results = expected_lp == self.lp
        if not results:
            raise Exception(FAILED_TO_MATCH_VALUES.format(expected_lp, self.lp))
        return results

    def validate_meta_data(self, response_body, k_values):
        metadata = response_body['report']['metadata']
        keys = ["source_config_id", "source_program_id"]
        return self.compare_expected_and_actual_results(metadata, keys, k_values)

    def verify_group_got_created(self, response_body):
        return self.verify_entry(response_body['report']["group"], success_key, true_value)

    def verify_enrollment_rule_details(self, response_body):
        response = response_body['report']['enrollment_rule']
        keys = ["activation_success", "lp_assign_success", "group_assign_success", "creation_success"]
        self.verify_entries(response, keys, true_value)
        return self.verify_key_exist_with_valid_value_type(response, "rule_name")

    def verify_courses_got_created(self, response_body):
        keys = [success_key, "updated_with_config_id"]
        keys_list = ["source_docebo_id", "docebo_id", "id"]
        response = response_body['report']['courses']
        for course, actual_course in zip(response, self.courses):
            self.verify_entries(course, keys, true_value)
            self.verify_value_exist_in_a_list(course["type"], course_types)
            self.compare_expected_and_actual_result(course, 'name', actual_course['course_name'])
            self.verify_keys_exist_with_valid_value_type(course, keys_list, int)
        return response

    def validate_replication_timeline_response(self, response_body):
        timeline_info = response_body['data']
        for program in timeline_info:
            timeline_info_keys_string = ['created_at', 'created_by', 'destination_config_id']
            keys = ['status', 'program_sub_type', 'source_program_id', 'source_config_id']
            values = ['COMPLETED', 'REPLICATION', program_id, config_id]
            self.compare_expected_and_actual_results(program, keys, values)
            self.verify_keys_exist_with_valid_value_type(program, timeline_info_keys_string)

        return self.verify_key_exist_with_valid_value_type(timeline_info[0], 'id', int)
