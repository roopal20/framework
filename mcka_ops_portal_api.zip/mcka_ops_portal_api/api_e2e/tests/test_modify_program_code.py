from ..api_library.modify_program_code import ModifyProgramCode
from ...config import *
import pytest


@pytest.mark.DEMO_PROD
class TestModifyProgramCodeScenarios:
    modify_program_code = ModifyProgramCode()
    logger = Log

    def test_validate_the_response_of_modify_existing_program_with_new_unique_id(self, basic_auth):
        """
         Validate Modify existing ID by hitting api/dat/unique_config_id/old_program_id and passing a new unique id
        - Status code to be 200
        - success key exist with value true
        - message key exist with value SUCCESS
        - unique key exist with value true
        """
        url = f'{old_program_api}{self.modify_program_code.get_unique_config_id()}'
        response = self.modify_program_code._get(url=url, token=basic_auth)
        response_body = self.modify_program_code.get_content(response)
        self.logger.info(response_body)
        status_code = self.modify_program_code.get_status_code(response)
        self.logger.info(f"status code: {status_code}")
        assert STATUS_CODE_GOOD == status_code
        assert self.modify_program_code.verify_entry(response_body, success_key, true_value)
        self.logger.info(f"success key exist having value: {true_value}")

        assert self.modify_program_code.compare_expected_and_actual_result(response_body, message_key, success_message)
        self.logger.info(f"message key found having value as: {success_message}")
        assert self.modify_program_code.compare_expected_and_actual_result(response_body, unique_key, true_value)
        self.logger.info(f"a key named as unique exist with value to be {true_value}")

    def test_validate_the_response_of_modify_existing_program_with_existing_config_id(self, basic_auth):
        """
        Validate Modify existing ID by hitting api/dat/unique_config_id/old_program_id and passing some existing id
        - Status code to be 409
        - success key exist with value true
        - message key exist with value "The program with this name already exists. Please search the home page with this Config ID to make any updates to this program."
        - unique key exist with value false
        """
        response = self.modify_program_code._get(
            url=mod_base_url + 'dat/unique_config_id/' + config_id, token=basic_auth
        )
        response_body = self.modify_program_code.get_content(response)
        self.logger.info(response_body)
        status_code = self.modify_program_code.get_status_code(response)
        self.logger.info(f"status code: {status_code}")
        assert CONFLICT_RESPONSE_STATUS_CODE_409 == status_code
        assert self.modify_program_code.verify_entry(response_body, success_key, true_value)
        self.logger.info(f"success key exist having value: {true_value}")

        assert self.modify_program_code.compare_expected_and_actual_result(response_body, message_key,
                                                                           modify_program_error_message)
        self.logger.info(f"message key found having value as: {modify_program_error_message}")
        assert self.modify_program_code.compare_expected_and_actual_result(response_body, unique_key, false_value)
        self.logger.info(f"a key named as unique exist with value to be {false_value}")

    def test_validate_the_response_of_edit_program_code_and_response_of_summary_api(self, basic_auth):
        """
        Note: we are hitting 2 apis in this block as 2nd api is dependent on the 1st one
        1. Hit api/dat/course_prod/edit_program_code to validate edit is performed successfully
        - status code to be 200
        - is_imported_from_docebo key exist with value as false
        - success key exist with value true transaction_id key exist with valid int value

        2. Hit summary api (api/report/4087) and you will get a list of objects like LP, courses,
        groups and enrollment rules. Validate:

        - status code to be 200
        - iterate over the list and validate we have old_name, new_name and component keys for every object and have
          valid values that we compare with the data given
        - for group and enrollment user values must be same
        """
        response = self.modify_program_code.edit_program_code(url=edit_program, token=basic_auth)
        response_body = self.modify_program_code.get_content(response)
        self.logger.info(response_body)
        status_code = self.modify_program_code.get_status_code(response)
        self.logger.info(f"status code: {status_code}")
        assert STATUS_CODE_GOOD == status_code
        assert self.modify_program_code.verify_entry(response_body, is_imported_from_docebo_key, false_value)
        self.logger.info(f"{is_imported_from_docebo_key} key exist having value: {false_value}")
        assert self.modify_program_code.verify_entry(response_body, success_key, true_value)
        self.logger.info(f"{success_key} key exist having value: {true_value}")
        t_id = self.modify_program_code.get_transaction_id(response_body)
        assert t_id
        self.logger.info(f"t_id key exist with value {t_id} in it")

        summary_response = self.modify_program_code._get(
            url=f'{mod_base_url}report/{t_id}', token=basic_auth
        )
        response_body = self.modify_program_code.get_content(summary_response)
        self.logger.info(response_body)
        status_code = self.modify_program_code.get_status_code(summary_response)
        self.logger.info(f"status code: {status_code}")
        assert STATUS_CODE_GOOD == status_code

        assert self.modify_program_code.validate_modify_program_code_summary(response_body)

    def test_validate_the_response_of_overview_api_with_update_false_parameter(self, basic_auth):
        """
        Hit api/overview/users/enrolled/1856?update=false to validate users enrolments
        - Status code to be 200
        - A dict named as data exist having 2 keys enrolled_users and participant_users that must be 0
         if no user is not registered for example participant_users: 0, enrolled_users: 0
        """
        response = self.modify_program_code._get(
            url=f'{mod_base_url}overview/users/enrolled/{program_id_already_rep}', token=basic_auth
        )

        response_body = self.modify_program_code.get_content(response)
        self.logger.info(response_body)
        status_code = self.modify_program_code.get_status_code(response)
        self.logger.info(f"status code: {status_code}")
        assert STATUS_CODE_GOOD == status_code
        self.modify_program_code.verify_enrollment_details(response_body)
        assert self.modify_program_code.verify_entry(response_body, success_key, true_value)
        self.logger.info("success key exist having some value in it")

    def test_validate_the_response_of_overview_api_with_update_true_parameter(self, basic_auth):
        """
        Note: once this case is fixed from the dev we can use simple program id=1912
         to validate this case as that program contain users present in it

       Hit an api/overview/users/enrolled/1856?update=true to validate users enrollements
       - status code to be 200
       - a dict named as data exist having 2 keys enrolled_users and participant_users that must not be 0 i.e.
       participant_users: 1 enrolled_users: 1
       """
        response = self.modify_program_code._get(
            url=f'{mod_base_url}overview/users/enrolled/{program_id}', token=basic_auth
        )

        response_body = self.modify_program_code.get_content(response)
        self.logger.info(response_body)
        status_code = self.modify_program_code.get_status_code(response)
        self.logger.info(f"status code: {status_code}")
        assert STATUS_CODE_GOOD == status_code
        # pytest.xfail("Failing because of Bug ticket MAPOAS-1487")

        enrolment_details = self.modify_program_code.get_enrolment_details(response_body)
        assert participant_users_value_zero < enrolment_details[1]
        self.logger.info(f"{participant_users_key} key exist having value: {participant_users_value_zero}")
        assert self.modify_program_code.verify_entry(response_body, success_key, true_value)
        self.logger.info("success key exist having some value in it")
        if enrolment_details[0] == 0:
            pytest.xfail("Failing because of Bug ticket MAPOAS-1487")
        assert enrolled_users_value_zero < enrolment_details[0]
        self.logger.info(f"{enrolled_users_key} key exist having value: {enrolled_users_value_zero}")

    def test_validate_the_response_of_successful_modification(self, basic_auth):
        """
        Validate user is able to successfully Modify a replicated program by hitting submit api
         (/api/automation/course_prod/edit_program_code) to modify the program in response we must get
        -status code to be 200
        -config_id key exist with updated value
        -program_id key exist and has unique value must not match with the one we modify from
        -groups key exist with value as 0
        -last_activity with value as edit_program_code
        -stage key with value STAGE_REPLICATED
        -replicated key with value true
        -updated_by key exist with valid name
        -test_users key exist with value
        -default_experience key exist with right landing page option
        -extended_enterprise key exist with value Default
        """
        response = self.modify_program_code.edit_program_code(url=edit_program, token=basic_auth)
        response_body = self.modify_program_code.get_content(response)
        self.logger.info(response_body)
        status_code = self.modify_program_code.get_status_code(response)
        self.logger.info(f"status code: {status_code}")
        assert STATUS_CODE_GOOD == status_code

        assert self.modify_program_code.verify_entry(response_body, is_imported_from_docebo_key, false_value)
        self.logger.info(f"{is_imported_from_docebo_key} key exist having value: {false_value}")
        assert self.modify_program_code.verify_entry(response_body, success_key, true_value)
        self.logger.info(f"{success_key} key exist having value: {true_value}")

        assert self.modify_program_code.verify_key_exist_with_valid_value_type(response_body, transaction_id_key)
        self.logger.info(f"{transaction_id_key} key exist having some valid valid in it")
