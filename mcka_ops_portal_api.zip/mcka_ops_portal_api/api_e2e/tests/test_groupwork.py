import email
import time
import pytest

from test.mcka_ops_portal_api.api_e2e.api_library.groupwork import GroupWork
from test.mcka_ops_portal_api.api_e2e.api_library.user_management import UserManagement
from test.mcka_ops_portal_api.config import *


class TestGroupWork:
    groupwork = GroupWork()
    user = UserManagement()
    logger = Log

    def test_lp_without_assignment_and_groups(self, basic_auth):
        """
        (Group work) Validate lp without assignment and groups
        """
        response = self.groupwork.get_lp_without_assignment_and_groups(basic_auth)
        response_body = self.groupwork.get_content(response)
        assert STATUS_CODE_GOOD == response.status_code
        assert self.groupwork.compare_expected_and_actual_result(response_body, success_key, true_value)
        assert self.groupwork.compare_expected_and_actual_result(response_body, CONFIG_ID, content_management_lp_code)
        assert self.groupwork.compare_expected_and_actual_result(response_body, assignments_key, [])

    def test_lp_with_groups_and_assignment(self, basic_auth):
        """
        (Group work) Validate lp with groups and assignment
        """
        response = self.groupwork.get_lp_with_groups_and_assignment(basic_auth)
        response_body = self.groupwork.get_content(response)
        assert STATUS_CODE_GOOD == response.status_code
        assert self.groupwork.compare_expected_and_actual_result(response_body, success_key, true_value)
        assert self.groupwork.compare_expected_and_actual_result(response_body, CONFIG_ID, config_id)
        assert self.groupwork.compare_expected_and_actual_result(response_body, highest_group_number_key, 5)
        assert self.groupwork.compare_expected_and_actual_result(response_body, lowest_group_number_key, 1)
        assert self.groupwork.compare_expected_and_actual_result(response_body[assignments_key][0], assignment_name_key,
                                                                 group_assignment_name)
        assert self.groupwork.verify_key_exist_with_valid_value_type(response_body, highest_group_number_key)
        assert self.groupwork.verify_key_exist_with_valid_value_type(response_body, lowest_group_number_key)

    def test_validate_created_group(self, basic_auth):
        """
        (Group work) Create and validate new group
        """
        response = self.groupwork.get_lp_with_groups_and_assignment(basic_auth)
        response_body = self.groupwork.get_content(response)
        assert STATUS_CODE_GOOD == response.status_code
        assert self.groupwork.compare_expected_and_actual_result(response_body, success_key, true_value)
        assert self.groupwork.compare_expected_and_actual_result(response_body, highest_group_number_key, 5)
        assert self.groupwork.compare_expected_and_actual_result(response_body, lowest_group_number_key, 1)
        assert self.groupwork.compare_expected_and_actual_result(response_body[assignments_key][0], assignment_name_key,
                                                                 group_assignment_name)
        assert self.groupwork.verify_key_exist_with_valid_value_type(response_body, highest_group_number_key)
        assert self.groupwork.verify_key_exist_with_valid_value_type(response_body, lowest_group_number_key)

    @pytest.mark.skip()
    def test_validate_by_adding_new_groups(self, basic_auth):
        """
        (Group work) Add new groups and validate them
        """
        response = self.groupwork.create_groups(token=basic_auth, prog_id=sync_user_failed_program_id)
        response_body = self.groupwork.get_content(response)
        transaction_id = self.groupwork.get_transaction_id(response_body)
        details = self.groupwork.user_uploading_got_completed(transaction_id, basic_auth)
        self.logger.info(details)
        report_response = self.groupwork.report_api_response(transaction_id, basic_auth)
        report_body = self.groupwork.get_content(report_response)
        self.logger.info(report_body)
        status_code = self.groupwork.get_status_code(report_response)
        self.logger.info(f"status code: {status_code}")
        assert STATUS_CODE_GOOD == status_code
        assert self.groupwork.validate_group_work_details(report_body)

    def test_adding_2001_groups_must_fail(self, basic_auth):
        """
        (Group work) Try to add 2001 groups and validate the failure
        """
        response = self.groupwork.create_groups(token=basic_auth, prog_id=sync_user_failed_program_id, num_of_groups=2001)
        response_body = self.groupwork.get_content(response)
        status_code = self.groupwork.get_status_code(response)
        assert BAD_REQUEST_STATUS_CODE_400 == status_code
        self.logger.info(f"status code: {status_code}")
        self.groupwork.validate_group_work_failure_message(response_body)
        self.logger.info("Groups Must be greater than or equal to 1 and less than or equal to 2000.")

    def test_uploading_new_users_in_group_works(self, basic_auth):
        """
        (Group work) Upload new users in group work and validate it
        """
        response = self.groupwork.upload_participants_file(token=basic_auth, p_id=None)
        response_body = self.groupwork.get_content(response)
        status_code = self.groupwork.get_status_code(response)
        assert STATUS_CODE_GOOD == status_code
        assert self.groupwork.compare_expected_and_actual_result(response_body, success_key, true_value)
        assert self.groupwork.verify_key_exist_with_valid_value_type(response_body, transaction_id_key)

        transaction_id = self.groupwork.get_transaction_id(response_body)

        details = self.groupwork.user_uploading_got_completed(transaction_id, basic_auth)
        details_body = self.groupwork.get_content(response)
        time.sleep(25)
        response = self.groupwork.upload_user_report(token=basic_auth, tr_id=transaction_id)
        response_body = self.groupwork.get_content(response)
        status_code = self.groupwork.get_status_code(response)

        assert STATUS_CODE_GOOD == status_code
        self.logger.info(f"status code: {status_code}")

        assert self.groupwork.validate_uploaded_new_users_in_group_works(response_body, transaction_id)

    @pytest.mark.skip()
    def test_move_user_failed(self, basic_auth):
        """
        (Group work) Move user from one group to another with more than 15 users and validate the failure
        """
        response_group_users = self.groupwork.get_group_details(basic_auth)
        response_group_users_body = self.groupwork.get_content(response_group_users)
        status_code = self.groupwork.get_status_code(response_group_users)
        assert STATUS_CODE_GOOD == status_code
        email_id_to_move, group_number = self.groupwork.get_group_number_and_users_email(response_group_users_body)

        response_move_user = self.groupwork.move_users(basic_auth, email_id_to_move, group_number)
        response_move_user_body = self.groupwork.get_content(response_move_user)

        status_code = self.groupwork.get_status_code(response_group_users)
        assert STATUS_CODE_GOOD == status_code
        self.logger.info(f"status code: {status_code}")

        assert self.groupwork.compare_expected_and_actual_result(response_move_user_body, success_key, false_value)
        assert self.groupwork.compare_expected_and_actual_result(response_move_user_body, message_key,
                                                                 move_user_error_message)

    def test_move_user_success(self, basic_auth):
        """
        (Group work) Move user from one group to another with less than 15 users and validate it (at the end move user
        back to previous group)
        """
        response_group_users = self.groupwork.get_group_details(basic_auth, move_user_lp)
        response_group_users_body = self.groupwork.get_content(response_group_users)
        status_code = self.user.get_status_code(response_group_users)
        assert STATUS_CODE_GOOD == status_code
        email_id_to_move, group_number = self.groupwork.get_group_number_and_users_email(response_group_users_body)

        response_move_user = self.groupwork.move_users(basic_auth, email_id_to_move, group_number)
        response_move_user_body = self.groupwork.get_content(response_move_user)

        status_code = self.user.get_status_code(response_group_users)
        assert STATUS_CODE_GOOD == status_code
        self.logger.info(f"status code: {status_code}")

        assert self.groupwork.compare_expected_and_actual_result(response_move_user_body, success_key, true_value)

        # move user back to group one
        assert STATUS_CODE_GOOD == self.user.get_status_code(self.groupwork.move_users(basic_auth, email_id_to_move, 1))

    def test_group_gc(self, basic_auth):
        """
        (Group work) Make a user group coordinator of a group and validate it
        """
        response_group_users = self.groupwork.get_group_details(basic_auth)
        response_group_users_body = self.groupwork.get_content(response_group_users)
        email_id, _ = self.groupwork.get_group_number_and_users_email(response_group_users_body)

        response = self.groupwork.group_gc(basic_auth, email_id, 1, True)
        response_body = self.groupwork.get_content(response)
        status_code = self.user.get_status_code(response_group_users)

        assert STATUS_CODE_GOOD == status_code
        self.logger.info(f"status code: {status_code}")

        assert self.groupwork.compare_expected_and_actual_result(response_body, success_key, true_value)

        response = self.groupwork.group_gc(basic_auth, email_id, 1, False)
        response_body = self.groupwork.get_content(response)
        status_code = self.user.get_status_code(response_group_users)

        assert STATUS_CODE_GOOD == status_code
        self.logger.info(f"status code: {status_code}")

        assert self.groupwork.compare_expected_and_actual_result(response_body, success_key, true_value)

    def test_group_ta(self, basic_auth):
        """
        (Group work) Make a user group TA of a group and validate it
        """
        response = self.groupwork.assign_group_ta(basic_auth, group_number=1, ta_email="TA@email.com",
                                                  ta_name="TA Name")
        response_body = self.groupwork.get_content(response)
        status_code = self.user.get_status_code(response)

        assert STATUS_CODE_GOOD == status_code
        self.logger.info(f"status code: {status_code}")

        assert self.groupwork.compare_expected_and_actual_result(response_body, success_key, true_value)

    def test_remove_group_user(self, basic_auth):
        """
        (Group work) Remove a user from the group and validate it
        """
        response_group_users = self.groupwork.get_group_details(basic_auth)
        response_group_users_body = self.groupwork.get_content(response_group_users)
        email_id, _ = self.groupwork.get_group_number_and_users_email(response_group_users_body)
        response = self.groupwork.remove_group_user(basic_auth, email_id=email_id, group_number=1)
        response_body = self.groupwork.get_content(response)
        status_code = self.user.get_status_code(response)

        assert STATUS_CODE_GOOD == status_code
        self.logger.info(f"status code: {status_code}")

        assert self.groupwork.compare_expected_and_actual_result(response_body, success_key, true_value)

    def test_update_group_user_role(self, basic_auth):
        """
        (Group work) Update a group user role and validate it
        """

        response = self.groupwork.validate_upload_group_coordinators_and_ta_groupwork_info(basic_auth)
        response_body = self.groupwork.get_content(response)
        response = self.groupwork.upload_group_coordinators_and_ta_groupwork_info(basic_auth)
        response_body = self.groupwork.get_content(response)
        status_code = self.user.get_status_code(response)
        assert STATUS_CODE_GOOD == status_code
        self.logger.info(f"status code: {status_code}")

        assert self.groupwork.compare_expected_and_actual_result(response_body, success_key, true_value)
        assert self.groupwork.compare_expected_and_actual_result(response_body['result'], total_rows_key, 2)
        assert self.groupwork.compare_expected_and_actual_result(response_body['result'], successful_rows_key, 2)
        assert self.groupwork.compare_expected_and_actual_result(response_body['result'], failed_rows_key, 0)
        assert self.groupwork.compare_expected_and_actual_result(response_body['result'], status_key, completed_message)
        assert self.groupwork.verify_key_exist_with_valid_value_type(response_body['result'], transaction_id_key, int)

    @pytest.mark.skip()
    def test_user_un_enrollment_is_happening_successfully(self, basic_auth):
        """
        (Group work) Un-enroll a user and validate it
        """
        response = self.groupwork.upload_participants_file(token=basic_auth, p_id=None)
        response_body = self.groupwork.get_content(response)
        status_code = self.groupwork.get_status_code(response)
        assert STATUS_CODE_GOOD == status_code
        self.logger.info(f"status code: {status_code}")

        transaction_id = self.groupwork.get_transaction_id(response_body)
        details = self.groupwork.user_uploading_got_completed(transaction_id, basic_auth)
        time.sleep(25)

        report_response = self.groupwork.report_api_response(transaction_id, basic_auth)
        report_body = self.groupwork.get_content(report_response)
        self.logger.info(report_body)

        enrolled_users = self.groupwork.get_enrollment_users()
        response_ne_users = self.groupwork.get_group_details(basic_auth, enrolled_session_program_id)
        response_ne_users_body = self.groupwork.get_content(response_ne_users)
        assert self.groupwork.validate_emails_in_json(response_ne_users_body[groups_key], enrolled_users,
                                                      response_ne_users_body['total_rows'])

        response = self.groupwork.validate_upload_unenroll_file(token=basic_auth, sheet_name=sheet_name,
                                                                users=valid_value, upload=True)
        response_body = self.groupwork.get_content(response)
        transaction_id = self.groupwork.get_transaction_id(response_body)
        details = self.groupwork.user_uploading_got_completed(transaction_id, basic_auth)
        self.logger.info(details)
        assert self.groupwork.check_if_pending(details, transaction_id, transaction_status_key, basic_auth)
        # self.logger.info("transaction status came as COMPLETED")

        report_response = self.groupwork.report_api_response(transaction_id, basic_auth)
        report_body = self.groupwork.get_content(report_response)
        self.logger.info(report_body)
        assert self.groupwork.validate_un_enrollment_details(report_body, transaction_id)
        self.logger.info('["transaction_id", "title", "subtitle", "overall_success"] keys exist with right values')

        response_ne_users = self.groupwork.get_group_details(basic_auth, enrolled_session_program_id)
        response_ne_users_body = self.groupwork.get_content(response_ne_users)
        assert not self.groupwork.validate_emails_in_json(response_ne_users_body[groups_key], enrolled_users,
                                                          response_ne_users_body['total_rows'])

    def test_download_latest_groupwork_data_file(self, basic_auth):
        """
        (Group work) Validate that latest group-work data file is downloading
        """
        response = self.groupwork.download_latest_groupwork_data_file(basic_auth)
        status_code = self.user.get_status_code(response)
        assert STATUS_CODE_GOOD == status_code
        self.logger.info(f"status code: {status_code}")
