import logging
import time
import pytest

from ..api_library.user_management import UserManagement
from ...config import *


class TestUserManagementScenarios:
    user = UserManagement()
    logger = Log

    def test_by_passing_empty_values_to_all_required_fields(self, basic_auth):
        """
        MAPOAS-1584
        verify by passing empty values to all required fields[email id, password] must fail the api
        - status code must be 400
        - errors key exist having list as value and list contains 2 dicts where we validate error messages for each field
        Note:
            we merged 3 cases here
            verify by passing empty values to all required fields must fail the api
            verify by passing wrong values to all required fields must fail the api
            verify by passing only optional values must not create a user and api must fail
            so we added both empty and invalid values in 1 file and validated it
        """
        response = self.user.upload_participants_file(
            token=basic_auth, email=invalid_value, client_name="", password=invalid_value, number_of_user=2
        )
        response_body = self.user.get_content(response)
        self.logger.info(response_body)
        status_code = self.user.get_status_code(response)
        self.logger.info(f"status code: {status_code}")
        assert BAD_REQUEST_STATUS_CODE_400 == status_code
        assert self.user.validate_errors_details(response_body)
        self.logger.info("email id and password values are missing")

    def test_by_uploading_user_management_file_with_new_users(self, basic_auth):
        """
        MAPOAS-1582
        User Management - Upload user management file with single client id and validate the response
        prepare a data in xlsx file to enroll new users with just single client id and name
         for example with R10_Arbisoft
        Hit post
        and validate
        -status code to be 200
        - message key exist having value File validation successful
        - count key exist with value that we provided in our sheet (user count)
        - warnings key exist with value as empty list
        """
        response = self.user.upload_participants_file(token=basic_auth)
        response_body = self.user.get_content(response)
        self.logger.info(response_body)
        status_code = self.user.get_status_code(response)
        self.logger.info(f"status code: {status_code}")
        assert STATUS_CODE_GOOD == status_code
        assert self.user.compare_expected_and_actual_result(response_body, message_key, message_value)
        self.logger.info(f"{message_key} exist and contains value: {message_value}")
        assert self.user.compare_expected_and_actual_result(response_body, count_key, 3)
        self.logger.info(f"{count_key} exist and contains value: {3}")
        assert self.user.verify_value_not_exist(response_body, "warnings", [])
        self.logger.info("warnings key exist and have nothing in it so we will getting empty list")

    def test_by_uploading_user_management_file_with_invalid_sheet_name(self, basic_auth):
        """
        MAPOAS-1580
        prepare a data in xlsx file to enroll users with invalid sheet name that can be any name
        the user must not able to submit the api successfully
        Hit api https://admin-qa.mckinseyaccelerate.com/api/dat/validate/course_ops/auto_enrollment?program_id={}
         we need to change sheet name that must not be manage sheet and hit the above api and validate
        - status code to be 400
        - errors key exist having list as value and 1 dict must have message key with value to be "Missing manage users sheet(s)
        """
        response = self.user.upload_participants_file(token=basic_auth, sheet_name=invalid_value)
        response_body = self.user.get_content(response)
        self.logger.info(response_body)
        status_code = self.user.get_status_code(response)
        self.logger.info(f"status code: {status_code}")
        assert BAD_REQUEST_STATUS_CODE_400 == status_code

        assert self.user.verify_error_message_for_invalid_sheet_name(response_body)
        self.logger.info("errors key exist having list as value message key with value to be Missing manage users sheet(s)")

    def test_user_management_file_with_new_users_uploaded_successfully(self, basic_auth):
        """
        User Management - Upload user management file with single client id and validate the response
        prepare a data in xlsx file to enroll new users with just single client id and name
         for example with R10_Arbisoft
        Hit post
        and validate
        -status code to be 200
        - success key exist with value true
        - transaction id key exist with some valid value

        when we have transaction id we use that id to start the process of uploading the user to the server
        - status code to be 200
        - done key exist with value to be true
        - percentage key exist with value to be 100
        - transaction id must match with the one we have from above api
        - transaction_status key exist with value to be COMPLETED

        Based on the transaction id we hit another api to get the report and then validate
        - status code to be 200
        - transaction id exist and match with the one we got from previous api
        - status key exist with value to be completed

        newly created user details
        - failed key exist having value to be 0
        - success key exist with value to be the number of users we created
        - failed key exist with value to be 0
        - errors key exist with value to be []
        - total key exist with value to be the number of users we created

        existing users details
        - failed key exist having value to be 0
        - errors key exist with value to be []
        - total and success key exist with value to be 0, 0
        """
        response = self.user.upload_participants_file(token=basic_auth, p_id=None)
        response_body = self.user.get_content(response)
        self.logger.info(response_body)
        status_code = self.user.get_status_code(response)
        self.logger.info(f"status code: {status_code}")
        assert STATUS_CODE_GOOD == status_code
        assert self.user.compare_expected_and_actual_result(response_body, success_key, true_value)
        self.logger.info(f"{message_key} exist and contains value: {true_value}")
        transaction_id = self.user.get_transaction_id(response_body)
        details = self.user.user_uploading_got_completed(transaction_id, basic_auth)
        self.logger.info(details)
        assert self.user.check_if_pending(details, transaction_id, transaction_status_key, basic_auth)
        assert self.user.validate_user_uploading_response(details, transaction_id, status=transaction_status_key)
        self.logger.info("transaction status came as COMPLETED")

        report_response = self.user.report_api_response(transaction_id, basic_auth)
        report_body = self.user.get_content(report_response)
        self.logger.info(report_body)
        status_code = self.user.get_status_code(report_response)
        self.logger.info(f"status code: {status_code}")
        assert STATUS_CODE_GOOD == status_code
        assert self.user.validate_user_uploading_response(report_body, transaction_id, status=status_key)
        self.logger.info("status key exist with value as COMPLETED")

        assert self.user.compare_expected_and_actual_result(report_body, failed_key, 0)
        assert self.user.validate_user_details(report_body["new_users"], k_values=[3, [], 3])

        assert self.user.compare_expected_and_actual_result(report_body["new_users"], failed_key, 0)
        logging.info("all new users keys found with right values in them")
        assert self.user.validate_user_details(report_body["existing_users"], k_values=[0, [], 0])
        logging.info("all existing users keys found with right values in them")

    @pytest.mark.skip(reason="API response taking too much time and then returns 504")
    def test_users_got_created_successfully(self, basic_auth):
        """
        hit api https://admin-{}.mckinseyaccelerate.com/api/automation/course_ops/auto_enrollment/{p_id}
        - status code to be 200
        - success key exist with value to be true
        - data key exist and have value as list take 1st entry and validate keys and value
        - transaction_id key exist having int as value
        - completed key exist with value to be true
        - existing_user_total key exist with value to be 0
        - existing_user_success_count key exist with value to be 0
        - new_user_success_count key exist with value to be 3
        - new_user_total key exist with value to be 3
        """
        # failing: reason is API response taking too much time and then return 504 in the response.
        # Obsolete API call
        response = self.user._get(
            url=f'{ADMIN_BASE_URL}api/automation/course_ops/auto_enrollment/{program_id}', token=basic_auth
        )
        response_body = self.user.get_content(response)
        self.logger.info(response_body)
        status_code = self.user.get_status_code(response)
        self.logger.info(f"status code: {status_code}")
        assert STATUS_CODE_GOOD == status_code
        assert self.user.compare_expected_and_actual_result(response_body, success_key, true_value)
        self.logger.info(f"{success_key} key exist with value as {true_value}")
        assert self.user.created_new_users_details(response_body)
        self.logger.info("All above keys exist and have valid values")

    def test_user_management_file_with_existing_user(self, basic_auth):
        """
        try to upload a file having existing user
        - status code to be 400
        - errors key exist having list as value and take the 1st object and validate
        - column key must exist and have value as username
        - message key exist and have value as 'Usernames should be distinct'
        """
        response = self.user.upload_participants_file(token=basic_auth, email=existing_user)
        response_body = self.user.get_content(response)
        self.logger.info(response_body)
        status_code = self.user.get_status_code(response)
        self.logger.info(f"status code: {status_code}")
        assert BAD_REQUEST_STATUS_CODE_400 == status_code
        self.user.validate_existing_user_failure_details(response_body)
        logging.info("error key exist and have all the values that are expected")

    def test_by_uploading_user_management_file_with_new_users_and_multi_clients(self, basic_auth):
        """
        User Management - Upload user management file with single client id and validate the response
        prepare a data in xlsx file to enroll new users with multi client ids and names
        Hit post https://admin-{}.mckinseyaccelerate.com/api/dat/validate/course_ops/auto_enrollment?program_id=2139
        and validate
        -status code to be 200
        - message key exist having value File validation successful
        - count key exist with value that we provided in our sheet (user count)
        - warnings key exist with value as empty list
        """
        response = self.user.upload_participants_file(token=basic_auth, single_client=False)
        response_body = self.user.get_content(response)
        self.logger.info(response_body)
        status_code = self.user.get_status_code(response)
        self.logger.info(f"status code: {status_code}")
        assert STATUS_CODE_GOOD == status_code
        assert self.user.compare_expected_and_actual_result(response_body, message_key, message_value)
        self.logger.info(f"{message_key} exist and contains value: {message_value}")
        assert self.user.compare_expected_and_actual_result(response_body, count_key, 3)
        self.logger.info(f"{count_key} exist and contains value: {3}")
        assert self.user.verify_value_not_exist(response_body, "warnings", [])
        self.logger.info("warnings key exist and have nothing in it so we will getting empty list")

    def test_by_uploading_user_un_enrollment_file_with_valid_sheet_name_and_empty_users(self, basic_auth):
        """
        prepare a data in xlsx file to enroll users with invalid sheet name that can be any name
        the user must not able to submit the api successfully
        Hit api with some valid sheet name and user value to be empty
        - status code to be 400
        - errors key exist having list as value and 1 dict must have message key with value to be "No data found in sheet.""
        """
        self.user.upload_participants_file(token=basic_auth)
        response = self.user.validate_upload_unenroll_file(token=basic_auth, sheet_name=sheet_name, users="")
        response_body = self.user.get_content(response)
        self.logger.info(response_body)
        status_code = self.user.get_status_code(response)
        self.logger.info(f"status code: {status_code}")
        assert BAD_REQUEST_STATUS_CODE_400 == status_code
        assert self.user.verify_error_message_for_invalid_sheet_name(response_body, message=empty_user_message)
        self.logger.info("errors key exist having list as value message key with value to be No data found in sheet.")

    def test_by_uploading_user_un_enrollment_file_with_invalid_sheet_name(self, basic_auth):
        """
        prepare a data in xlsx file to enroll users with invalid sheet name that can be any name
        the user must not able to submit the api successfully
        Hit api with some valid user value and invalid sheet name
        - status code to be 400
        - errors key exist having list as value and 1 dict must have message key with value to be "Unrecognized sheet invalid"
        """
        self.user.upload_participants_file(token=basic_auth)
        response = self.user.validate_upload_unenroll_file(
            token=basic_auth, sheet_name=invalid_value, users=valid_value
        )
        response_body = self.user.get_content(response)
        self.logger.info(response_body)
        status_code = self.user.get_status_code(response)
        self.logger.info(f"status code: {status_code}")
        assert BAD_REQUEST_STATUS_CODE_400 == status_code
        assert self.user.verify_error_message_for_invalid_sheet_name(
            response_body, index=1, message=invalid_sheet_message
        )
        self.logger.info(f"errors key exist having list as value message key with value to be {invalid_sheet_message}")

    def test_by_uploading_user_un_enrollment_file_with_valid_sheet_name_and_valid_users(self, basic_auth):
        """
        prepare a data in xlsx file to enroll users with invalid sheet name that can be any name
        the user must be able to submit the api successfully
        Hit api with some valid user value and valid sheet name
        - status code to be 200
        - message key exist having value as 'File validation successful'
        """
        self.user.upload_participants_file(token=basic_auth)
        response = self.user.validate_upload_unenroll_file(token=basic_auth, sheet_name=sheet_name, users=valid_value)
        response_body = self.user.get_content(response)
        self.logger.info(response_body)
        status_code = self.user.get_status_code(response)
        self.logger.info(f"status code: {status_code}")
        assert STATUS_CODE_GOOD == status_code
        assert self.user.compare_expected_and_actual_result(response_body, message_key, file_validation_message)
        self.logger.info(f"message key exist with value {file_validation_message}")

    @pytest.mark.skip()
    def test_user_un_enrollment_is_happening_successfully(self, basic_auth):
        """
        upload user 1st same we are doing in our above cases
        Prepare a data in xlsx file to unenroll existing users with valid sheet name and having valid username Hit https://admin-qa.mckinseyaccelerate.com/api/progress/4767 and validate
        -status code to be 200
        -transaction_status key exist having value COMPLETED
        - updated_at key exist having some valid value
        - percentage key exist with value to be 100
        - filename key exist and have value that must match with the file name we provided while loading excel
        - done key exist having value true
        - transaction_id key exist with some valid value

        Hit report api after the un enrollment thing and validate
        - status code to be 200
        validate ["transaction_id", "title", "subtitle", "overall_success"] these keys exist with right values

        """
        response = self.user.upload_participants_file(token=basic_auth, p_id=None)
        response_body = self.user.get_content(response)
        transaction_id = self.user.get_transaction_id(response_body)
        details = self.user.user_uploading_got_completed(transaction_id, basic_auth)
        self.logger.info(details)
        time.sleep(20)
        response = self.user.validate_upload_unenroll_file(
            token=basic_auth, sheet_name=sheet_name, users=valid_value, upload=True
        )
        response_body = self.user.get_content(response)
        transaction_id = self.user.get_transaction_id(response_body)
        details = self.user.user_uploading_got_completed(transaction_id, basic_auth)
        self.logger.info(details)
        assert self.user.validate_user_uploading_response(details, transaction_id, status=transaction_status_key)
        self.logger.info("transaction status came as COMPLETED")

        report_response = self.user.report_api_response(transaction_id, basic_auth)
        report_body = self.user.get_content(report_response)
        self.logger.info(report_body)
        assert self.user.validate_un_enrollment_details(report_body, transaction_id)
        self.logger.info('["transaction_id", "title", "subtitle", "overall_success"] keys exist with right values')

    @pytest.mark.skip(reason="Already covered in Group-work tests")
    def test_by_adding_group_work_successfully(self, basic_auth):
        """
        Hit this api to create new group
        - status code to be 200
        - transaction_id key exist and that value must match with the one we got from above case
        """
        response = self.user.create_groups(token=basic_auth, prog_id=program_id)
        response_body = self.user.get_content(response)
        transaction_id = self.user.get_transaction_id(response_body)
        details = self.user.user_uploading_got_completed(transaction_id, basic_auth)
        self.logger.info(details)
        report_response = self.user.report_api_response(transaction_id, basic_auth)
        report_body = self.user.get_content(report_response)
        self.logger.info(report_body)
        status_code = self.user.get_status_code(report_response)
        self.logger.info(f"status code: {status_code}")
        assert STATUS_CODE_GOOD == status_code
        assert self.user.validate_group_work_details(report_body)

    @pytest.mark.skip(reason="handled in group work")
    def test_adding_201_groups_must_fail(self, basic_auth):
        """
        Hit this api to create new group
        groups count must be greater than 200
        - status code to be 400
        - Hit this api with max value greater than 200 in payload must not create groups and show error message as
        "Must be greater than or equal to 1 and less than or equal to 200."
        """
        response = self.user.create_groups(token=basic_auth, prog_id=program_id, num_of_groups=201)
        response_body = self.user.get_content(response)
        status_code = self.user.get_status_code(response)
        assert BAD_REQUEST_STATUS_CODE_400 == status_code
        self.logger.info(f"status code: {status_code}")
        self.user.validate_group_work_failure_message(response_body)
        self.logger.info("Groups Must be greater than or equal to 1 and less than or equal to 200.")

    def test_validating_bulk_update_accounts_file_with_invalid_sheet_name_and_no_active_status(self, basic_auth):
        """
        pre req upload few users
        Prepare a data in xlsx file to deactivate users with valid file name that must be "Invalid"
        and must have these 2 Columns names "username" and "active"=="no"
         - status code to be 400
         - response body contains true flag
        """
        self.user.upload_participants_file(token=basic_auth)
        response = self.user.upload_bulk_update_accounts_file(token=basic_auth, active="no",
                                                              sheet_name_value=invalid_value)
        response_body = self.user.get_content(response)
        self.logger.info(response_body)
        status_code = self.user.get_status_code(response)
        self.logger.info(f"status code: {status_code}")
        assert BAD_REQUEST_STATUS_CODE_400 == status_code
        assert self.user.verify_error_message_for_invalid_sheet_name(response_body, index=1, message=invalid_sheet)
        self.logger.info(f"errors key exist having list as value message key with value to {invalid_sheet}")

    def test_validating_bulk_update_accounts_file_with_invalid_sheet_name_and_yes_active_status(self, basic_auth):
        """
        pre req upload few users
        Prepare a data in xlsx file to deactivate users with valid file name that must be "Invalid"
        and must have these 2 Columns names "username" and "active"=="yes"
         - status code to be 400
         - response body contains true flag
        """
        self.user.upload_participants_file(token=basic_auth)
        response = self.user.upload_bulk_update_accounts_file(token=basic_auth, active="yes", sheet_name_value=invalid_value)
        response_body = self.user.get_content(response)
        self.logger.info(response_body)
        status_code = self.user.get_status_code(response)
        self.logger.info(f"status code: {status_code}")
        assert BAD_REQUEST_STATUS_CODE_400 == status_code
        assert self.user.verify_error_message_for_invalid_sheet_name(response_body, index=1, message=invalid_sheet)
        self.logger.info(f"errors key exist having list as value message key with value to {invalid_sheet}")

    def test_validating_bulk_update_accounts_file_with_valid_sheet_name_and_yes_active_status(self, basic_auth):
        """
        pre req upload few users
        Prepare a data in xlsx file to deactivate users with valid file name that must be "bulk update accounts"
        and must have these 2 Columns names "username" and "active"=="yes"
         - status code to be 200
         - response body contains true flag
        """
        self.user.upload_participants_file(token=basic_auth)
        response = self.user.upload_bulk_update_accounts_file(token=basic_auth, active="yes", upload=True)
        response_body = self.user.get_content(response)
        self.logger.info(response_body)
        status_code = self.user.get_status_code(response)
        self.logger.info(f"status code: {status_code}")
        assert STATUS_CODE_GOOD == status_code
        assert self.user.compare_expected_and_actual_values(response_body, true_value)
        self.logger.info("response body contains true flag")

    def test_validating_bulk_update_accounts_file_with_valid_sheet_name_and_no_active_status(self, basic_auth):
        """
        pre req upload few users
        Prepare a data in xlsx file to deactivate users with valid file name that must be "bulk update accounts"
        and must have these 2 Columns names "username" and "active"=="no"
         - status code to be 200
         - response body contains true flag
        """
        self.user.upload_participants_file(token=basic_auth)
        response = self.user.upload_bulk_update_accounts_file(token=basic_auth, active="no", upload=True)
        response_body = self.user.get_content(response)
        self.logger.info(response_body)
        status_code = self.user.get_status_code(response)
        self.logger.info(f"status code: {status_code}")
        assert STATUS_CODE_GOOD == status_code
        assert self.user.compare_expected_and_actual_values(response_body, true_value)
        self.logger.info("response body contains true flag")

    def test_by_uploading_bulk_update_accounts_file_with_valid_sheet_name_and_yes_active_status(self, basic_auth):
        """
        Hit Api to upload few users as pre req step

        Prepare a data in xlsx file to deactivate users with valid file name that must be "bulk update accounts"
        and must have these 2 Columns names "username" and "active"=="no"
        hit Api to upload the file and wait till 100 percent processing got completed
         - status code to be 200
         - percentage complete to 100 percent
         - Transaction status came as COMPLETED or PROCESSING

        hit report api at the end and validate
        - success key exist with true as value
        - status key exist with value as Completed
        """
        response = self.user.upload_participants_file(token=basic_auth, p_id=None)
        response_body = self.user.get_content(response)
        transaction_id = self.user.get_transaction_id(response_body)
        self.user.user_uploading_got_completed(transaction_id, basic_auth)
        response = self.user.upload_bulk_update_accounts_file(token=basic_auth, active="yes", upload=True)
        response_body = self.user.get_content(response)
        self.logger.info(response_body)
        status_code = self.user.get_status_code(response)
        self.logger.info(f"status code: {status_code}")
        assert STATUS_CODE_GOOD == status_code
        transaction_id = self.user.get_transaction(basic_auth)
        time.sleep(20)
        details = self.user.user_uploading_got_completed(transaction_id, basic_auth)
        self.logger.info(details)
        assert self.user.validate_user_uploading_response(details, transaction_id, status=transaction_status_key)
        self.logger.info("transaction status came as COMPLETED")
        report_response = self.user.report_api_response(transaction_id, basic_auth)
        report_body = self.user.get_content(report_response)
        self.logger.info(report_body)
        assert self.user.compare_expected_and_actual_result(report_body, success_key, true_value)
        assert self.user.compare_expected_and_actual_result(report_body, status_key, "COMPLETED")

    def test_by_uploading_bulk_update_accounts_file_with_valid_sheet_name_and_no_active_status(self, basic_auth):
        """
        Hit Api to upload few users as pre req step

        Prepare a data in xlsx file to deactivate users with valid file name that must be "bulk update accounts"
        and must have these 2 Columns names "username" and "active"=="yes"
        hit Api to upload the file and wait till 100 percent processing got completed
         - status code to be 200
         - percentage complete to 100 percent
         - Transaction status came as COMPLETED or PROCESSING

        hit report api at the end and validate
        - success key exist with true as value
        - status key exist with value as Completed
        """
        response = self.user.upload_participants_file(token=basic_auth, p_id=None)
        response_body = self.user.get_content(response)
        transaction_id = self.user.get_transaction_id(response_body)
        self.user.user_uploading_got_completed(transaction_id, basic_auth)
        response = self.user.upload_bulk_update_accounts_file(token=basic_auth, active="yes", upload=True)
        response_body = self.user.get_content(response)
        self.logger.info(response_body)
        status_code = self.user.get_status_code(response)
        self.logger.info(f"status code: {status_code}")
        assert STATUS_CODE_GOOD == status_code
        transaction_id = self.user.get_transaction(basic_auth)
        time.sleep(20)
        details = self.user.user_uploading_got_completed(transaction_id, basic_auth)
        self.logger.info(details)
        assert self.user.validate_user_uploading_response(details, transaction_id, status=transaction_status_key)
        self.logger.info("Transaction status came as COMPLETED or PROCESSING")
        report_response = self.user.report_api_response(transaction_id, basic_auth)
        report_body = self.user.get_content(report_response)
        self.logger.info(report_body)
        assert self.user.compare_expected_and_actual_result(report_body, success_key, true_value)
        self.logger.info("success key exist with true as value")
        assert self.user.compare_expected_and_actual_result(report_body, status_key, "COMPLETED")
        self.logger.info("status key exist with value as Completed")

    def test_validate_webinar_api(self, basic_auth):
        """
        hit api and validate
        - status code to be 200
        - success key exist having value as true
        - data key exist having value as dict and that dict further have waitlisted and enrolled as keys with respected values that we passed
        """
        response = self.user.get_webinar_enrollments(basic_auth)
        response_body = self.user.get_content(response)
        status_code = self.user.get_status_code(response)
        assert STATUS_CODE_GOOD == status_code
        self.logger.info(f"status code: {status_code}")
        assert self.user.compare_expected_and_actual_result(response_body, success_key, true_value)
        self.logger.info("success key exist with true as value")
        assert self.user.validate_webinar_details(response_body)
        self.logger.info("enrolled and waitlisted keys exist with values to be integers")
