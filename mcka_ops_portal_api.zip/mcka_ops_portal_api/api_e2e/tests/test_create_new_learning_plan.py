import logging
import time

import requests
from ..api_library.create_new_lp import CreateNewLP
from ..api_library.lp_sheet_creation import LPCreation
from ..api_library.modify_program_code import ModifyProgramCode
import os
from pathlib import Path
from ...config import *


class TestCreateNewLP:
    create_new_lp = CreateNewLP()
    lp_creation = LPCreation()

    # Verify successful upload of Learning plan file
    def test_validate_lp_upload_file(self, basic_auth):
        """
        Test for abc
        """
        Log.info("test_validate_lp_upload")
        response = self.lp_creation.upload_learning_plan_file(APP_URL, basic_auth, pre_fix=pre_fix, post_fix=post_fix,
                                                              course_type=course_type,
                                                              lp_name=lp_name, lp_desc=lp_desc, lp_level=lp_level,
                                                              expert_name=expert_name, connected=connected,
                                                              ch_type=ch_type, ch_empty=ch_empty, ch_sort=ch_sort)
        Log.info("printing status_code")
        Log.debug(response.status_code)
        assert response.status_code == 200

    # Verify "File validation successful message"

    def test_verify_message(self, basic_auth):
        """
        hello
        """
        Log.info("test_verify_message")
        response = self.lp_creation.upload_learning_plan_file(APP_URL, basic_auth, pre_fix=pre_fix, post_fix=post_fix,
                                                              course_type=course_type,
                                                              lp_name=lp_name, lp_desc=lp_desc, lp_level=lp_level,
                                                              expert_name=expert_name, connected=connected,
                                                              ch_type=ch_type, ch_empty=ch_empty, ch_sort=ch_sort)
        Log.info("printing status_code")
        Log.debug(response.status_code)
        Log.info(response.status_code)
        message = response.json()['message']
        assert message == 'File validation successful'

    # Verify courses name

    def test_validate_steps(self, basic_auth):
        Log.info("test_validate_steps")
        response = self.lp_creation.upload_learning_plan_file(APP_URL, basic_auth, pre_fix=pre_fix, post_fix=post_fix,
                                                              course_type=course_type,
                                                              lp_name=lp_name, lp_desc=lp_desc, lp_level=lp_level,
                                                              expert_name=expert_name, connected=connected,
                                                              ch_type=ch_type, ch_empty=ch_empty, ch_sort=ch_sort)
        Log.info(response.status_code)
        Log.info(response.json())
        steps = response.json()["steps"]
        assert steps[0] == 'Learning plan creation'
        assert steps[1] == 'Course component creation'
        assert steps[2] == 'Connecting learning plans and courses'
        assert steps[3] == 'Creation of cohort group'
        assert steps[4] == 'Creation of enrollment rule'
        assert steps[5] == 'Channel creation'

    # verify 401 is returned when invalid user tries to upload the file

    def test_validate_modification(self, basic_auth):
        modify = ModifyProgramCode()
        response = self.lp_creation.upload_learning_plan_file(APP_URL, basic_auth, pre_fix=pre_fix, post_fix=post_fix,
                                                              course_type=course_type,
                                                              lp_name=lp_name, lp_desc=lp_desc, lp_level=lp_level,
                                                              expert_name=expert_name, connected=connected,
                                                              ch_type=ch_type, ch_empty=ch_empty, ch_sort=ch_sort, url_type="Modification")
        status_code = modify.get_status_code(response)
        Log.info(f"status code: {status_code}")
        assert STATUS_CODE_GOOD == status_code
        body = modify.get_content(response)
        p_id = modify.get_program_id(body)
        time.sleep(20)
        edit_response = modify.edit_program_code(url=edit_program, token=basic_auth, p_id=p_id)
        status_code = modify.get_status_code(edit_response)
        Log.info(f"status code: {status_code}")
        assert STATUS_CODE_GOOD == status_code
        edit_response_body = modify.get_content(edit_response)
        assert modify.verify_entry(edit_response_body, success_key, true_value)
        Log.info(f"success key exist having value ok in it")
        edited_t_id = modify.get_transaction_id(edit_response_body)
        Log.info(edited_t_id)
        edit_final_response = modify.final_edit_program_code(t_id=edited_t_id, p_id=p_id, token=basic_auth)
        final_body = modify.get_content(edit_final_response)
        status_code = modify.get_status_code(edit_response)
        Log.info(f"status code: {status_code}")
        assert STATUS_CODE_GOOD == status_code
        assert modify.verify_entry(final_body, success_key, true_value)
        Log.info("success key exist having value True")
        assert modify.compare_expected_and_actual_result(final_body, message_key, success_message)
        Log.info("message key exist having value SUCCESS")

        details = modify.replication_completed(task_key=edited_t_id, token=basic_auth, modification=True)
        Log.info(details)
        t_id = modify.get_transaction_id(details)
        logging.info(t_id)
        assert t_id
        time.sleep(5)
        resp = modify._get(url=f'{report_api}{p_id}', token=basic_auth)
        status_code = modify.get_status_code(resp)
        Log.info(f"status code: {status_code}")
        assert STATUS_CODE_GOOD == status_code
        modified_body = modify.get_content(resp)
        Log.info(modified_body)
        assert modify.validate_modification_details(modified_body)

    def test_invalid_user(self, basic_auth):
        Log.info("test_invalid_user")
        basic_auth = "sdsadsadsadjsadjsadjakdsjsajdasdsakdjsadjdjsad"
        response = self.lp_creation.upload_learning_plan_file(APP_URL, basic_auth, pre_fix=pre_fix, post_fix=post_fix,
                                                              course_type=course_type,
                                                              lp_name=lp_name, lp_desc=lp_desc, lp_level=lp_level,
                                                              expert_name=expert_name, connected=connected,
                                                              ch_type=ch_type, ch_empty=ch_empty, ch_sort=ch_sort)

        Log.info(response.status_code)
        Log.info(response.json())
        assert response.status_code == 401

    # mismatch in config and channel Id

    def test_error_course_and_config_id(self, basic_auth):
        Log.info("test_error_course_and_configID")
        response = self.lp_creation.upload_learning_plan_file(APP_URL, basic_auth, pre_fix=pre_fix, post_fix='',
                                                              course_type=course_type,
                                                              lp_name=lp_name, lp_desc=lp_desc, lp_level=lp_level,
                                                              expert_name=expert_name, connected=connected,
                                                              ch_type=ch_type, ch_empty=ch_empty, ch_sort=ch_sort)
        Log.info(response.status_code)
        Log.info(response.json())
        sheet_column = response.json()['errors'][0]['column']
        Log.info(sheet_column)
        error_message = response.json()['errors'][0]['message']
        Log.info(error_message)
        assert response.status_code == 400
        assert sheet_column == "Learning Plan course_code"
        assert error_message == "Course code and config_id mismatch."

    # Learning plan name is blank

    def test_error_lp_name_blank(self, basic_auth):
        Log.info("test_err_lpname_blank")
        response = self.lp_creation.upload_learning_plan_file(APP_URL, basic_auth, pre_fix=pre_fix, post_fix=post_fix,
                                                              course_type=course_type,
                                                              lp_name=' ', lp_desc=lp_desc, lp_level=lp_level,
                                                              expert_name=expert_name, connected=connected,
                                                              ch_type=ch_type, ch_empty=ch_empty, ch_sort=ch_sort)
        Log.info(response.status_code)
        Log.info(response.json())
        sheet_column = response.json()['errors'][0]['column']
        Log.info(sheet_column)
        error_message = response.json()['errors'][0]['message']
        Log.info(error_message)
        assert response.status_code == 400
        assert sheet_column == "learning plan: lp_name"
        assert error_message == ERR_MESSAGE_BLANK

    def test_err_course_name_blank(self, basic_auth):
        """
        course name is blank
        """
        Log.info("test_err_course_name_blank")
        response = self.create_new_lp.validate_lp_upload_file(APP_URL, basic_auth)
        Log.info(response.status_code)
        sheet_column = response.json()['errors'][0]['column']
        Log.info(sheet_column)
        error_message = response.json()['errors'][0]['message']
        Log.info(error_message)
        assert response.status_code == 400
        assert sheet_column == "learning plan: course_name"
        assert error_message == ERR_MESSAGE_BLANK

    def test_err_course_type_blank(self, basic_auth):
        Log.info("test_err_course_type_blank")
        response = self.lp_creation.upload_learning_plan_file(APP_URL, basic_auth, pre_fix=pre_fix, post_fix=post_fix,
                                                              course_type='',
                                                              lp_name=lp_name, lp_desc=lp_desc, lp_level=lp_level,
                                                              expert_name=expert_name, connected=connected,
                                                              ch_type=ch_type, ch_empty=ch_empty, ch_sort=ch_sort)
        Log.info(response.status_code)
        Log.info(response.json())

        assert response.status_code == 400
        sheet_column = response.json()['errors'][0]['column']
        message_display = response.json()['errors'][0]['message']
        assert sheet_column == "learning plan: course_type"
        assert message_display == ERR_COURSE_TYPE_MESSAGE

    def test_err_lp_level_blank(self, basic_auth):
        Log.info("test_err_lp_level_blank")
        response = self.lp_creation.upload_learning_plan_file(APP_URL, basic_auth, pre_fix=pre_fix, post_fix=post_fix,
                                                              course_type=course_type,
                                                              lp_name=lp_name, lp_desc=lp_desc, lp_level='',
                                                              expert_name=expert_name, connected=connected,
                                                              ch_type=ch_type, ch_empty=ch_empty, ch_sort=ch_sort)
        Log.info(response.status_code)
        Log.info(response.json())
        sheet_column = response.json()['errors'][0]['column']
        message_display = response.json()['errors'][0]['message']
        assert sheet_column == "learning plan: lp_level"
        assert message_display == ERR_MESSAGE_LP_LEVEL_BLANK

    def test_err_lp_desc(self, basic_auth):
        Log.info("test_err_lp_desc")
        response = self.lp_creation.upload_learning_plan_file(APP_URL, basic_auth, pre_fix=pre_fix, post_fix=post_fix,
                                                              course_type=course_type,
                                                              lp_name=lp_name, lp_desc='', lp_level=lp_level,
                                                              expert_name=expert_name, connected=connected,
                                                              ch_type=ch_type, ch_empty=ch_empty, ch_sort=ch_sort)

        Log.info(response.status_code)

        assert response.status_code == 400
        sheet_column = response.json()['errors'][0]['column']
        err_message = response.json()['errors'][0]['message']
        assert sheet_column == "learning plan: lp_desc"
        assert err_message == ERR_LP_DESCRIPTION_BLANK_MESSAGE

    def test_verify_expert_name_blank(self, basic_auth):
        Log.info("test_verify_expert_name_blank")
        response = self.lp_creation.upload_learning_plan_file(APP_URL, basic_auth, pre_fix=pre_fix, post_fix=post_fix,
                                                              course_type=course_type,
                                                              lp_name=lp_name, lp_desc=lp_desc, lp_level=lp_level,
                                                              expert_name='', connected=connected,
                                                              ch_type=ch_type, ch_empty=ch_empty, ch_sort=ch_sort)
        Log.info(response.status_code)
        Log.info(response.json())
        sheet_column = response.json()['errors'][0]['column']
        Log.info(sheet_column)
        error_message = response.json()['errors'][0]['message']
        Log.info(error_message)
        assert response.status_code == 400
        assert sheet_column == 'channel: expert_name'
        assert error_message == ERR_MESSAGE_BLANK

    def test_verify_channel_sheet_blank(self, basic_auth):
        Log.info("test_verify_ChannelSheet_blank")
        response = self.lp_creation.upload_learning_plan_file(APP_URL, basic_auth, pre_fix=pre_fix, post_fix=post_fix,
                                                              course_type=course_type,
                                                              lp_name=lp_name, lp_desc=lp_desc, lp_level=lp_level,
                                                              expert_name=expert_name, connected=connected,
                                                              ch_type=ch_type, ch_empty=0, ch_sort=ch_sort)
        Log.info(response.status_code)
        assert response.status_code == 200

    def test_verify_multiple_expert_name(self, basic_auth):
        Log.info("test_verify_multiple_expert_name")
        response = self.lp_creation.upload_learning_plan_file(APP_URL, basic_auth, pre_fix=pre_fix, post_fix=post_fix,
                                                              course_type=course_type,
                                                              lp_name=lp_name, lp_desc=lp_desc, lp_level=lp_level,
                                                              expert_name='abc@gmail.com', connected=connected,
                                                              ch_type=ch_type, ch_empty=ch_empty, ch_sort=ch_sort)
        Log.info(response.status_code)
        assert response.status_code == 400
        sheet_column = response.json()['errors'][0]['column']
        err_message = response.json()['errors'][0]['message']
        assert sheet_column == "Channel sheet expert_name"
        assert err_message == ERR_MULTIPLE_MESSAGE

    def test_verify_connected_type(self, basic_auth):
        Log.info("test_verify_connected_Type")
        response = self.lp_creation.upload_learning_plan_file(APP_URL, basic_auth, pre_fix=pre_fix, post_fix=post_fix,
                                                              course_type=course_type,
                                                              lp_name=lp_name, lp_desc=lp_desc, lp_level=lp_level,
                                                              expert_name=expert_name, connected='',
                                                              ch_type=ch_type, ch_empty=ch_empty, ch_sort=ch_sort)
        Log.info(response.status_code)
        Log.info(response.json())
        sheet_column = response.json()['errors'][0]['column']
        Log.info(sheet_column)
        error_message = response.json()['errors'][0]['message']
        Log.info(error_message)
        assert response.status_code == 400
        assert sheet_column == 'learning plan: connected'
        assert error_message == ERR_CONNECTED_VALUES_ALLOWED

    def test_verify_metadata_blank(self, basic_auth):
        Log.info("test_verify_metadata_blank")
        response = self.lp_creation.upload_learning_plan_file(APP_URL, basic_auth, pre_fix=pre_fix, post_fix=post_fix,
                                                              course_type=course_type,
                                                              lp_name=lp_name, lp_desc=lp_desc, lp_level=lp_level,
                                                              expert_name=expert_name, connected=connected,
                                                              ch_type=ch_type, ch_empty=ch_empty, ch_sort=ch_sort)
        Log.info("printing status_code")
        Log.debug(response.status_code)
        assert response.status_code == 200

    def test_verify_channel_sort_multiple(self, basic_auth):
        Log.info("test_verify_Channel_sort_multiple")
        response = self.lp_creation.upload_learning_plan_file(APP_URL, basic_auth, pre_fix=pre_fix, post_fix=post_fix,
                                                              course_type=course_type,
                                                              lp_name=lp_name, lp_desc=lp_desc, lp_level=lp_level,
                                                              expert_name=expert_name, connected=connected,
                                                              ch_type=ch_type, ch_empty=ch_empty, ch_sort='h_sort')
        Log.info(response.status_code)
        assert response.status_code == 400
        sheet_column = response.json()['errors'][0]['column']
        err_message = response.json()['errors'][0]['message']
        assert sheet_column == "channel: channel_sort"
        assert err_message == ERR_CHANNEL_SORT_VALUES

    def test_verify_channel_type_multiple(self, basic_auth):
        Log.info("test_verify_Channel_type_multiple")
        response = self.lp_creation.upload_learning_plan_file(APP_URL, basic_auth, pre_fix=pre_fix, post_fix=post_fix,
                                                              course_type=course_type,
                                                              lp_name=lp_name, lp_desc=lp_desc, lp_level=lp_level,
                                                              expert_name=expert_name, connected=connected,
                                                              ch_type='ch_type', ch_empty=ch_empty, ch_sort=ch_sort)
        Log.info(response.status_code)
        assert response.status_code == 400
        sheet_column = response.json()['errors'][0]['column']
        err_message = response.json()['errors'][0]['message']
        assert sheet_column == "Channel sheet channel_type"
        assert err_message == ERR_MULTIPLE_MESSAGE

    def test_verify_channel_metadata_blank(self, basic_auth):
        Log.info("test_verify_channel_metadata_blank")
        response = self.lp_creation.upload_learning_plan_file(APP_URL, basic_auth, pre_fix=pre_fix, post_fix=post_fix,
                                                              course_type=course_type,
                                                              lp_name=lp_name, lp_desc=lp_desc, lp_level=lp_level,
                                                              expert_name=expert_name, connected=connected,
                                                              ch_type=ch_type, ch_empty=ch_empty, ch_sort=ch_sort)
        Log.info("printing status_code")
        Log.debug(response.status_code)
        assert response.status_code == 200
