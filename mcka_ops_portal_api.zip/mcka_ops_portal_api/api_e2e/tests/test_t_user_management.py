import email
import time

from test.mcka_ops_portal_api.api_e2e.api_library.t_user_management import TUserManagement
from test.mcka_ops_portal_api.config import *


class TestTUserManagement:
    test_user_management = TUserManagement()
    logger = Log

    def test_create_deactivate_activate_delete_test_user_management(self, basic_auth):
        """
        (Test User Management) Create, deactivate, activate and delete the test user(s) along with all
        required validations
        """
        user_id_start = 1
        response = self.test_user_management.create_test_user_management(basic_auth, user_id_start=user_id_start)
        response_body = self.test_user_management.get_content(response)
        assert STATUS_CODE_GOOD == response.status_code

        transaction_id = self.test_user_management.get_transaction_id(response_body)

        assert self.test_user_management.compare_expected_and_actual_result(response_body, success_key, true_value)
        assert self.test_user_management.validate_created_updated_users_response(response_body['users'], user_id_start,
                                                                                 true_value)

        program_report_response = self.test_user_management.get_program_report(basic_auth, enrolled_session_program_id)
        program_report_response_body = self.test_user_management.get_content(program_report_response)

        program_report_t_id = program_report_response_body[
            'activities_status']['course_prod']['test_users_creation']['transaction_ids'][0]
        assert program_report_t_id == transaction_id

        # create_new_test_user_management
        response = self.test_user_management.create_new_test_user_management(basic_auth, user_id_start=user_id_start,
                                                                             transaction_id=transaction_id)
        response_body = self.test_user_management.get_content(response)

        assert STATUS_CODE_GOOD == response.status_code
        transaction_id = self.test_user_management.get_transaction_id(response_body)

        assert self.test_user_management.compare_expected_and_actual_result(response_body, success_key, true_value)
        assert self.test_user_management.validate_created_updated_users_response(
            response_body['users'], user_id_start, true_value)

        api_report_t_id_response = self.test_user_management.get_api_report_transaction_id(basic_auth, transaction_id)
        api_report_t_id_response_body = self.test_user_management.get_content(api_report_t_id_response)
        users, user_count = self.test_user_management.get_users_and_users_count(api_report_t_id_response_body)

        assert self.test_user_management.compare_expected_and_actual_result(api_report_t_id_response_body,
                                                                            in_progress_key, false_value)
        assert self.test_user_management.validate_created_updated_users_response(
            api_report_t_id_response_body['data']['Landing Page 0'], user_id_start, true_value)
        time.sleep(5)

        # update password one user
        response = self.test_user_management.update_users_password(basic_auth, [users[0]], transaction_id)
        response_body = self.test_user_management.get_content(response)
        assert STATUS_CODE_GOOD == response.status_code

        assert self.test_user_management.compare_expected_and_actual_result(response_body, success_key, true_value)
        assert self.test_user_management.compare_expected_and_actual_result(response_body, transaction_id_key,
                                                                            transaction_id)
        assert self.test_user_management.validate_created_updated_users_response(
            response_body['users'], user_id_start, true_value)
        time.sleep(2)

        # update password multi users
        response = self.test_user_management.update_users_password(basic_auth, users, transaction_id)
        response_body = self.test_user_management.get_content(response)
        assert STATUS_CODE_GOOD == response.status_code

        assert self.test_user_management.compare_expected_and_actual_result(response_body, success_key, true_value)
        assert self.test_user_management.compare_expected_and_actual_result(
            response_body, transaction_id_key, transaction_id)
        assert self.test_user_management.validate_created_updated_users_response(
            response_body['users'], user_id_start, true_value)
        time.sleep(2)

        # deactivate one user
        response = self.test_user_management.deactivate_users(basic_auth, [users[0]], transaction_id)
        response_body = self.test_user_management.get_content(response)
        assert STATUS_CODE_GOOD == response.status_code

        assert self.test_user_management.compare_expected_and_actual_result(response_body, success_key, true_value)
        assert self.test_user_management.compare_expected_and_actual_result(response_body, transaction_id_key,
                                                                            transaction_id)
        assert self.test_user_management.validate_created_updated_users_response(
            response_body['users'], user_id_start, false_value)
        time.sleep(2)

        # activate one user
        response = self.test_user_management.activate_users(basic_auth, [users[0]], transaction_id)
        response_body = self.test_user_management.get_content(response)
        assert STATUS_CODE_GOOD == response.status_code

        assert self.test_user_management.compare_expected_and_actual_result(response_body, success_key, true_value)
        assert self.test_user_management.compare_expected_and_actual_result(response_body, transaction_id_key,
                                                                            transaction_id)
        assert self.test_user_management.validate_created_updated_users_response(response_body['users'], user_id_start,
                                                                                 true_value)
        time.sleep(2)

        # deactivate multi users
        response = self.test_user_management.deactivate_users(basic_auth, users, transaction_id)
        response_body = self.test_user_management.get_content(response)
        assert STATUS_CODE_GOOD == response.status_code

        assert self.test_user_management.compare_expected_and_actual_result(response_body, success_key, true_value)
        assert self.test_user_management.compare_expected_and_actual_result(response_body, transaction_id_key,
                                                                            transaction_id)
        assert self.test_user_management.validate_created_updated_users_response(response_body['users'], user_id_start, false_value)
        time.sleep(2)

        # activate multi users
        response = self.test_user_management.activate_users(basic_auth, users, transaction_id)
        response_body = self.test_user_management.get_content(response)
        assert STATUS_CODE_GOOD == response.status_code

        assert self.test_user_management.compare_expected_and_actual_result(response_body, success_key, true_value)
        assert self.test_user_management.compare_expected_and_actual_result(response_body, transaction_id_key,
                                                                            transaction_id)
        assert self.test_user_management.validate_created_updated_users_response(response_body['users'], user_id_start,
                                                                                 true_value)
        time.sleep(2)
        # create test_user_management_new_learning_exp
        response = self.test_user_management.create_test_user_with_new_learning_plan_exp(
            basic_auth, transaction_id, user_id_start)
        response_body_new_exp = self.test_user_management.get_content(response)
        assert STATUS_CODE_GOOD == response.status_code

        time.sleep(2)
        # create test_user_management_new_learning_plan
        response = self.test_user_management.create_test_user_with_new_learning_plan_exp(
            basic_auth, transaction_id, user_id_start + 2, lp=["REP_TEST_OCT22"])
        response_body_new_lp = self.test_user_management.get_content(response)
        assert STATUS_CODE_GOOD == response.status_code

        time.sleep(2)
        api_report_t_id_response = self.test_user_management.get_api_report_transaction_id(basic_auth, transaction_id)
        api_report_t_id_response_body = self.test_user_management.get_content(api_report_t_id_response)
        users_with_new_learning_plan_exp, user_count = self.test_user_management.get_users_and_users_count(
            api_report_t_id_response_body, primary_exp='Landing Page 1')
        assert self.test_user_management.validate_created_updated_users_response(
            api_report_t_id_response_body['data']['Landing Page 1'], user_id_start, true_value, 'Landing_Page_1')
        time.sleep(2)

        time.sleep(2)
        # delete all users here
        self.test_user_management.delete_users(basic_auth, users_with_new_learning_plan_exp, transaction_id)
        delete_user_response = self.test_user_management.delete_users(basic_auth, users, transaction_id)
        delete_user_response_body = self.test_user_management.get_content(delete_user_response)
        assert STATUS_CODE_GOOD == response.status_code

        assert self.test_user_management.compare_expected_and_actual_result(delete_user_response_body, success_key,
                                                                            true_value)
        assert self.test_user_management.compare_expected_and_actual_result(delete_user_response_body, message_key,
                                                                            delete_user_message)
