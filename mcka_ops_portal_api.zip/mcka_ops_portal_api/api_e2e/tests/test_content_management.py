from test.mcka_ops_portal_api.api_e2e.api_library.content_management import ContentManagement
from test.mcka_ops_portal_api.config import (
    STATUS_CODE_GOOD, success_key, true_value, eop_key, docebo_url_key, docebo_lms_url, last_refreshed_key, text_key,
    cm_languages_endpoint, message_key, component_code_already_exists_message, existing_component_name, data_key,
    copy_component_code_without_lp, incorrect_copy_component_message, check_component_eop_endpoint, false_value, id_key,
    error_key, course_code_text, validation_passed_message, update_program, update_content_management_course, code_key,
    courses_languages, updated_component_endpoint, is_published_key, copy_component_success_message, course_not_found,
    update_eop_tag_endpoint, incorrect_update_eop_tag_endpoint, name_key, REQUESTED_PAGE_NOT_FOUND_STATUS_CODE,
    error_key_key, )


class TestContentManagement:
    content_management = ContentManagement()

    def test_view_component(self, basic_auth):
        """
        (Content Management) View and verify component details like: 200 code, eop_key, success_key, instructors' list
        """
        response = self.content_management.get_response_of_view_component(basic_auth)
        response_body = self.content_management.get_content(response)
        self.content_management.get_value_of_view_component_data(response_body, "instructors")
        assert STATUS_CODE_GOOD == response.status_code
        assert self.content_management.compare_expected_and_actual_result(response_body, success_key, true_value)
        assert self.content_management.verify_value_not_exist(response_body, eop_key, None)

    def test_refresh_content_management(self, basic_auth):
        """
        (Content Management)
        """
        response = self.content_management.refresh_content_management(basic_auth)
        response_body = self.content_management.get_content(response)
        assert STATUS_CODE_GOOD == response.status_code
        assert self.content_management.compare_expected_and_actual_result(response_body, success_key, true_value)
        assert self.content_management.compare_expected_and_actual_result(response_body, docebo_url_key,
                                                                          docebo_lms_url[:-1])
        assert self.content_management.verify_key_exist_with_valid_value_type(response_body, last_refreshed_key)

    def test_languages_content_management(self, basic_auth):
        """
        (Content Management) Verify all languages end point of content management
        """
        response = self.content_management._get(cm_languages_endpoint, basic_auth)
        response_body = self.content_management.get_content(response)
        assert STATUS_CODE_GOOD == response.status_code
        assert self.content_management.compare_expected_and_actual_result(response_body, success_key, true_value)
        assert self.content_management.verify_languages(response_body, courses_languages)

    def test_copy_content_management_success(self, basic_auth):
        """
        (Content Management)
        """
        response = self.content_management.validate_copy_component(basic_auth)
        response_body = self.content_management.get_content(response)
        assert STATUS_CODE_GOOD == response.status_code
        assert self.content_management.compare_expected_and_actual_result(response_body, success_key, true_value)
        assert self.content_management.compare_expected_and_actual_result(response_body, message_key,
                                                                          validation_passed_message)

        response, copy_component_payload = self.content_management.copy_component(basic_auth)
        response_body = self.content_management.get_content(response)
        assert STATUS_CODE_GOOD == response.status_code
        assert self.content_management.compare_expected_and_actual_result(response_body, success_key, true_value)
        assert self.content_management.compare_expected_and_actual_result(
            response_body, message_key,
            copy_component_success_message.format(copy_component_payload['new_component_code']))

    def test_copy_content_management_failure(self, basic_auth):
        """
        (Content Management)
        """
        response = self.content_management.validate_copy_component(basic_auth, existing_component_name)
        response_body = self.content_management.get_content(response)
        assert STATUS_CODE_GOOD == response.status_code
        assert self.content_management.compare_expected_and_actual_result(response_body, success_key, false_value)
        assert self.content_management.compare_expected_and_actual_result(response_body, error_key_key,
                                                                          course_code_text)
        assert self.content_management.compare_expected_and_actual_result(response_body, message_key,
                                                                          component_code_already_exists_message)

        response = self.content_management.validate_copy_component(basic_auth, copy_component_code_without_lp)
        response_body = self.content_management.get_content(response)
        assert STATUS_CODE_GOOD == response.status_code
        assert self.content_management.compare_expected_and_actual_result(response_body, success_key, false_value)
        assert self.content_management.compare_expected_and_actual_result(response_body, error_key_key,
                                                                          course_code_text)
        assert self.content_management.compare_expected_and_actual_result(response_body, message_key,
                                                                          incorrect_copy_component_message)

        response, _ = self.content_management.copy_component(basic_auth, copy_component_code_without_lp)
        response_body = self.content_management.get_content(response)
        assert STATUS_CODE_GOOD == response.status_code
        assert self.content_management.compare_expected_and_actual_result(response_body, success_key, false_value)
        assert self.content_management.compare_expected_and_actual_result(response_body, message_key,
                                                                          incorrect_copy_component_message)

    def test_assigning_eop_tag_success(self, basic_auth):
        """
        (Content Management) assigning and un-assigning eop tag
        """

        response = self.content_management._post(update_eop_tag_endpoint, {'eop': True}, cookie='', token=basic_auth)
        response_body = self.content_management.get_content(response)
        assert STATUS_CODE_GOOD == response.status_code
        assert self.content_management.compare_expected_and_actual_result(response_body, success_key, true_value)

        response = self.content_management._get(check_component_eop_endpoint, basic_auth)
        response_body = self.content_management.get_content(response)
        assert STATUS_CODE_GOOD == response.status_code
        assert self.content_management.compare_expected_and_actual_result(response_body, eop_key, true_value)

        response = self.content_management._post(update_eop_tag_endpoint, {'eop': False}, cookie='', token=basic_auth)
        response_body = self.content_management.get_content(response)
        assert STATUS_CODE_GOOD == response.status_code
        assert self.content_management.compare_expected_and_actual_result(response_body, success_key, true_value)

        response = self.content_management._get(check_component_eop_endpoint, basic_auth)
        response_body = self.content_management.get_content(response)
        assert STATUS_CODE_GOOD == response.status_code
        assert self.content_management.compare_expected_and_actual_result(response_body, eop_key, false_value)

    def test_assigning_eop_tag_failure(self, basic_auth):
        """
        (Content Management) assigning and un-assigning eop tag
        """
        response = self.content_management._post(incorrect_update_eop_tag_endpoint, {'eop': True}, cookie='',
                                                 token=basic_auth)
        response_body = self.content_management.get_content(response)
        assert REQUESTED_PAGE_NOT_FOUND_STATUS_CODE == response.status_code
        assert self.content_management.compare_expected_and_actual_result(response_body, success_key, false_value)
        assert self.content_management.compare_expected_and_actual_result(response_body, error_key, course_not_found)

    def test_update_program(self, basic_auth):
        """
        (Content Management)
        """
        response, updated_component_code_name = self.content_management.update_program(basic_auth)
        response_body = self.content_management.get_content(response)
        assert STATUS_CODE_GOOD == response.status_code
        assert self.content_management.compare_expected_and_actual_result(response_body, success_key, true_value)
        assert self.content_management.compare_expected_and_actual_result(response_body["message"], text_key,
                                                                          update_content_management_course)

        response = self.content_management._get(f'{updated_component_endpoint}{update_content_management_course}',
                                                basic_auth)
        response_body = self.content_management.get_content(response)

        assert self.content_management.compare_expected_and_actual_result(response_body[data_key][0], id_key,
                                                                          update_content_management_course)
        assert self.content_management.compare_expected_and_actual_result(response_body[data_key][0], name_key,
                                                                          updated_component_code_name[0])
        assert self.content_management.compare_expected_and_actual_result(response_body[data_key][0], code_key,
                                                                          updated_component_code_name[1])
        assert self.content_management.verify_value_not_exist(response_body, eop_key, False)

    def test_course_published_locked(self, basic_auth):
        """
        (Content Management)
        """
        response = self.content_management._put(update_program, {"status": "published"}, cookie='', token=basic_auth)
        response_body = self.content_management.get_content(response)
        assert STATUS_CODE_GOOD == response.status_code
        assert self.content_management.compare_expected_and_actual_result(response_body, success_key, true_value)
        assert self.content_management.compare_expected_and_actual_result(response_body["message"], text_key,
                                                                          update_content_management_course)

        response = self.content_management._get(f'{updated_component_endpoint}{update_content_management_course}',
                                                basic_auth)
        response_body = self.content_management.get_content(response)
        assert self.content_management.compare_expected_and_actual_result(response_body[data_key][0], is_published_key,
                                                                          true_value)

        response = self.content_management._put(update_program, {"status": "unpublished"}, cookie='', token=basic_auth)
        response_body = self.content_management.get_content(response)
        assert STATUS_CODE_GOOD == response.status_code
        assert self.content_management.compare_expected_and_actual_result(response_body, success_key, true_value)
        assert self.content_management.compare_expected_and_actual_result(response_body[message_key], text_key,
                                                                          update_content_management_course)
        response = self.content_management._get(f'{updated_component_endpoint}{update_content_management_course}',
                                                basic_auth)
        response_body = self.content_management.get_content(response)
        assert self.content_management.compare_expected_and_actual_result(response_body[data_key][0], is_published_key,
                                                                          false_value)
