from ..api_library.replications import Replication
from ...resources import REPLICATION_TIMELINE
from ...config import *
import pytest


class TestReplicationsScenarios:
    replication = Replication()
    logger = Log

    @pytest.mark.DEMO_PROD
    def test_validate_a_program_with_a_similar_config_id_already_exists(self, basic_auth):
        """
        On Replication Home page Validate a program with a similar config id already exists.
        - status code must be 409
        - success key exist with value true
        - message key exist and contains value “A program with a similar config id already exists.
        - A list located with config id already present in it
        """
        response = self.replication.get_response(api_keyword, config_id, basic_auth)
        response_body = self.replication.get_content(response)
        self.logger.info(response_body)
        status_code = self.replication.get_status_code(response)
        self.logger.info(f"status code: {status_code}")
        assert CONFLICT_RESPONSE_STATUS_CODE_409 == status_code
        assert self.replication.verify_entry(response_body, success_key, true_value)
        self.logger.info("success key exist having some value in it")

        assert self.replication.verify_entry(response_body, unique_key, false_value)
        self.logger.info("success key exist having some value in it")

        assert self.replication.compare_expected_and_actual_result(response_body, message_key, raw_message)
        self.logger.info(f"message key found having value as: {config_id}")

        assert self.replication.compare_expected_and_actual_result(response_body, message_key, raw_message)
        self.logger.info(f"message key found having value as: {config_id}")
        assert self.replication.verify_similar_id_exist(response_body)
        self.logger.info("A list located with config id already present in it")

    @pytest.mark.DEMO_PROD
    def test_validate_a_program_with_a_keyword_of_already_existing_config_id(self, basic_auth):
        """
        Submit a request by passing 1 keyword as config id that belongs to some Plan amd it must fail
         the request with details
        - status code to be 409
        - unique key exist with value as false
        - message key exist with value contains Existing similar config id(s): all Names
        """
        new_id = self.replication.get_keyword_from_config_id()
        response = self.replication.get_response(api_keyword, new_id, basic_auth)
        response_body = self.replication.get_content(response)
        self.logger.info(response_body)
        status_code = self.replication.get_status_code(response)
        self.logger.info(f"status code: {status_code}")
        assert CONFLICT_RESPONSE_STATUS_CODE_409 == status_code
        assert self.replication.verify_entry(response_body, success_key, true_value)
        self.logger.info("success key exist having true as value in it")
        assert self.replication.compare_expected_and_actual_result(response_body, unique_key, false_value)
        self.logger.info(f"a key named as unique exist with value to be {false_value}")
        assert self.replication.compare_expected_and_actual_result(response_body, message_key, raw_message)
        self.logger.info(f"message key found having value as: {message}")

    @pytest.mark.DEMO_PROD
    def test_validate_a_program_with_a_unique_config_id(self, basic_auth):
        """
        Submit a request with unique config id and validate
        - status code to be 200
        - Message key exist and should have value "Success"
        - unique key exist and should have value "true"
        - success key exist with value "true"
        """
        response = self.replication.get_response(api_keyword, unique_config_id, basic_auth)
        response_body = self.replication.get_content(response)
        self.logger.info(response_body)
        status_code = self.replication.get_status_code(response)
        self.logger.info(f"status code: {status_code}")
        assert STATUS_CODE_GOOD == status_code
        assert self.replication.verify_entry(response_body, success_key, true_value)
        self.logger.info("success key exist having some value in it")
        assert self.replication.compare_expected_and_actual_result(response_body, unique_key, true_value)
        self.logger.info(f"A key named as unique exist with value to be {true_value}")
        assert self.replication.compare_expected_and_actual_result(response_body, message_key, success_message)
        self.logger.info(f"message key found having value as: {success_message}")

    @pytest.mark.DEMO_PROD
    def test_validate_a_program_with_config_id_greater_than_range(self, basic_auth):
        """

        Submit a request with config id that has length greater than 25
        - status code to be 400
        - Message key exist and should have value "Config id length must be in range"
        - success key exist with value "false"
        """
        response = self.replication.get_response(api_keyword, over_range_config_id, basic_auth)
        response_body = self.replication.get_content(response)
        self.logger.info(response_body)
        status_code = self.replication.get_status_code(response)
        self.logger.info(f"status code: {status_code}")
        assert BAD_REQUEST_STATUS_CODE_400 == status_code
        assert self.replication.verify_entry(response_body, success_key, false_value)
        self.logger.info(f"success key exist having some value :{false_value} in it")

        assert self.replication.compare_expected_and_actual_result(response_body, message_key, out_of_range)
        self.logger.info(f"message key found having value as: {out_of_range}")

    @pytest.mark.DEMO_PROD
    def test_validate_a_program_with_no_config_id(self, basic_auth):
        """

        Submit a request with bo config id
        - status code to be 404
        - Message key exist and should have value "Config id length must be in range"
        - success key exist with value "false"
        """
        response = self.replication.get_response(api_keyword, empty_config_id, basic_auth)
        response_body = self.replication.get_content(response)
        self.logger.info(response_body)
        status_code = self.replication.get_status_code(response)
        self.logger.info(f"status code: {status_code}")
        assert REQUESTED_PAGE_NOT_FOUND_STATUS_CODE == status_code
        assert self.replication.compare_expected_and_actual_result(response_body, message_key, no_config_id)
        self.logger.info(f"message key found having value as: {no_config_id}")

    @pytest.mark.DEMO_PROD
    def test_validate_scorms(self, basic_auth):
        """
        Pass valid config id and hit next will lists an api /replication/docebo/{config_id_of_lp}/scorms
        validate below things with parent project id:
        - status code to be 200
        - success key exist with value true
        - limit_exceeded key exist with value as true

        validate a key exist named as data and have one LP with following details
        - code key exist with value as config id that we have saved
        - id key exist with value as lp_id
        - description key exist with some valid description
        - name key exist with valid name
        validate a key exist named as data and have 4 courses having following details each
        - course_code key exist for each course and have config id of program in it
        - course_type key exist for each course and have either e-learning or classroom as type
        - course_id key exist and have value as int
        - course_name exist and must have value as string
        - image key exist and have valid url --> starting with http
        - lo key exist for each course but for scorm attachment it must have values to be validated
            - is_project_id_valid key exist and have value as true
            - lo_id exist and have int as value
            - lo_name exist with value as valid string
            - new_project_id key exist with value not None
            - original_project_id key exist with value not None
            - original_project_id_status key exist with value as VALID
            - project_id_status key exist with value as VALID
            - project_name key exist with value not None
        """
        response = self.replication.get_response(f'docebo/{lp_config_id}', scorm_api, basic_auth)
        response_body = self.replication.get_content(response)
        self.logger.info(response_body)
        status_code = self.replication.get_status_code(response)
        self.logger.info(f"status code: {status_code}")
        assert STATUS_CODE_GOOD == status_code
        assert self.replication.verify_entry(response_body, success_key, true_value)
        self.logger.info(f"success key exist having value :{true_value} in it")
        assert self.replication.verify_entry(response_body, limit_exceeded_key, false_value)
        self.logger.info(f"limit_exceeded key exist having value :{limit_exceeded_key} in it")
        assert self.replication.validate_lp_details_from_scorms(response_body)
        self.logger.info("LP is validated successfully")
        assert self.replication.validate_courses_details_from_scorms(response_body)

    def test_validate_scorms_having_parent_id(self, basic_auth):
        """
        Pass replicated config id and hit next will lists an api /replication/docebo/{config_id_of_replicated_lp}/scorms
        validate below things with parent project id:
        - status code to be 200
        - success key exist with value true
        - limit_exceeded key exist with value as true
        In 1 course we have Lo key available and need to check following things
        - lo key exist for each course but for scorm attachment it must have values to be validated
            - is_project_id_valid key exist and have value as true
            - lo_id exist and have int as value
            - lo_name exist with value as valid string
            - new_project_id key exist with value as 6204a3d7059e6
            - original_project_id key exist with value as 6204a3d7059e6
            - original_project_id_status key exist with value as Valid
            - project_id_status key exist with value as VALID
            - project_name key exist with value some Valid Value
        """
        response = self.replication.get_response(f'docebo/{rep_config_id}', scorm_api, basic_auth)
        response_body = self.replication.get_content(response)
        self.logger.info(response_body)
        status_code = self.replication.get_status_code(response)
        self.logger.info(f"status code: {status_code}")
        assert STATUS_CODE_GOOD == status_code
        assert self.replication.verify_entry(response_body, success_key, true_value)
        self.logger.info(f"success key exist having value :{true_value} in it")
        assert self.replication.verify_entry(response_body, limit_exceeded_key, false_value)
        self.logger.info(f"limit_exceeded key exist having value :{limit_exceeded_key} in it")
        assert self.replication.validate_lo_details(response_body)
        self.logger.info("we are getting 2 values now : original_project_id and new_project_id")

    @pytest.mark.DEMO_PROD
    def test_validate_valid_new_project_id(self, basic_auth):
        """
        Pass valid new project id and validate
        - status code to be 200
        - success key exist with value true
        - name key exist with some valid value
        - valid key exist with value true

        """
        response = self.replication.get_response(project_id_api, valid_project_id, basic_auth)
        response_body = self.replication.get_content(response)
        self.logger.info(response_body)
        status_code = self.replication.get_status_code(response)
        self.logger.info(f"status code: {status_code}")
        assert STATUS_CODE_GOOD == status_code

        assert self.replication.verify_entry(response_body, success_key, true_value)
        self.logger.info(f"success key exist having value :{true_value} in it")

        assert self.replication.verify_key_exist_with_valid_value_type(response_body, name_key)
        self.logger.info(f"{name_key} key exist having some valid valid in it")

        assert self.replication.verify_entry(response_body, valid_key, true_value)
        self.logger.info(f"{valid_key} key exist having value :{true_value} in it")

    @pytest.mark.DEMO_PROD
    def test_validate_invalid_new_project_id(self, basic_auth):
        """
        Pass invalid new project id and validate
        - status code to be 200
        - success key exist with value true
        - name key exist with value None
        - valid key exist with value false
        """
        response = self.replication.get_response(project_id_api, invalid_project_id, basic_auth)
        response_body = self.replication.get_content(response)
        self.logger.info(response_body)
        status_code = self.replication.get_status_code(response)
        self.logger.info(f"status code: {status_code}")
        assert STATUS_CODE_GOOD == status_code

        assert self.replication.verify_entry(response_body, success_key, true_value)
        self.logger.info(f"success key exist having value :{true_value} in it")

        assert self.replication.compare_expected_and_actual_result(response_body, name_key, None)
        self.logger.info(f"{name_key} key exist having some valid valid in it")

        assert self.replication.verify_entry(response_body, valid_key, false_value)
        self.logger.info(f"{valid_key} key exist having value :{false_value} in it")

    def test_validate_a_program_having_channel_attached(self, basic_auth):
        """
        Submit a request with fixed channel id and validate below things
        - status code to be 200
        - channel name must match with name provided
        - success key exist with value "true"
        - values exist for the keys ("channel_id", "docebo_id")
        - we have 4 assets attached with different types and names validate assets types and names
        """
        response = self.replication._get(url=channel_api + channel_id, token=basic_auth)
        response_body = self.replication.get_content(response)
        self.logger.info(response_body)
        status_code = self.replication.get_status_code(response)
        self.logger.info(f"status code: {status_code}")
        assert STATUS_CODE_GOOD == status_code
        assert self.replication.compare_expected_and_actual_result(response_body, success_key, true_value)
        self.logger.info(f"success key found having value as: {true_value}")
        assert self.replication.validate_default_channel_details(response_body)
        self.logger.info("channel name matched with name provided")
        # assert self.replication.validate_default_channel_assets(response_body)
        # self.logger.info("All Assets exit having valid names and types")

    def test_validate_a_program_with_no_channel_attached(self, basic_auth):
        """
        Submit a request with having no channel attached to a program
        - status code to be 200
        - success key exist with value "true"
        - data key exist and have value as empty list
        """
        response = self.replication._get(url=channel_api + program_with_no_channel, token=basic_auth)
        response_body = self.replication.get_content(response)
        self.logger.info(response_body)
        status_code = self.replication.get_status_code(response)
        self.logger.info(f"status code: {status_code}")
        assert STATUS_CODE_GOOD == status_code
        assert self.replication.compare_expected_and_actual_result(response_body, success_key, true_value)
        self.logger.info(f"success key found having value as: {true_value}")
        assert self.replication.verify_no_channel_found(response_body)
        self.logger.info("No channel located for the selected program")

    def test_replicate_a_program_having_no_channel(self, basic_auth):
        """
        In this case we have learning plan created with no channel in it so we are going to replicate
         a similar kind of program
        we will hit scorms api to get courses and lp details
        - status code to be 200
        - success key exist with value to be True
        - transaction_id key exist with value as int and store that id for future use as well

        Use transaction id and submit replication api and validate
        - status code to be 200
        - no channel exist when program got replicated
        - done key exist with value as true
        - estimated_time_left key exist having value as: int
        - "estimated_time_left key exist having value as: 0"
        - "percentage key found having value as: 100"

        hit /api/report/program/{p_id} page api to fetch results and validate
        - status code to be 200
        - verify "Program id matched with the id we got from replicated program"
        - verify replicated key exist with value to be True
        - verify stage key exist and have value STAGE_REPLICATED
        """
        transaction_id = self.replication.generate_transaction_id(
            basic_auth=basic_auth,
            lp_id=lp_config_id_without_channel,
            con_id=config_id_without_channel,
            p_id=program_with_no_channel
        )

        details = self.replication.replication_completed(task_key=transaction_id, token=basic_auth)
        self.logger.info(details)
        assert self.replication.verify_replicated_program_details(details)
        self.logger.info("estimated_time_left key exist having value as: int")
        assert self.replication.verify_channel_details(details)
        self.logger.info("no channel exist when program got replicated")
        p_id = self.replication.get_program_id_from_rep_success(details)
        response = self.replication._get(url=report_api + str(p_id), token=basic_auth)
        response_body = self.replication.get_content(response)
        self.logger.info(response_body)
        status_code = self.replication.get_status_code(response)
        self.logger.info(f"status code: {status_code}")
        assert STATUS_CODE_GOOD == status_code
        # assert self.replication.validate_program_information(response_body)
        # self.logger.info("All fields mentioned in test case exist and have valid values")
        assert self.replication.compare_expected_and_actual_result(response_body, PROGRAM_ID, p_id)
        self.logger.info("Program id matched with the id we got from replicated program")
        assert self.replication.verify_entry(response_body, replicated_key, true_value)
        self.logger.info("Replication value is coming as True so program replicated successfully")
        assert self.replication.compare_expected_and_actual_result(response_body, stage_key, stage_value)
        self.logger.info(f"{stage_key} key exist and have value {stage_value}")

    def test_replicate_a_program_with_enrollment_into_existing_channel(self, basic_auth):
        """
        In this case we have learning plan created with 1 channel(same name) in it so we are going to replicate a program
        we will hit scorms api to get courses and lp details
        - status code to be 200
        - transaction_id key exist with value as int and store that id for future use as well

        Use transaction id and submit replication api and validate
        - status code to be 200
        - in report key we must have channels key and it contains values like
         ["source_channel_name", "status", "channel_name", "docebo_id"] these values must match with actual values
        - done key exist with value as true
        - estimated_time_left key exist having value as: int
        - "estimated_time_left key exist having value as: 0"
        - "percentage key found having value as: 100"

        - plan got replicated and all lp related fields got validated as well
        - metadata fields got validated as well
        - Group got created successfully
        - enrollment rule got created with all other details
        - "Courses got created successfully"

        """
        transaction_id = self.replication.generate_transaction_id(
            basic_auth=basic_auth, lp_id=lp_config_id,
            con_id=config_id, p_id=program_id, channel_exist=True, link_assets=True
        )
        details = self.replication.replication_completed(task_key=transaction_id, token=basic_auth)
        self.logger.info(details)
        assert self.replication.verify_replicated_program_details(details)
        self.logger.info(Log.info("estimated_time_left key exist having value as: int"))
        assert self.replication.verify_channel_got_created(details)
        self.logger.info("channel exists when program got replicated")
        assert self.replication.verify_channel_got_created_with_content(details)
        self.logger.info("channel content exists when program got replicated")
        p_id = self.replication.get_program_id_from_rep_success(details)
        self.logger.info(f"replicated program id located and value is {p_id}")
        assert self.replication.validate_lp_details(details)
        self.logger.info("plan got replicated and all lp related fields got validated as well")
        assert self.replication.validate_meta_data(details, [config_id, program_id])
        self.logger.info("meta data fields got validated as well")
        assert self.replication.verify_group_got_created(details)
        self.logger.info("Group got created successfully")
        assert self.replication.verify_enrollment_rule_details(details)
        self.logger.info("Enrollment Rule got created successfully with all attached fields")
        assert self.replication.verify_courses_got_created(details)
        self.logger.info("Courses got created successfully")

    def test_replicate_a_program_and_create_new_channel_with_no_assets(self, basic_auth):
        """
        In this case we have learning plan created with new channel and No assets so we are going to replicate a program
        we will hit scorms api to get courses and lp details
        - status code to be 200
        - transaction_id key exist with value as int and store that id for future use as well

        Use transaction id and submit replication api and validate
        - status code to be 200
        - in report key we must have channels key and it contains values like
         ["source_channel_name", "status", "channel_name", "docebo_id"] these values must match with actual values
        - done key exist with value as true
        - estimated_time_left key exist having value as: int
        - "estimated_time_left key exist having value as: 0"
        - "percentage key found having value as: 100"
        - "Channel got created without any assets"

        """
        ch_name = self.replication.create_channel_name()
        self.logger.info(ch_name)
        transaction_id = self.replication.generate_transaction_id(
            basic_auth=basic_auth, lp_id=lp_config_id,
            con_id=config_id, p_id=program_id, channel_exist=True, new_channel_name=ch_name
        )
        details = self.replication.replication_completed(task_key=transaction_id, token=basic_auth)
        self.logger.info(details)
        assert self.replication.verify_replicated_program_details(details)
        self.logger.info(Log.info("estimated_time_left key exist having value as: int"))
        assert self.replication.verify_channel_got_created(details, new_channel_name=ch_name)
        self.logger.info(f"Channel got created having name {ch_name}")
        assert self.replication.verify_channel_content_is_empty(details)
        self.logger.info("Channel got created without any assets")

    def test_replicate_a_replicated_program_having_no_channel(self, basic_auth):
        """
        In this case we have learning plan created with no channel in it so we are going to replicate
         a program that is already replicated
        we will hit scorms api to get courses and lp details
        - status code to be 200
        - success key exist with value to be True
        - transaction_id key exist with value as int and store that id for future use as well

        Use transaction id and submit replication api and validate
        - status code to be 200

        hit /api/program/homepage api to fetch results and validate (MAPOAS-1418)
        On home page the replicated program is created successfully by hitting all programs api
        - status code to be 200
        - verify "Program id matched with the id we got from replicated program"
        - verify replicated key exist with value to be True
        - verify stage key exist and have value STAGE_REPLICATED
        """
        transaction_id = self.replication.generate_transaction_id(
            basic_auth=basic_auth,
            lp_id=lp_config_id_alr_rep,
            con_id=config_id_alr_rep,
            p_id=program_id_already_rep,
            parent_id=True
        )
        details = self.replication.replication_completed(task_key=transaction_id, token=basic_auth)
        self.logger.info(details)
        assert self.replication.verify_channel_details(details)
        self.logger.info("response of replicated program without channel should not have a new or duplicated channel")
        p_id = self.replication.get_program_id_from_rep_success(details)
        response = self.replication._get(url=programs + 'STAGE_REPLICATED', token=basic_auth)
        response_body = self.replication.get_content(response)
        self.logger.info(response_body)
        status_code = self.replication.get_status_code(response)
        self.logger.info(f"status code: {status_code}")
        assert STATUS_CODE_GOOD == status_code
        assert self.replication.validate_replication_details(response_body, p_id)
        self.logger.info('On home page the replicated program is created successfully by hitting all programs api')

    def test_replicate_a_program_having_no_courses(self, basic_auth):
        """
        In this case we have learning plan created with no courses in it.
        we will hit scorms api to get validate courses key exist and have value as []
        - status code to be 200
        - success key exist with value to be True
        - limit_exceeded key exist having value false in it
        - courses key exist with value as empty list
        """
        response = self.replication.get_response(f'docebo/{lp_config_id_no_course}', scorm_api, basic_auth)
        response_body = self.replication.get_content(response)
        self.logger.info(response_body)
        status_code = self.replication.get_status_code(response)
        self.logger.info(f"status code: {status_code}")
        assert STATUS_CODE_GOOD == status_code
        assert self.replication.verify_entry(response_body, success_key, true_value)
        self.logger.info(f"success key exist having value :{true_value} in it")
        assert self.replication.verify_entry(response_body, limit_exceeded_key, false_value)
        self.logger.info(f"limit_exceeded key exist having value :{limit_exceeded_key} in it")
        assert self.replication.verify_no_course_available(response_body)
        self.logger.info("We can replicated a program having no courses")

    def test_replication_timeline(self, basic_auth):
        """
        Access replication timeline api and validate
        - status code to be 200
        - data key exist having a list with all the programs that got replicated from specifc program
        - match source_program_id with actual program id
        - status key exist with value completed
        - match source_config_id with actual id
        - replication_success key exist with value as true
        - destination_config_id
        - destination_program_id
        - channel_created
        - created_by

        """
        response = self.replication._get(url=REPLICATION_TIMELINE, token=basic_auth)
        response_body = self.replication.get_content(response)
        self.logger.info(response_body)
        status_code = self.replication.get_status_code(response)
        self.logger.info(f"status code: {status_code}")
        assert STATUS_CODE_GOOD == status_code

        assert self.replication.verify_entry(response_body, success_key, true_value)
        self.logger.info(f"success key exist having value :{true_value} in it")

        assert self.replication.verify_key_exist_with_valid_value_type(response_body, data_key)
        self.logger.info(f"{name_key} key exist having some valid valid in it")

        assert self.replication.validate_replication_timeline_response(response_body)
        self.logger.info(f"replication timeline info has been validated")

    def test_validate_replication_with_31_courses(self, basic_auth):
        """
        Pass valid config id and hit next will lists an api /replication/docebo/{config_id_of_lp}/scorms
        validate below things with parent project id:
        - status code to be 200
        - success key exist with value false
        - limit_exceeded key exist with value as true
        - no_of_courses key exist having value as 31
        """
        response = self.replication.get_response(f'docebo/{lp_config_id_of_31_courses}', scorm_api, basic_auth)
        response_body = self.replication.get_content(response)
        self.logger.info(response_body)
        status_code = self.replication.get_status_code(response)
        self.logger.info(f"status code: {status_code}")
        assert STATUS_CODE_GOOD == status_code
        assert self.replication.verify_entry(response_body, success_key, false_value)
        self.logger.info(f"success key exist having value :{false_value} in it")
        assert self.replication.verify_entry(response_body, limit_exceeded_key, true_value)
        self.logger.info(f"limit_exceeded key exist having value :{true_value} in it")
        assert self.replication.compare_expected_and_actual_result(response_body, "no_of_courses", 31)
        self.logger.info("Found more than 30 courses")

    def test_validate_replication_with_181_components(self, basic_auth):
        """
        Pass valid config id and hit next will lists an api /replication/docebo/{config_id_of_lp}/scorms
        validate below things with parent project id:
        - status code to be 200
        - success key exist with value false
        - limit_exceeded key exist with value as true
        - total_components_exceeded key exist having value as 198
        """
        response = self.replication.get_response(f'docebo/{lp_config_id_with_181_components}', scorm_api, basic_auth)
        response_body = self.replication.get_content(response)
        self.logger.info(response_body)
        status_code = self.replication.get_status_code(response)
        self.logger.info(f"status code: {status_code}")
        assert STATUS_CODE_GOOD == status_code
        assert self.replication.verify_entry(response_body, success_key, false_value)
        self.logger.info(f"success key exist having value :{false_value} in it")
        assert self.replication.verify_entry(response_body, limit_exceeded_key, true_value)
        self.logger.info(f"limit_exceeded key exist having value :{true_value} in it")
        assert self.replication.compare_expected_and_actual_result(response_body, "total_components_exceeded", 198)
        self.logger.info("Found more than 180 components(Courses + TMs)")

    def test_validate_replication_with_11_training_materials_in_a_course(self, basic_auth):
        """
        Pass valid config id and hit next will lists an api /replication/docebo/{config_id_of_lp}/scorms
        validate below things with parent project id:
        - status code to be 200
        - success key exist with value false
        - limit_exceeded key exist with value as true
        - lo_exceeded_course_count key exist having value as 2
        """
        response = self.replication.get_response(f'docebo/{lp_config_id_with_11_training_materials_inside_a_course}', scorm_api, basic_auth)
        response_body = self.replication.get_content(response)
        self.logger.info(response_body)
        status_code = self.replication.get_status_code(response)
        self.logger.info(f"status code: {status_code}")
        assert STATUS_CODE_GOOD == status_code
        assert self.replication.verify_entry(response_body, success_key, false_value)
        self.logger.info(f"success key exist having value :{false_value} in it")
        assert self.replication.verify_entry(response_body, limit_exceeded_key, true_value)
        self.logger.info(f"limit_exceeded key exist having value :{true_value} in it")
        assert self.replication.compare_expected_and_actual_result(response_body, "lo_exceeded_course_count", 1)
        self.logger.info("02 courses have more than 10 training materials each")
