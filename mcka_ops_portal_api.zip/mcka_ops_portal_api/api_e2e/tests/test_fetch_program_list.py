import requests
from ...resources.utils import build_request_headers
from ..api_library.fetch_programs import FetchPrograms
from ...config import APP_URL, DOCEBO, Log, TOTAL_ROWS, CONFIG_ID, PROGRAM_ID, DOCEBO_SUCCESS


class TestFetchPrograms:
    fetch_programs = FetchPrograms()

    def test_fetch_all_program_list(self, basic_auth):
        Log.info("test_fetchAllProgramList")
        response = self.fetch_programs.fetch_all_programs(APP_URL, basic_auth)
        Log.debug(response.status_code)
        Log.debug(response.json())
        assert response.status_code == 200

    def test_validate_program_docebo_success(self, basic_auth):
        Log.info("test_validate_program_details")
        response = self.fetch_programs.fetch_all_programs(APP_URL, basic_auth)
        Log.debug(response.json())
        items_keys = response.json().keys()
        docebo_success = list(items_keys)
        assert DOCEBO_SUCCESS == docebo_success[0]

    def test_validate_program_total_rows(self, basic_auth):
        Log.info("test_validate_program_total_rows")
        response = self.fetch_programs.fetch_all_programs(APP_URL, basic_auth)
        Log.debug(response.json())
        if response.status_code == 200:
            total_rows = response.json().keys()
            total_rows_key = list(total_rows)
            assert TOTAL_ROWS == total_rows_key[2]
        elif response.status_code == 400:
            Log.info("400 Error message returned. Key totalRows not returned")

    def test_validate_program_count(self, basic_auth):
        Log.info("test_validate_program_count")
        response = self.fetch_programs.fetch_all_programs(APP_URL, basic_auth)
        Log.debug(response.json())
        items = response.json()["items"]
        items_count = len(items)
        Log.info("No of items are" + str(items_count))
        assert 11 == items_count

    def test_validate_docebo_program_ids(self, basic_auth):
        Log.info("test_validate_program_id")
        response = self.fetch_programs.fetch_all_programs(APP_URL, basic_auth)
        Log.debug(response.json())
        items = response.json()["items"]
        items_keys = items[0].keys()
        program_id = list(items_keys)
        assert PROGRAM_ID == program_id[0]

    def test_validate_program_config_id(self, basic_auth):
        Log.info("test_validate_program_config_id")
        response = self.fetch_programs.fetch_all_programs(APP_URL, basic_auth)
        Log.debug(response.json())
        items = response.json()["items"]
        items_keys = items[0].keys()
        config_id = list(items_keys)
        assert CONFIG_ID == config_id[1]

    def test_validate_program_docebo_flag(self, basic_auth):
        Log.info("test_validate_program_config_id")
        response = self.fetch_programs.fetch_all_programs(APP_URL, basic_auth)
        Log.debug(response.json())
        items = response.json()["items"]
        items_keys = items[0].keys()
        docebo = list(items_keys)
        assert DOCEBO == docebo[8]
