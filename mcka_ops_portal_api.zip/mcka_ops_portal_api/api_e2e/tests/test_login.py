from ..api_library.login import LoginPage


class TestLogin:
    login_page = LoginPage()

    def test_login_success(self):
        """
        Test user logging into Ops Portal successfully
        """
        login_resp, _ = self.login_page.login()
        assert 200 == login_resp.status_code
