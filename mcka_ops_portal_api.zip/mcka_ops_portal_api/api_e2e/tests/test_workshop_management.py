import time

import pytest

from ..api_library.user_management import UserManagement
from ..api_library.workshop_management import WorkshopManagement
import numbers
from ...config import (STATUS_CODE_GOOD, Log, success_key, true_value, session_key, instructor_endpoint,
                       instructors_key,
                       no_session_endpoint, courses_value_key, session_value_key, event_key, event_types,
                       update_session_endpoint, delete_session_key, venues_names, update_event_endpoint,
                       delete_event_key, session_types, message_key, message_value_event, BAD_REQUEST_STATUS_CODE_400,
                       message_value_session, delta_key, transaction_id_key, count_session_endpoint,
                       get_course_id_wm_endpoint, progress_api_endpoint, status_key, failed_status,
                       enrolled_session_program_id)


class TestWorkshopManagement:
    workshop_management = WorkshopManagement()
    user = UserManagement()
    logger = Log

    def test_validate_and_add_new_manual_session(self, basic_auth):
        """
        (Workshop Management) Add new manual session and validate if it's working fine
        """
        self.logger.info("test add new session")
        before_add_session = self.workshop_management.get_count_of_session(get_course_id_wm_endpoint,
                                                                           count_session_endpoint, basic_auth)
        response, payload = self.workshop_management.create_new_session(session_types[0], basic_auth)
        after_add_session = self.workshop_management.get_count_of_session(get_course_id_wm_endpoint,
                                                                          count_session_endpoint, basic_auth)
        response_body = self.workshop_management.get_content(response)
        self.logger.info(response_body)
        status_code = self.workshop_management.get_status_code(response)
        assert response.status_code == status_code
        assert self.workshop_management.compare_payload(payload, after_add_session[0])
        self.logger.info(f"status code: {status_code}")
        assert self.workshop_management.compare_expected_and_actual_result(response_body, success_key, true_value)
        self.logger.info(f"{success_key} key exist with value as {true_value}")
        assert self.workshop_management.verify_key_exist_with_valid_value_type(response_body["data"], session_key, int)
        self.logger.info("Session key is available in response data")
        assert self.workshop_management.validate_updated_count(before_add_session, after_add_session)
        self.logger.info(f"Verify before add session value {len(before_add_session)} is less than "
                         f"after add session value {len(after_add_session)}")

    def test_validate_and_add_new_attendance_session(self, basic_auth):
        """
        (Workshop Management) Add new attendance session and validate if it's working fine
        """
        self.logger.info("test add new session")
        before_add_session = self.workshop_management.get_count_of_session(get_course_id_wm_endpoint,
                                                                           count_session_endpoint, basic_auth)
        response, payload = self.workshop_management.create_new_session(session_types[1], basic_auth)
        after_add_session = self.workshop_management.get_count_of_session(get_course_id_wm_endpoint,
                                                                          count_session_endpoint, basic_auth)
        response_body = self.workshop_management.get_content(response)
        assert self.workshop_management.compare_payload(payload, after_add_session[0])
        self.logger.info(response_body)
        status_code = self.workshop_management.get_status_code(response)
        assert response.status_code == status_code
        self.logger.info(f"status code: {status_code}")
        assert self.workshop_management.compare_expected_and_actual_result(response_body, success_key, true_value)
        self.logger.info(f"{success_key} key exist with value as {true_value}")
        assert self.workshop_management.verify_key_exist_with_valid_value_type(response_body["data"], session_key, int)
        self.logger.info("Session key is available in response data")
        assert self.workshop_management.validate_updated_count(before_add_session, after_add_session)
        self.logger.info(f"Verify before add session value {len(before_add_session)} is less than "
                         f"after add session value {len(after_add_session)}")

    def test_update_and_delete_session(self, basic_auth):
        create_session_response, session_payload = self.workshop_management.create_new_session(session_types[1],
                                                                                               basic_auth)
        response_body = self.workshop_management.get_content(create_session_response)
        session_status_code = self.workshop_management.get_status_code(create_session_response)
        assert session_status_code == create_session_response.status_code
        url = f'{update_session_endpoint}{response_body["data"]["id_session"]}'
        update_session_response, payload = self.workshop_management.update_session(
            url, basic_auth, "update session", "description")
        update_status_code = self.workshop_management.get_status_code(update_session_response)
        assert update_status_code == update_session_response.status_code
        get_session_resopnse = self.workshop_management.get_count_of_session(get_course_id_wm_endpoint,
                                                                             count_session_endpoint, basic_auth)
        assert self.workshop_management.compare_payload(payload, get_session_resopnse[0])
        delete_session_response = self.workshop_management.delete_session(url, basic_auth)
        delete_session_status_code = self.workshop_management.get_status_code(delete_session_response)
        delete_response_body = self.workshop_management.get_content(delete_session_response)
        assert self.workshop_management.compare_expected_and_actual_result(
            delete_response_body, success_key, true_value)
        self.logger.info(f"{success_key} key exist with value as {true_value}")
        assert self.workshop_management.compare_expected_and_actual_result(
            delete_response_body, delete_session_key, true_value)
        self.logger.info(f"{delete_session_key} key exist with value as {true_value}")
        assert delete_session_status_code == delete_session_response.status_code

    def test_validate_create_session_with_empty(self, basic_auth):
        response, payload = self.workshop_management.create_session_with_empty_payload(basic_auth)
        status_code = self.workshop_management.get_status_code(response)
        response_body = self.workshop_management.get_content(response)
        assert status_code == BAD_REQUEST_STATUS_CODE_400
        assert self.workshop_management.compare_expected_and_actual_result(response_body, message_key,
                                                                           message_value_session)

    def test_create_new_video_event(self, basic_auth):
        before_add_event = self.workshop_management.get_count_of_session(get_course_id_wm_endpoint,
                                                                         count_session_endpoint, basic_auth)
        response, payload = self.workshop_management.create_event(basic_auth, event_types[0], before_add_event)
        response_body = self.workshop_management.get_content(response)
        status_code = self.workshop_management.get_status_code(response)
        assert status_code == response.status_code
        assert self.workshop_management.compare_expected_and_actual_result(response_body, success_key, true_value)
        after_add_session = self.workshop_management.get_count_of_session(get_course_id_wm_endpoint,
                                                                          count_session_endpoint, basic_auth)
        assert self.workshop_management.compare_payload(payload, after_add_session[0]['events'][0])
        assert self.workshop_management.validate_updated_count(before_add_event[0][event_key],
                                                               after_add_session[0][event_key])
        event_id = self.workshop_management.get_list_of_json_key(after_add_session[0]['events'], 'id')
        assert self.workshop_management.verify_value_exist_in_a_list(response_body['data']['event_id'], event_id)

    def test_create_new_venue_event(self, basic_auth):
        before_add_event = self.workshop_management.get_count_of_session(get_course_id_wm_endpoint,
                                                                         count_session_endpoint, basic_auth)
        response, payload = self.workshop_management.create_event(basic_auth, event_types[1], before_add_event)
        response_body = self.workshop_management.get_content(response)
        status_code = self.workshop_management.get_status_code(response)
        assert status_code == response.status_code
        assert self.workshop_management.compare_expected_and_actual_result(response_body, success_key, true_value)
        after_add_session = self.workshop_management.get_count_of_session(get_course_id_wm_endpoint,
                                                                          count_session_endpoint, basic_auth)
        assert self.workshop_management.compare_payload(payload, after_add_session[0]['events'][0])
        assert self.workshop_management.validate_updated_count(before_add_event[0][event_key],
                                                               after_add_session[0][event_key])
        event_id = self.workshop_management.get_list_of_json_key(after_add_session[0]['events'], 'id')
        assert self.workshop_management.verify_value_exist_in_a_list(response_body['data']['event_id'], event_id)

    def test_validate_event_name_have_character_limit(self, basic_auth):
        """
        (Workshop Management) Validate event name with valid character limit
        """
        before_add_event = self.workshop_management.get_count_of_session(get_course_id_wm_endpoint,
                                                                         count_session_endpoint, basic_auth)
        response, payload = self.workshop_management.create_event_with_character_limit(basic_auth, event_types[1],
                                                                                       before_add_event)
        status_code = self.workshop_management.get_status_code(response)
        response_body = self.workshop_management.get_content(response)
        assert status_code == BAD_REQUEST_STATUS_CODE_400
        assert self.workshop_management.compare_expected_and_actual_result(response_body, message_key,
                                                                           message_value_event)

    def test_update_and_delete_event(self, basic_auth):
        """
        (Workshop Management) Update and delete new event
        """
        response, payload = self.workshop_management.update_event("updated event name", venues_names[0], event_types[0],
                                                                  basic_auth)
        response_body = self.workshop_management.get_content(response)
        status_code = self.workshop_management.get_status_code(response)
        assert status_code == response.status_code
        self.workshop_management.get_count_of_session(get_course_id_wm_endpoint, count_session_endpoint, basic_auth)
        delete_event_response = self.workshop_management.delete_event(
            f'{update_event_endpoint}{response_body["data"]["event_id"]}', basic_auth)
        delete_status_code = self.workshop_management.get_status_code(delete_event_response)
        assert delete_status_code == delete_event_response.status_code
        delete_response_body = self.workshop_management.get_content(delete_event_response)
        assert self.workshop_management.compare_expected_and_actual_result(delete_response_body, success_key,
                                                                           true_value)
        self.logger.info(f"{success_key} key exist with value as {true_value}")
        assert self.workshop_management.compare_expected_and_actual_result(delete_response_body, delete_event_key,
                                                                           true_value)
        self.logger.info(f"{delete_event_key} key exist with value as {true_value}")

    def validate_instructors_list(self, basic_auth):
        """
        (Workshop Management) Validate instructors list API is working fine
        """
        self.logger.info("Test validate instructors api return the list of instructors")
        response = self.workshop_management.get_instructors(instructor_endpoint, basic_auth)
        status_code = self.workshop_management.get_status_code(response)
        assert response.status_code == status_code
        response_body = self.workshop_management.get_content(response)
        list_of_instructors = self.workshop_management.get_list_of_json_key(response_body, instructors_key)
        assert len(list_of_instructors) == 5

    def test_validate_ILT_course_having_no_session(self, basic_auth):
        """
        (Workshop Management) Validate ILT course with no session
        """
        response = self.workshop_management._get(no_session_endpoint, basic_auth)
        status_code = self.workshop_management.get_status_code(response)
        assert status_code == response.status_code
        response_body = self.workshop_management.get_content(response)
        assert self.workshop_management.compare_expected_and_actual_result(response_body, success_key, true_value)
        assert self.workshop_management.compare_expected_and_actual_result(response_body[courses_value_key][0],
                                                                           session_value_key, 0)

    def test_validate_sync_user_success(self, basic_auth):
        """
        (Workshop Management) Validate sync user success is working fine
        """
        create_test_user = self.workshop_management.create_test_user(basic_auth)
        response_body_user = self.workshop_management.get_content(create_test_user)
        list_of_user = self.workshop_management.get_list_of_json_key(response_body_user['users'], 'user')
        sync_user_response = self.workshop_management.get_response_of_sync_user(basic_auth, 8)
        status_code = self.workshop_management.get_status_code(sync_user_response)
        response_body_of_sync = self.workshop_management.get_content(sync_user_response)
        self.workshop_management.get_count_of_session(get_course_id_wm_endpoint, count_session_endpoint, basic_auth)
        delete_user_response = self.workshop_management.delete_test_user(response_body_user[transaction_id_key],
                                                                         list_of_user, basic_auth)
        self.logger.info(f"status code: {status_code}")
        assert status_code == STATUS_CODE_GOOD
        status_code = self.workshop_management.get_status_code(delete_user_response)
        assert STATUS_CODE_GOOD == status_code
        assert self.workshop_management.compare_expected_and_actual_result(
            response_body_of_sync, success_key, true_value)
        assert self.workshop_management.compare_expected_and_actual_result(response_body_of_sync, delta_key, true_value)

        assert self.workshop_management.verify_key_exist_with_valid_value_type(
            response_body_of_sync, transaction_id_key, self.workshop_management.get_transaction_id(
                response_body_of_sync))

    def test_validate_sync_user_failure(self, basic_auth):
        """
        (Workshop Management) Validate sync user failure is working fine
        """
        response_failed_sync_users = self.workshop_management.hit_sync_user_failed_api(basic_auth)
        response_body_sync_failed_users = self.workshop_management.get_content(response_failed_sync_users)
        time.sleep(10)
        processing_response = self.workshop_management._get(
            f'{progress_api_endpoint}{response_body_sync_failed_users["transaction_id"]}', basic_auth)
        processing_response_body = self.workshop_management.get_content(processing_response)
        status_code = self.workshop_management.get_status_code(processing_response)

        self.logger.info(f"status code: {status_code}")
        assert status_code == STATUS_CODE_GOOD
        self.workshop_management.compare_expected_and_actual_result(processing_response_body,
                                                                    status_key, failed_status)

    def test_validate_log_file_download(self, basic_auth):
        """
        (Workshop Management) Validate log file download is working fine
        """
        response = self.workshop_management.upload_manage_users_file(basic_auth)
        status_code = self.workshop_management.get_status_code(response)
        self.logger.info(f"status code: {status_code}")
        assert STATUS_CODE_GOOD == status_code

    def test_validate_user_sync_in_session(self, basic_auth):
        """
        (Workshop Management) Validate user sync in session is working fine
        """
        response = self.workshop_management.upload_participants_file(basic_auth, enrolled_session_program_id)
        response_body = self.workshop_management.get_content(response)

        transaction_id = self.workshop_management.get_transaction_id(response_body)
        details = self.user.user_uploading_got_completed(transaction_id, basic_auth)
        self.logger.info(details)
        time.sleep(140)
        sync_user_response = self.workshop_management.hit_sync_user_enrollment_check_api(basic_auth)
        response_body_sync = self.workshop_management.get_content(sync_user_response)
        time.sleep(20)

        progress_response = self.workshop_management._get(
            f'{progress_api_endpoint}{response_body_sync["transaction_id"]}', basic_auth)
        progress_response_body = self.workshop_management.get_content(progress_response)

        self.workshop_management.compare_expected_and_actual_result(
            progress_response_body["progress"][0]["sessions"][0], 'successful_rows', 4)
