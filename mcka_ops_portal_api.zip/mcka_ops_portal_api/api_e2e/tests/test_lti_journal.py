from ..api_library.lti_journal import LtiJournal
from ...config import *
import pytest


class TestLtiJournalScenarios:
    lti_journal = LtiJournal()
    logger = Log

    def test_validate_the_response_of_existing_lti_lps(self, basic_auth):
        """
         Validate the response of existing LTI LPs by hitting api/learning-plans/?page=1&search=and passing lti token
        - Status code to be 200
        - success key exists with value true
        - data key exists with valid values
        """
        lti_auth = self.lti_journal.get_lti_token(url=lti_token_url, basic_auth=basic_auth)
        response = self.lti_journal._get_lti(url=existing_lti_url, token=lti_auth)
        response_body = self.lti_journal.get_content(response)
        self.logger.info(response_body)
        status_code = self.lti_journal.get_status_code(response)
        self.logger.info(f"status code: {status_code}")
        assert STATUS_CODE_GOOD == status_code
        assert self.lti_journal.verify_entry(response_body, success_key, true_value)
        self.logger.info(f"success key exist having value: {true_value}")
        assert self.lti_journal.verify_entry(response_body[data_key], lti_has_more_key, true_value)
        self.logger.info(f"hasMore key exists having value: {true_value}")
        assert self.lti_journal.verify_key_exist_with_valid_value_type(response_body[data_key], lti_rows_key, int)
        assert self.lti_journal.validate_existing_lti_lps_response(response_body)

    def test_validate_the_response_of_invalid_lp_config_id(self, basic_auth):
        """
         Validate the response of invalid lp config id
        - Status code to be 200
        - success key exists with value false
        - data key exists
        """
        response = self.lti_journal.get_content_with_invalid_config_id(basic_auth)
        response_body = self.lti_journal.get_content(response)
        self.logger.info(response_body)
        status_code = self.lti_journal.get_status_code(response)
        self.logger.info(f"status code: {status_code}")
        assert REQUESTED_PAGE_NOT_FOUND_STATUS_CODE == status_code
        assert self.lti_journal.compare_expected_and_actual_result(response_body, message_key, lti_invalid_message)
        self.logger.info(f"message key found having value as: {lti_invalid_message}")
        assert self.lti_journal.compare_expected_and_actual_result(response_body, success_key, false_value)
        self.logger.info(f"a key named as unique exist with value to be {false_value}")
        assert self.lti_journal.compare_expected_and_actual_result(response_body, lti_details_key, lti_program_not_found)
        self.logger.info(f"a key named as details exist with value to be {lti_program_not_found}")

    def test_validate_the_response_of_valid_lp_config_id(self, basic_auth):
        """
         Validate the response of valid LP Config ID
        - Status code to be 200
        - success key exists with value true
        - data key exists
        """
        response = self.lti_journal._get(url=lti_lp_config_url, token=basic_auth)
        response_body = self.lti_journal.get_content(response)
        self.logger.info(response_body)
        status_code = self.lti_journal.get_status_code(response)
        self.logger.info(f"status code: {status_code}")
        assert STATUS_CODE_GOOD == status_code
        assert self.lti_journal.compare_expected_and_actual_result(response_body, success_key, true_value)
        self.logger.info(f"a key named as success exists with value to be {true_value}")
        assert self.lti_journal.verify_entry(response_body, success_key, true_value)
        self.logger.info(f"success key exists having value: {true_value}")
        assert self.lti_journal.compare_expected_and_actual_result(response_body[data_key], lti_config_id_key, enrolled_session_program_name)
        self.logger.info(f"a key named as config id exists with value to be {enrolled_session_program_name}")
        assert self.lti_journal.compare_expected_and_actual_result(response_body[data_key], lti_docebo_lp_id_key, lti_docebo_lp_id)
        self.logger.info(f"a key named as docebo lp id exists with value to be {lti_docebo_lp_id}")
        assert self.lti_journal.verify_key_exist_with_valid_value_type(response_body[data_key], lti_num_components_key, int)
        assert self.lti_journal.compare_expected_and_actual_result(response_body[data_key], lti_program_name_key, lti_program_name)
        self.logger.info(f"a key named as program name exist with value to be {lti_program_name}")

    def test_create_update_delete_an_lti_journal(self, basic_auth):
        """
        Validate the response of creating/updating/deleting a new LTI Jurnal
        - Status code to be 200
        - success key exists with value true
        - data key exists with value SUCCESS
        """
        # Adding a new journal
        lti_auth = self.lti_journal.get_lti_token(url=lti_token_url, basic_auth=basic_auth)
        response = self.lti_journal.create_an_lti_lp(lti_auth)
        response_body = self.lti_journal.get_content(response)
        self.logger.info(response_body)
        status_code = self.lti_journal.get_status_code(response)
        self.logger.info(f"status code: {status_code}")
        assert STATUS_CODE_201 == status_code
        lti_lp_id = response_body[data_key]['id']
        assert self.lti_journal.verify_entry(response_body, success_key, true_value)
        self.logger.info(f"success key exist having value: {true_value}")
        assert self.lti_journal.compare_expected_and_actual_result(response_body[data_key], lti_lp_id_key, lti_docebo_lp_id)
        self.logger.info(f"a key named as docebo lp id exists with value to be {lti_docebo_lp_id}")
        assert self.lti_journal.verify_key_exist_with_valid_value_type(response_body[data_key], id_key, int)
        assert self.lti_journal.validate_newly_created_lti_lp_response(response_body)

        # Validating the error response on adding an existing lti journal
        response = self.lti_journal.create_an_lti_lp(lti_auth)
        response_body = self.lti_journal.get_content(response)
        self.logger.info(response_body)
        status_code = self.lti_journal.get_status_code(response)
        self.logger.info(f"status code: {status_code}")
        assert BAD_REQUEST_STATUS_CODE_400 == status_code
        assert self.lti_journal.verify_entry(response_body, success_key, false_value)
        self.logger.info(f"success key exist having value: {false_value}")
        assert self.lti_journal.compare_expected_and_actual_result(response_body, message_key, lti_duplicate_error)
        self.logger.info(f"a key named as message exist with value to be {lti_duplicate_error}")

        # Editing the newly added journal
        response = self.lti_journal.edit_an_lti_lp(lti_auth, lti_lp_id)
        response_body = self.lti_journal.get_content(response)
        self.logger.info(response_body)
        status_code = self.lti_journal.get_status_code(response)
        self.logger.info(f"status code: {status_code}")
        assert STATUS_CODE_GOOD == status_code
        assert self.lti_journal.verify_entry(response_body, success_key, true_value)
        self.logger.info(f"success key exist having value: {true_value}")
        assert self.lti_journal.compare_expected_and_actual_result(response_body[data_key], lti_lp_id_key, lti_docebo_lp_id)
        self.logger.info(f"a key named as docebo lp id exists with value to be {lti_docebo_lp_id}")
        assert self.lti_journal.verify_key_exist_with_valid_value_type(response_body[data_key], id_key, int)
        assert self.lti_journal.validate_newly_created_lti_lp_response(response_body)

        # Deleting the newly added journal
        response = self.lti_journal.delete_an_lti_journal(basic_auth, lti_lp_id)
        response_body = self.lti_journal.get_content(response)
        self.logger.info(response_body)
        status_code = self.lti_journal.get_status_code(response)
        self.logger.info(f"status code: {status_code}")
        assert STATUS_CODE_GOOD == status_code
        assert self.lti_journal.verify_entry(response_body, success_key, true_value)
        self.logger.info(f"success key exist having value: {true_value}")

    def test_create_update_delete_a_page_in_a_journal(self, basic_auth):
        """
        Validate the response of creating/updating/deleting a new LTI Jurnal
        - Status code to be 200
        - success key exists with value true
        - data key exists with value SUCCESS
        """
        # Getting the info of existing lti journal
        lti_auth = self.lti_journal.get_lti_token(url=lti_token_url, basic_auth=basic_auth)
        response = self.lti_journal.get_lp_content_library_details(lti_auth)
        response_body = self.lti_journal.get_content(response)
        self.logger.info(response_body)
        status_code = self.lti_journal.get_status_code(response)
        self.logger.info(f"status code: {status_code}")
        assert STATUS_CODE_GOOD == status_code
        assert self.lti_journal.verify_entry(response_body, success_key, true_value)
        self.logger.info(f"success key exist having value: {true_value}")
        assert self.lti_journal.compare_expected_and_actual_result(response_body[data_key], lti_lp_id_key, existing_docebo_lti_lp_id)
        self.logger.info(f"a key named as docebo lp id exists with value to be {existing_docebo_lti_lp_id}")
        assert self.lti_journal.verify_key_exist_with_valid_value_type(response_body[data_key], id_key, int)
        assert self.lti_journal.validate_newly_created_lti_lp_response(response_body)

        response = self.lti_journal.get_lp_journal_pages_search_details(lti_auth)
        response_body = self.lti_journal.get_content(response)
        self.logger.info(response_body)
        status_code = self.lti_journal.get_status_code(response)
        self.logger.info(f"status code: {status_code}")
        assert STATUS_CODE_GOOD == status_code
        assert self.lti_journal.verify_entry(response_body, success_key, true_value)
        self.logger.info(f"success key exist having value: {true_value}")
        assert self.lti_journal.verify_key_exist_with_valid_value_type(response_body[data_key], 'hasMore', bool)
        assert self.lti_journal.verify_key_exist_with_valid_value_type(response_body[data_key], 'totalRows', int)
        assert self.lti_journal.verify_key_exist_with_valid_value_type(response_body[data_key], 'items', list)

        response = self.lti_journal.get_refresh_components(basic_auth)
        response_body = self.lti_journal.get_content(response)
        self.logger.info(response_body)
        status_code = self.lti_journal.get_status_code(response)
        self.logger.info(f"status code: {status_code}")
        assert STATUS_CODE_GOOD == status_code
        assert self.lti_journal.verify_entry(response_body, success_key, true_value)
        self.logger.info(f"success key exist having value: {true_value}")
        assert self.lti_journal.verify_key_exist_with_valid_value_type(response_body[data_key], 'components', list)
        assert self.lti_journal.verify_key_exist_with_valid_value_type(response_body[data_key], 'num_components', int)
        assert self.lti_journal.validate_components_info_response(response_body)
        course_details_standard = response_body['data']['components'][1]
        course_details_review = response_body['data']['components'][2]

        response = self.lti_journal.create_a_new_page(basic_auth, course_details_standard)
        response_body = self.lti_journal.get_content(response)
        self.logger.info(response_body)
        status_code = self.lti_journal.get_status_code(response)
        self.logger.info(f"status code: {status_code}")
        assert STATUS_CODE_GOOD == status_code
        assert self.lti_journal.verify_entry(response_body, success_key, true_value)
        self.logger.info(f"success key exist having value: {true_value}")
        assert self.lti_journal.verify_key_exist_with_valid_value_type(response_body[data_key], id_key, int)
        assert self.lti_journal.compare_expected_and_actual_result(response_body[data_key], 'journal_type', 'standard')
        self.logger.info(f"a key named as jouranl_type exists with value to be standard")
        assert self.lti_journal.validate_newly_created_page_response(response_body)
        standard_page_id = response_body['data']['id']

        response = self.lti_journal.create_a_new_page(basic_auth, course_details_review, "review")
        response_body = self.lti_journal.get_content(response)
        self.logger.info(response_body)
        status_code = self.lti_journal.get_status_code(response)
        self.logger.info(f"status code: {status_code}")
        assert STATUS_CODE_GOOD == status_code
        assert self.lti_journal.verify_entry(response_body, success_key, true_value)
        self.logger.info(f"success key exist having value: {true_value}")
        assert self.lti_journal.verify_key_exist_with_valid_value_type(response_body[data_key], id_key, int)
        assert self.lti_journal.compare_expected_and_actual_result(response_body[data_key], 'journal_type', 'review')
        self.logger.info(f"a key named as jouranl_type exists with value to be review")
        assert self.lti_journal.validate_newly_created_page_response(response_body)
        review_page_id = response_body['data']['id']
        # get pages count
        response = self.lti_journal.get_journal_pages_tms_count(lti_auth, standard_page_id)
        response_body = self.lti_journal.get_content(response)
        self.logger.info(response_body)
        status_code = self.lti_journal.get_status_code(response)
        self.logger.info(f"status code: {status_code}")
        assert STATUS_CODE_GOOD == status_code
        st_tm_id = response_body['data']['training_material_id']
        assert self.lti_journal.verify_entry(response_body, success_key, true_value)
        self.logger.info(f"success key exist having value: {true_value}")
        assert self.lti_journal.verify_key_exist_with_valid_value_type(response_body[data_key], id_key, int)
        assert self.lti_journal.compare_expected_and_actual_result(response_body[data_key], 'journal_type', 'standard')
        self.logger.info(f"a key named as jouranl_type exists with value to be review")
        assert self.lti_journal.validate_training_materials_response(response_body)

        response = self.lti_journal.get_journal_pages_tms_count(lti_auth, review_page_id)
        response_body = self.lti_journal.get_content(response)
        self.logger.info(response_body)
        status_code = self.lti_journal.get_status_code(response)
        self.logger.info(f"status code: {status_code}")
        assert STATUS_CODE_GOOD == status_code
        assert self.lti_journal.verify_entry(response_body, success_key, true_value)
        self.logger.info(f"success key exist having value: {true_value}")
        assert self.lti_journal.verify_key_exist_with_valid_value_type(response_body[data_key], id_key, int)
        assert self.lti_journal.compare_expected_and_actual_result(response_body[data_key], 'journal_type', 'review')
        self.logger.info(f"a key named as jouranl_type exists with value to be review")
        assert self.lti_journal.validate_training_materials_response(response_body)
        r_tm_id = response_body['data']['training_material_id']
        # Edit newly created page
        response = self.lti_journal.edit_newly_created_page(basic_auth, course_details_standard, standard_page_id, st_tm_id)
        response_body = self.lti_journal.get_content(response)
        self.logger.info(response_body)
        status_code = self.lti_journal.get_status_code(response)
        self.logger.info(f"status code: {status_code}")
        assert STATUS_CODE_GOOD == status_code
        assert self.lti_journal.verify_entry(response_body, success_key, true_value)
        self.logger.info(f"success key exist having value: {true_value}")
        assert self.lti_journal.verify_key_exist_with_valid_value_type(response_body[data_key], id_key, int)
        assert self.lti_journal.compare_expected_and_actual_result(response_body[data_key], 'journal_type', 'standard')
        self.logger.info(f"a key named as jouranl_type exists with value to be review")
        assert self.lti_journal.validate_newly_created_page_response(response_body)

        response = self.lti_journal.edit_newly_created_page(basic_auth, course_details_review, review_page_id, r_tm_id, "review")
        response_body = self.lti_journal.get_content(response)
        self.logger.info(response_body)
        status_code = self.lti_journal.get_status_code(response)
        self.logger.info(f"status code: {status_code}")
        assert STATUS_CODE_GOOD == status_code
        assert self.lti_journal.verify_entry(response_body, success_key, true_value)
        self.logger.info(f"success key exist having value: {true_value}")
        assert self.lti_journal.verify_key_exist_with_valid_value_type(response_body[data_key], id_key, int)
        assert self.lti_journal.compare_expected_and_actual_result(response_body[data_key], 'journal_type', 'review')
        self.logger.info(f"a key named as jouranl_type exists with value to be review")
        assert self.lti_journal.validate_newly_created_page_response(response_body)

        response = self.lti_journal.delete_newly_created_page(basic_auth, review_page_id)
        response_body = self.lti_journal.get_content(response)
        self.logger.info(response_body)
        status_code = self.lti_journal.get_status_code(response)
        self.logger.info(f"status code: {status_code}")
        assert STATUS_CODE_GOOD == status_code
        assert self.lti_journal.verify_entry(response_body, success_key, true_value)
        self.logger.info(f"success key exist having value: {true_value}")

        response = self.lti_journal.get_journal_pages_prompts(lti_auth, standard_page_id)
        response_body = self.lti_journal.get_content(response)
        self.logger.info(response_body)
        status_code = self.lti_journal.get_status_code(response)
        self.logger.info(f"status code: {status_code}")
        assert STATUS_CODE_GOOD == status_code
        total_rows = response_body['data']['totalRows']
        assert self.lti_journal.verify_entry(response_body, success_key, true_value)
        self.logger.info(f"success key exist having value: {true_value}")
        assert self.lti_journal.verify_key_exist_with_valid_value_type(response_body[data_key], 'hasMore', bool)
        assert self.lti_journal.verify_key_exist_with_valid_value_type(response_body[data_key], 'totalRows', int)
        assert self.lti_journal.verify_key_exist_with_valid_value_type(response_body[data_key], 'items', list)

        response = self.lti_journal.create_a_new_prompt(lti_auth, total_rows, standard_page_id)
        response_body = self.lti_journal.get_content(response)
        self.logger.info(response_body)
        status_code = self.lti_journal.get_status_code(response)
        self.logger.info(f"status code: {status_code}")
        assert STATUS_CODE_201 == status_code
        assert self.lti_journal.verify_entry(response_body, success_key, true_value)
        self.logger.info(f"success key exist having value: {true_value}")
        assert self.lti_journal.compare_expected_and_actual_result(response_body[data_key], 'is_required', True)
        self.lti_journal.validate_newly_created_prompt_response(response_body)
        prompt_id = response_body['data']['id']

        response = self.lti_journal.edit_newly_created_prompt(lti_auth, total_rows, prompt_id, standard_page_id)
        response_body = self.lti_journal.get_content(response)
        self.logger.info(response_body)
        status_code = self.lti_journal.get_status_code(response)
        self.logger.info(f"status code: {status_code}")
        assert STATUS_CODE_GOOD == status_code
        assert self.lti_journal.verify_entry(response_body, success_key, true_value)
        self.logger.info(f"success key exist having value: {true_value}")
        assert self.lti_journal.compare_expected_and_actual_result(response_body[data_key], 'is_required', True)
        self.lti_journal.validate_newly_created_prompt_response(response_body)
        # self.lti_journal.delete_prompt(basic_auth, prompt_id)

        response = self.lti_journal.get_journal_pages_prompts(lti_auth, standard_page_id)
        response_body = self.lti_journal.get_content(response)
        self.logger.info(response_body)
        status_code = self.lti_journal.get_status_code(response)
        self.logger.info(f"status code: {status_code}")
        assert STATUS_CODE_GOOD == status_code
        total_rows = response_body['data']['totalRows']

        response = self.lti_journal.create_a_new_prompt(lti_auth, total_rows, standard_page_id, False)
        response_body = self.lti_journal.get_content(response)
        self.logger.info(response_body)
        status_code = self.lti_journal.get_status_code(response)
        self.logger.info(f"status code: {status_code}")
        assert STATUS_CODE_201 == status_code
        assert self.lti_journal.verify_entry(response_body, success_key, true_value)
        self.logger.info(f"success key exist having value: {true_value}")
        assert self.lti_journal.compare_expected_and_actual_result(response_body[data_key], 'is_required', False)
        self.lti_journal.validate_newly_created_prompt_response(response_body)
        prompt_id = response_body['data']['id']

        response = self.lti_journal.edit_newly_created_prompt(lti_auth, total_rows, prompt_id, standard_page_id, False)
        response_body = self.lti_journal.get_content(response)
        self.logger.info(response_body)
        status_code = self.lti_journal.get_status_code(response)
        self.logger.info(f"status code: {status_code}")
        assert STATUS_CODE_GOOD == status_code
        assert self.lti_journal.verify_entry(response_body, success_key, true_value)
        self.logger.info(f"success key exist having value: {true_value}")
        assert self.lti_journal.compare_expected_and_actual_result(response_body[data_key], 'is_required', False)
        self.lti_journal.validate_newly_created_prompt_response(response_body)
        # self.lti_journal.delete_prompt(basic_auth, prompt_id)

        response = self.lti_journal.delete_newly_created_page(basic_auth, standard_page_id)
        response_body = self.lti_journal.get_content(response)
        self.logger.info(response_body)
        status_code = self.lti_journal.get_status_code(response)
        self.logger.info(f"status code: {status_code}")
        assert STATUS_CODE_GOOD == status_code
        assert self.lti_journal.verify_entry(response_body, success_key, true_value)
        self.logger.info(f"success key exist having value: {true_value}")
