import logging
import time
import pytest

from ..api_library.user_management import UserManagement
from ..api_library.assignment_management import AssignmentManagement
from ..api_library.docebo_lms_login import DoceboLogin
from ...config import *
from ...resources import GROUP_WORK


@pytest.mark.skip("To update the existing tests")
class TestAssignmentManagementScenarios:
    user = UserManagement()
    assign = AssignmentManagement()
    docebo = DoceboLogin()
    logger = Log

    def test_refresh_link_status(self, basic_auth):
        """
        MAPOAS-1927
        verify by clicking on refresh link
        - status code must be 200
        - data key exists having courses info
        """
        response = self.assign.get_refresh_link_status(basic_auth)
        response_body = self.assign.get_content(response)
        status_code = self.assign.get_status_code(response)
        assert STATUS_CODE_GOOD == status_code
        self.logger.info(f"status code: {status_code}")
        assert self.assign.compare_expected_and_actual_result(response_body, success_key, true_value)
        self.logger.info("success key exists with true as value")
        assert self.assign.verify_key_exist_with_valid_value_type(response_body, data_key)
        self.logger.info(f"{data_key} key exist having some valid valid in it")
        assert self.assign.validate_refresh_link_details(response_body)
        self.logger.info("enrolled and waitlisted keys exist with values to be integers")

    def test_download_metadata_file(self, basic_auth):
        """
        MAPOAS-1933
        Download the 2nd option that is meta data
        Hit api and validate the response
        - status code must be 200
        - data key exists having courses info
        """
        # response = self.assign.download_metadata_file(basic_auth)
        # status_code = self.user.get_status_code(response)
        # self.logger.info(f"status code: {status_code}")
        # assert STATUS_CODE_GOOD == status_code

    def test_download_new_assignment(self, basic_auth):
        """
        MAPOAS-1930
        Hit the api
        We will use the assignment id from above api and validate following response
        - status code to be 200
        - transaction_id key exist and must have valid value store that value for further usage
        - success key exist with value to be True

        Hit the next api and validate following response
        - done: true
        - percentage: 100
        - transaction_id: 9467

        Hit the next api and validate following response
        - success: true

        Hit next  api and validate response
        - data: [{created_at: "2022-09-26 11:11:20", id: 888, transaction_id: 9467,…},…]
        - success: true

        Hit download new assignments api without hitting the refresh api and validate the response

        Hit api we will use the assignment id from above api

        - status code to be 400
        - success key exist with value to be False
        {"success": false, "message": "No new assignments to download, please click on Refresh and try again"}
        """
        response = self.assign.get_refresh_link_status(basic_auth)
        response_body = self.assign.get_content(response)
        status_code = self.assign.get_status_code(response)
        assert STATUS_CODE_GOOD == status_code
        self.logger.info(f"status code: {status_code}")
        response = self.user.upload_participants_file(token=basic_auth, p_id=None, group_work=GROUP_WORK)
        response_body = self.user.get_content(response)
        self.logger.info(response_body)
        status_code = self.user.get_status_code(response)
        self.logger.info(f"status code: {status_code}")
        assert STATUS_CODE_GOOD == status_code
        assert self.user.compare_expected_and_actual_result(response_body, success_key, true_value)
        self.logger.info(f"{message_key} exist and contains value: {true_value}")
        transaction_id = self.user.get_transaction_id(response_body)
        details = self.user.user_uploading_got_completed(transaction_id, basic_auth)
        self.logger.info(details)
        assert self.user.validate_user_uploading_response(details, transaction_id, status=transaction_status_key)
        self.logger.info("transaction status came as COMPLETED")
        resp = self.docebo.docebo_lms_login()
        self.logger.info("new assignment has been submitted by learner")
        assert self.assign.verify_key_exist_with_valid_value_type(resp, 'id', int)
        self.logger.info("id key exists with an integer value")
        response = self.assign.get_refresh_link_status(basic_auth)
        response_body = self.assign.get_content(response)
        status_code = self.assign.get_status_code(response)
        assert STATUS_CODE_GOOD == status_code
        self.logger.info(f"status code: {status_code}")
        # response = self.assign.get_download_new_assignments(basic_auth)
        # response_body = self.user.get_content(response)
        # self.logger.info(response_body)
        # status_code = self.user.get_status_code(response)
        # self.logger.info(f"status code: {status_code}")
        # assert STATUS_CODE_GOOD == status_code
        # assert self.user.compare_expected_and_actual_result(response_body, success_key, true_value)
        # self.logger.info(f"{success_key} exists and contains value: {true_value}")
        # transaction_id = self.assign.get_transaction_id(response_body)
        # details = self.assign.downloading_got_completed(transaction_id, basic_auth)
        # self.logger.info(details)
        # assert self.user.compare_expected_and_actual_result(details, done_key, true_value)
        # self.logger.info(f"done exists and contains value: {true_value}")
        # assert self.user.compare_expected_and_actual_result(details, 'percentage', 100)
        # self.logger.info(f"percentage value exists and contains valid value")
        # assert self.user.compare_expected_and_actual_result(details, transaction_id_key, transaction_id)
        # self.logger.info(f"{transaction_id_key} exists and contains value {transaction_id}")

        # report_response = self.assign.get_s3_url(transaction_id, basic_auth)
        # report_body = self.user.get_content(report_response)
        # self.logger.info(report_body)
        # status_code = self.user.get_status_code(report_response)
        # self.logger.info(f"status code: {status_code}")
        # assert STATUS_CODE_GOOD == status_code
        # assert self.user.compare_expected_and_actual_result(report_body, success_key, true_value)
        # self.logger.info(f"{success_key} exists and contains value: {true_value}")
        # assert self.assign.verify_key_exist_with_valid_value_type(report_body, 'url')
        # self.logger.info(f"url exists and contains value in string")
        # url = report_body.get('url')
        # response = self.assign.download_new_assignments_file(url)
        # status_code = self.user.get_status_code(response)
        # self.logger.info(f"status code: {status_code}")
        # assert STATUS_CODE_GOOD == status_code
        # response = self.assign.get_list(basic_auth)
        # response_body = self.user.get_content(response)
        # self.logger.info(response_body)
        # status_code = self.user.get_status_code(response)
        # self.logger.info(f"status code: {status_code}")
        # assert STATUS_CODE_GOOD == status_code
        # assert self.user.compare_expected_and_actual_result(response_body, success_key, true_value)
        # self.logger.info(f"{success_key} exist and contains value: {true_value}")
        # assert self.assign.verify_key_exist_with_valid_value_type(response_body, data_key)
        # self.logger.info(f"{data_key} key exist having some valid values in it")
        # assert self.assign.validate_list_response(response_body)

        # response = self.assign.get_refresh_link_status(basic_auth)
        # response_body = self.assign.get_content(response)
        # status_code = self.assign.get_status_code(response)
        # assert STATUS_CODE_GOOD == status_code
        # self.logger.info(f"status code: {status_code}")
        # response = self.assign.get_download_new_assignments(basic_auth)
        # response_body = self.assign.get_content(response)
        # status_code = self.assign.get_status_code(response)
        # self.logger.info(f"status code: {status_code}")
        # assert BAD_REQUEST_STATUS_CODE_400 == status_code
        # self.logger.info(f"status code: {status_code}")
        # assert self.assign.compare_expected_and_actual_result(response_body, success_key, false_value)
        # self.logger.info("success key exists with true as value")
        # assert self.assign.compare_expected_and_actual_result(response_body, message_key, error_download_new_assignmnet)
        # self.logger.info(f"{message_key} key exists with error message in it")

    def test_upload_grades_with_invalid_grade_value(self, basic_auth):
        """
        MAPOAS-1960
        Hit api and validate following response
        - status to be 400
        - message to be 'Value must be a number or empty'
        """
        response = self.assign.get_refresh_link_status(basic_auth)
        response_body = self.assign.get_content(response)
        status_code = self.assign.get_status_code(response)
        assert STATUS_CODE_GOOD == status_code
        self.logger.info(f"status code: {status_code}")
        response = self.user.upload_participants_file(token=basic_auth, p_id=None, group_work=GROUP_WORK)
        response_body = self.user.get_content(response)
        self.logger.info(response_body)
        status_code = self.user.get_status_code(response)
        self.logger.info(f"status code: {status_code}")
        assert STATUS_CODE_GOOD == status_code
        assert self.user.compare_expected_and_actual_result(response_body, success_key, true_value)
        self.logger.info(f"{message_key} exist and contains value: {true_value}")
        transaction_id = self.user.get_transaction_id(response_body)
        details = self.user.user_uploading_got_completed(transaction_id, basic_auth)
        self.logger.info(details)
        assert self.user.validate_user_uploading_response(details, transaction_id, status=transaction_status_key)
        self.logger.info("transaction status came as COMPLETED")
        resp = self.docebo.docebo_lms_login()
        self.logger.info("new assignment has been submitted by learner")
        assert self.assign.verify_key_exist_with_valid_value_type(resp, 'id', int)
        self.logger.info("id key exists with an integer value")
        response = self.assign.get_refresh_link_status(basic_auth)
        response_body = self.assign.get_content(response)
        status_code = self.assign.get_status_code(response)
        assert STATUS_CODE_GOOD == status_code
        self.logger.info(f"status code: {status_code}")

        response = self.assign.get_refresh_link_status(basic_auth)
        status_code = self.assign.get_status_code(response)
        assert STATUS_CODE_GOOD == status_code
        self.logger.info(f"status code: {status_code}")
        # response = self.assign.download_metadata_file(basic_auth)
        # status_code = self.assign.get_status_code(response)
        # self.logger.info(f"status code: {status_code}")
        # assert STATUS_CODE_GOOD == status_code
        # self.assign.write_metadata_file(instructor_name=instructor_username, grade_val='abc', g_status=grade_status)
        # response = self.assign.validate_evaluation_file(basic_auth, file_name=metadata_file)
        # response_body = self.assign.get_content(response)
        # status_code = self.assign.get_status_code(response)
        # self.logger.info(f"status code: {status_code}")
        # assert BAD_REQUEST_STATUS_CODE_400 == status_code
        # assert self.user.compare_expected_and_actual_result(response_body[errors_key][0], message_key, error_invalid_grade_value)
        # self.logger.info(f"message key exists with value {error_invalid_grade_value}")

    def test_upload_grades_with_decimal_grade_value(self, basic_auth):
        """
        MAPOAS-1964
        Hit api and validate following response
        - status to be 400
        - message to be "Grade value should not be in decimal"
        """
        response = self.assign.get_refresh_link_status(basic_auth)
        response_body = self.assign.get_content(response)
        status_code = self.assign.get_status_code(response)
        assert STATUS_CODE_GOOD == status_code
        self.logger.info(f"status code: {status_code}")
        response = self.user.upload_participants_file(token=basic_auth, p_id=None, group_work=GROUP_WORK)
        response_body = self.user.get_content(response)
        self.logger.info(response_body)
        status_code = self.user.get_status_code(response)
        self.logger.info(f"status code: {status_code}")
        assert STATUS_CODE_GOOD == status_code
        assert self.user.compare_expected_and_actual_result(response_body, success_key, true_value)
        self.logger.info(f"{message_key} exist and contains value: {true_value}")
        transaction_id = self.user.get_transaction_id(response_body)
        details = self.user.user_uploading_got_completed(transaction_id, basic_auth)
        self.logger.info(details)
        assert self.user.validate_user_uploading_response(details, transaction_id, status=transaction_status_key)
        self.logger.info("transaction status came as COMPLETED")
        resp = self.docebo.docebo_lms_login()
        self.logger.info("new assignment has been submitted by learner")
        assert self.assign.verify_key_exist_with_valid_value_type(resp, 'id', int)
        self.logger.info("id key exists with an integer value")
        response = self.assign.get_refresh_link_status(basic_auth)
        response_body = self.assign.get_content(response)
        status_code = self.assign.get_status_code(response)
        assert STATUS_CODE_GOOD == status_code
        self.logger.info(f"status code: {status_code}")

        response = self.assign.get_refresh_link_status(basic_auth)
        status_code = self.assign.get_status_code(response)
        assert STATUS_CODE_GOOD == status_code
        self.logger.info(f"status code: {status_code}")
        response = self.assign.download_metadata_file(basic_auth)
        status_code = self.assign.get_status_code(response)
        self.logger.info(f"status code: {status_code}")
        assert STATUS_CODE_GOOD == status_code
        pending_rows = self.assign.get_pending_rows_from_metadata_file()
        self.assign.update_pending_rows_file(pending_rows, instructor_info=instructor_username, grade_info=30.19, status_info=grade_status)
        response = self.assign.validate_evaluation_file(basic_auth, file_name=validate_metadata_file)
        response_body = self.assign.get_content(response)
        status_code = self.assign.get_status_code(response)
        self.logger.info(f"status code: {status_code}")
        assert BAD_REQUEST_STATUS_CODE_400 == status_code
        assert self.user.compare_expected_and_actual_result(response_body[errors_key][0], message_key, error_decimal_value)
        self.logger.info(f"message key exists with value {error_decimal_value}")

    def test_upload_grades_with_invalid_instructor_name(self, basic_auth):
        """
        MAPOAS-1963
        Hit api and validate the following response
        - status code must be 400
        - errors key exists with message "Instructor Username is missing" and
        "Grade Status must be passed or failed for rows to be evaluated"
        """
        response = self.assign.get_refresh_link_status(basic_auth)
        response_body = self.assign.get_content(response)
        status_code = self.assign.get_status_code(response)
        assert STATUS_CODE_GOOD == status_code
        self.logger.info(f"status code: {status_code}")
        response = self.user.upload_participants_file(token=basic_auth, p_id=None, group_work=GROUP_WORK)
        response_body = self.user.get_content(response)
        self.logger.info(response_body)
        status_code = self.user.get_status_code(response)
        self.logger.info(f"status code: {status_code}")
        assert STATUS_CODE_GOOD == status_code
        assert self.user.compare_expected_and_actual_result(response_body, success_key, true_value)
        self.logger.info(f"{message_key} exist and contains value: {true_value}")
        transaction_id = self.user.get_transaction_id(response_body)
        details = self.user.user_uploading_got_completed(transaction_id, basic_auth)
        self.logger.info(details)
        assert self.user.check_if_pending(details, transaction_id, transaction_status_key, basic_auth)
        assert self.user.validate_user_uploading_response(details, transaction_id, status=transaction_status_key)
        self.logger.info("transaction status came as COMPLETED")

        assert self.user.validate_user_uploading_response(details, transaction_id, status=transaction_status_key)
        self.logger.info("transaction status came as COMPLETED")
        resp = self.docebo.docebo_lms_login()
        self.logger.info("new assignment has been submitted by learner")
        assert self.assign.verify_key_exist_with_valid_value_type(resp, 'id', int)
        self.logger.info("id key exists with an integer value")
        response = self.assign.get_refresh_link_status(basic_auth)
        response_body = self.assign.get_content(response)
        status_code = self.assign.get_status_code(response)
        assert STATUS_CODE_GOOD == status_code
        self.logger.info(f"status code: {status_code}")

        # response = self.assign.get_refresh_link_status(basic_auth)
        # response = self.assign.download_metadata_file(basic_auth)
        # status_code = self.assign.get_status_code(response)
        # self.logger.info(f"status code: {status_code}")
        # assert STATUS_CODE_GOOD == status_code
        # pending_rows = self.assign.get_pending_rows_from_metadata_file()
        # self.assign.update_pending_rows_file(pending_rows, instructor_info="", grade_info=20, status_info='test')
        # response = self.assign.validate_evaluation_file(basic_auth, file_name=validate_metadata_file)
        # response_body = self.assign.get_content(response)
        # status_code = self.assign.get_status_code(response)
        # self.logger.info(f"status code: {status_code}")
        # assert BAD_REQUEST_STATUS_CODE_400 == status_code
        # assert self.user.compare_expected_and_actual_result(response_body[errors_key][0], message_key, error_missing_instructor_name)
        # self.logger.info(f"message key exists with value {error_missing_instructor_name}")
        # assert self.user.compare_expected_and_actual_result(response_body[errors_key][1], message_key, error_invalid_grade_status)
        # self.logger.info(f"message key exists with value {error_invalid_grade_status}")

        # response = self.assign.validate_modify_grades_file(basic_auth, file_name=validate_metadata_file)
        # response_body = self.assign.get_content(response)
        # status_code = self.assign.get_status_code(response)
        # self.logger.info(f"status code: {status_code}")
        # assert BAD_REQUEST_STATUS_CODE_400 == status_code
        # assert self.user.compare_expected_and_actual_result(response_body[errors_key][0], message_key, error_no_grades_modification)
        # self.logger.info(f"message key exists with value {error_missing_instructor_name}")

    def test_upload_grades_with_different_grade_status(self, basic_auth):
        """
        MAPOAS-1967
        Hit api  and validate following response
        - status code must be 400
        - message to be "Different grade status found for single groupwork"
        """
        response = self.assign.get_refresh_link_status(basic_auth)
        response_body = self.assign.get_content(response)
        status_code = self.assign.get_status_code(response)
        assert STATUS_CODE_GOOD == status_code
        self.logger.info(f"status code: {status_code}")
        response = self.user.upload_participants_file(token=basic_auth, p_id=None, group_work=GROUP_WORK)
        response_body = self.user.get_content(response)
        self.logger.info(response_body)
        status_code = self.user.get_status_code(response)
        self.logger.info(f"status code: {status_code}")
        assert STATUS_CODE_GOOD == status_code
        assert self.user.compare_expected_and_actual_result(response_body, success_key, true_value)
        self.logger.info(f"{message_key} exist and contains value: {true_value}")
        transaction_id = self.user.get_transaction_id(response_body)
        details = self.user.user_uploading_got_completed(transaction_id, basic_auth)
        self.logger.info(details)
        assert self.user.validate_user_uploading_response(details, transaction_id, status=transaction_status_key)
        self.logger.info("transaction status came as COMPLETED")
        resp = self.docebo.docebo_lms_login()
        self.logger.info("new assignment has been submitted by learner")
        assert self.assign.verify_key_exist_with_valid_value_type(resp, 'id', int)
        self.logger.info("id key exists with an integer value")
        response = self.assign.get_refresh_link_status(basic_auth)
        response_body = self.assign.get_content(response)
        status_code = self.assign.get_status_code(response)
        assert STATUS_CODE_GOOD == status_code
        self.logger.info(f"status code: {status_code}")

        response = self.assign.get_refresh_link_status(basic_auth)
        status_code = self.assign.get_status_code(response)
        assert STATUS_CODE_GOOD == status_code
        self.logger.info(f"status code: {status_code}")
        # response = self.assign.download_metadata_file(basic_auth)
        # status_code = self.assign.get_status_code(response)
        # self.logger.info(f"status code: {status_code}")
        # assert STATUS_CODE_GOOD == status_code
        # pending_rows = self.assign.get_pending_rows_from_metadata_file()
        # self.assign.update_pending_rows_file(pending_rows, instructor_info=instructor_username, grade_info=20, status_info='passed', flag=1)
        # response = self.assign.validate_evaluation_file(basic_auth, file_name=validate_metadata_file)
        # response_body = self.assign.get_content(response)
        # status_code = self.assign.get_status_code(response)
        # self.logger.info(f"status code: {status_code}")
        # assert BAD_REQUEST_STATUS_CODE_400 == status_code
        # assert self.user.compare_expected_and_actual_result(response_body[errors_key][0], message_key, error_different_grade_status)
        # self.logger.info(f"message key exists with value {error_different_grade_status}")

    def test_download_all_assignments(self, basic_auth):
        """
        MAPOAS-1957
        Download All Assignments --> 3rd option
        Hit api
        we will use the assignment id from above api
        - status code to be 200
        - transaction_id key exist and must have valid value store that value for further usage
        - success key exist with value to be True

        MAPOAS-1958
        Hit api and validate following response
        - status code to be 200
        - url key

        Hit api and validate response
        - status code to be 200
        - data: [{created_at: "2022-09-26 11:11:20", id: 888, transaction_id: 9467,…},…]
        - success key exist with value true
        - transaction id key exist with some valid value

        """
        response = self.assign.get_refresh_link_status(basic_auth)
        response_body = self.assign.get_content(response)
        status_code = self.assign.get_status_code(response)
        assert STATUS_CODE_GOOD == status_code
        self.logger.info(f"status code: {status_code}")

        # response = self.assign.get_download_all_assignments(basic_auth)
        # response_body = self.user.get_content(response)
        # self.logger.info(response_body)
        # status_code = self.user.get_status_code(response)
        # self.logger.info(f"status code: {status_code}")
        # assert STATUS_CODE_GOOD == status_code
        # assert self.user.compare_expected_and_actual_result(response_body, success_key, true_value)
        # self.logger.info(f"{success_key} exists and contains value: {true_value}")
        # transaction_id = self.assign.get_transaction_id(response_body)
        # details = self.assign.downloading_got_completed(transaction_id, basic_auth)
        # self.logger.info(details)
        # assert self.user.compare_expected_and_actual_result(details, done_key, true_value)
        # self.logger.info(f"done exists and contains value: {true_value}")
        # assert self.user.compare_expected_and_actual_result(details, 'percentage', 100)
        # self.logger.info(f"percentage value exists and contains valid value")
        # assert self.user.compare_expected_and_actual_result(details, transaction_id_key, transaction_id)
        # self.logger.info(f"{transaction_id_key} exists and contains value {transaction_id}")

        # report_response = self.assign.get_s3_url(transaction_id, basic_auth)
        # report_body = self.user.get_content(report_response)
        # self.logger.info(report_body)
        # status_code = self.user.get_status_code(report_response)
        # self.logger.info(f"status code: {status_code}")
        # assert STATUS_CODE_GOOD == status_code
        # assert self.user.compare_expected_and_actual_result(report_body, success_key, true_value)
        # self.logger.info(f"{success_key} exists and contains value: {true_value}")
        # assert self.assign.verify_key_exist_with_valid_value_type(report_body, 'url')
        # self.logger.info(f"url exists and contains value in string")
        # url = report_body.get('url')
        # response = self.assign.download_all_assignments_file(url)
        # status_code = self.user.get_status_code(response)
        # self.logger.info(f"status code: {status_code}")
        # assert STATUS_CODE_GOOD == status_code
        # response = self.assign.get_list(basic_auth)
        # response_body = self.user.get_content(response)
        # self.logger.info(response_body)
        # status_code = self.user.get_status_code(response)
        # self.logger.info(f"status code: {status_code}")
        # assert STATUS_CODE_GOOD == status_code
        # assert self.user.compare_expected_and_actual_result(response_body, success_key, true_value)
        # self.logger.info(f"{success_key} exist and contains value: {true_value}")
        # assert self.assign.verify_key_exist_with_valid_value_type(response_body, data_key)
        # self.logger.info(f"{data_key} key exist having some valid values in it")
        # assert self.assign.validate_list_response(response_body)

    def test_upload_grades(self, basic_auth):
        """
        MAPOAS-1951
        Create a sheet using group work value to be Group 01 - TEST_YESCHANNEL_JUL22 ; Automation_Assignment and pass values
        to column like instructor username: khurram_shahzad@external.mckinsey.com grade value: 85 grade status: passed
        allow re-upload: false
        hit api
        - status code must be 200
        - message key exist with value to be File validation successful

        Hit api
        - status code to be 200
        - success key exist with value to be true
        - transaction_id key exist store that value to hit in progress api based on t_id

        hit api
        progress will start and use the same method
        - done to be true - percentage to be 100
        - status code to be 200
        - transaction_status key exist with value to be completed
        - report key exist with values to be total:2 skipped_count:0 passed_count:2
        failed_count:0 Note: numbers will be dependent on users that we created
        """

        response = self.assign.get_refresh_link_status(basic_auth)
        response_body = self.assign.get_content(response)
        status_code = self.assign.get_status_code(response)
        assert STATUS_CODE_GOOD == status_code
        self.logger.info(f"status code: {status_code}")
        response = self.user.upload_participants_file(token=basic_auth, p_id=None, group_work=GROUP_WORK)
        response_body = self.user.get_content(response)
        self.logger.info(response_body)
        status_code = self.user.get_status_code(response)
        self.logger.info(f"status code: {status_code}")
        assert STATUS_CODE_GOOD == status_code
        assert self.user.compare_expected_and_actual_result(response_body, success_key, true_value)
        self.logger.info(f"{message_key} exist and contains value: {true_value}")
        transaction_id = self.user.get_transaction_id(response_body)
        details = self.user.user_uploading_got_completed(transaction_id, basic_auth)
        self.logger.info(details)
        assert self.user.validate_user_uploading_response(details, transaction_id, status=transaction_status_key)
        self.logger.info("transaction status came as COMPLETED")
        resp = self.docebo.docebo_lms_login()
        self.logger.info("new assignment has been submitted by learner")
        assert self.assign.verify_key_exist_with_valid_value_type(resp, 'id', int)
        self.logger.info("id key exists with an integer value")
        response = self.assign.get_refresh_link_status(basic_auth)
        response_body = self.assign.get_content(response)
        status_code = self.assign.get_status_code(response)
        assert STATUS_CODE_GOOD == status_code
        self.logger.info(f"status code: {status_code}")

        response = self.assign.get_refresh_link_status(basic_auth)
        status_code = self.assign.get_status_code(response)
        assert STATUS_CODE_GOOD == status_code
        self.logger.info(f"status code: {status_code}")
        response = self.assign.download_metadata_file(basic_auth)
        status_code = self.assign.get_status_code(response)
        self.logger.info(f"status code: {status_code}")
        assert STATUS_CODE_GOOD == status_code
        self.assign.write_metadata_file(instructor_username, grade_value, grade_status)
        response = self.assign.validate_evaluation_file(basic_auth, file_name=metadata_file)
        response_body = self.assign.get_content(response)
        status_code = self.assign.get_status_code(response)
        self.logger.info(f"status code: {status_code}")
        assert STATUS_CODE_GOOD == status_code
        assert self.user.compare_expected_and_actual_result(response_body, message_key, file_validation_message)
        self.logger.info(f"message key exists with value {file_validation_message}")
        response = self.assign.upload_evaluation_file(basic_auth, file_name=metadata_file)
        response_body = self.assign.get_content(response)
        status_code = self.assign.get_status_code(response)
        self.logger.info(f"status code: {status_code}")
        assert STATUS_CODE_GOOD == status_code
        assert self.user.compare_expected_and_actual_result(response_body, success_key, true_value)
        self.logger.info(f"success key exists with value {true_value}")
        transaction_id = self.user.get_transaction_id(response_body)
        self.assign.downloading_got_completed(transaction_id, basic_auth)
        response = self.assign.get_list_of_uploaded_grades(basic_auth)
        response_body = self.assign.get_content(response)
        status_code = self.assign.get_status_code(response)
        self.logger.info(f"status code: {status_code}")
        assert STATUS_CODE_GOOD == status_code
        assert self.user.compare_expected_and_actual_result(response_body, success_key, true_value)
        self.logger.info(f"success key exists with value {true_value}")
        assert self.user.verify_key_exist_with_valid_value_type(response_body, data_key)
        self.logger.info(f"data key exists with valid value type")
        assert self.assign.validate_data_response(response_body)
        self.logger.info(f"data key exists with valid values")
        response = self.assign.get_refresh_link_status(basic_auth)
        status_code = self.assign.get_status_code(response)
        assert STATUS_CODE_GOOD == status_code
        self.logger.info(f"status code: {status_code}")
        # response = self.assign.download_metadata_file(basic_auth)
        # status_code = self.assign.get_status_code(response)
        # self.logger.info(f"status code: {status_code}")
        # assert STATUS_CODE_GOOD == status_code
        # self.assign.write_metadata_file(instructor_username, grade_value, grade_status)

        # response = self.assign.validate_evaluation_file(basic_auth, file_name=metadata_file)
        # response_body = self.assign.get_content(response)
        # status_code = self.assign.get_status_code(response)
        # self.logger.info(f"status code: {status_code}")
        # assert STATUS_CODE_GOOD == status_code
        # assert self.user.compare_expected_and_actual_result(response_body[errors_key][0], message_key,
        #                                                     error_no_rows_message)
        # self.logger.info(f"message key exists with value {error_no_rows_message}")
        # updated_message = {'message': 'File validation successful', 'steps': []}

    def test_modify_grades(self, basic_auth):
        """
        MAPOAS-1969
        Modify the latest metadata with new grades and comments now create a sheet using group work value to be
        “[Group work 01]“and pass values to column like instructor username: khurram_shahzad@external.mckinsey.com
        grade value: 95 grade status: passed comments: done allow re-upload: false
        Upload the latest modified sheet
        hit api
        - message key exist with value to be File validation successful

        Hit api put request with modified file
        - status code to be 200
        - success key exist with value to be true
        - transaction_id key exist store that value to hit inprogress api based on t_id
        hit api progress will start and use the same method
        - done to be true
        - percentage to be 100
        - status code to be 200
        - transaction_status key exist with value to be completed
        - report key exist with valid values

        - status code must be 200
        - data key exists having courses info
        """
        response = self.assign.get_refresh_link_status(basic_auth)
        status_code = self.assign.get_status_code(response)
        assert STATUS_CODE_GOOD == status_code
        self.logger.info(f"status code: {status_code}")
        response = self.assign.download_metadata_file(basic_auth)
        status_code = self.assign.get_status_code(response)
        self.logger.info(f"status code: {status_code}")
        assert STATUS_CODE_GOOD == status_code
        self.assign.write_metadata_file(instructor_username, grade_val=95, g_status=grade_status)
        response = self.assign.validate_modify_grades_file(basic_auth, file_name=metadata_file)
        response_body = self.assign.get_content(response)
        status_code = self.assign.get_status_code(response)
        self.logger.info(f"status code: {status_code}")
        assert STATUS_CODE_GOOD == status_code
        assert self.user.compare_expected_and_actual_result(response_body, message_key, file_validation_message)
        self.logger.info(f"message key exists with value {file_validation_message}")
        response = self.assign.upload_modify_grades_file(basic_auth, file_name=metadata_file)
        response_body = self.assign.get_content(response)
        status_code = self.assign.get_status_code(response)
        self.logger.info(f"status code: {status_code}")
        assert STATUS_CODE_GOOD == status_code
        assert self.user.compare_expected_and_actual_result(response_body, success_key, true_value)
        self.logger.info(f"success key exists with value {true_value}")
        transaction_id = self.user.get_transaction_id(response_body)
        self.assign.downloading_got_completed(transaction_id, basic_auth)
        response = self.assign.get_list_of_uploaded_grades(basic_auth)
        response_body = self.assign.get_content(response)
        status_code = self.assign.get_status_code(response)
        self.logger.info(f"status code: {status_code}")
        assert STATUS_CODE_GOOD == status_code
        assert self.user.compare_expected_and_actual_result(response_body, success_key, true_value)
        self.logger.info(f"success key exists with value {true_value}")
        assert self.user.verify_key_exist_with_valid_value_type(response_body, data_key)
        self.logger.info(f"data key exists with valid value type")
        assert self.assign.validate_data_response(response_body)
        self.logger.info(f"data key exists with valid values")
