import time
import pytest

from test.mcka_ops_portal_api.config import *
from ...resources.utils import random_word

from test.mcka_ops_portal_api.api_e2e.api_library.enrollment_cohort import EnrollmentCohort
from test.mcka_ops_portal_api.api_e2e.api_library.groupwork import GroupWork


class TestEnrollmentCohort:
    enrollment_cohort = EnrollmentCohort()
    logger = Log
    groupwork = GroupWork

    def test_create_edit_del_wave_cohort_single_success(self, basic_auth):
        """
        (Enrollment Cohort) Create, deactivate, activate and delete the test user(s) along with all
        required validations
        """
        # create single client cohort
        ec_code = random_word(15)
        wave_name = 'Automation Cohort'
        experience_type = 'Single Client'
        response = self.enrollment_cohort.create_wave_cohort(basic_auth, ec_code, wave_name)
        response_body = self.enrollment_cohort.get_content(response)
        self.logger.info(response_body)

        status_code = self.enrollment_cohort.get_status_code(response)
        assert response.status_code == status_code

        assert self.enrollment_cohort.compare_expected_and_actual_result(response_body, success_key, true_value)
        self.logger.info(f"{success_key} key exist with value as {true_value}")
        assert self.enrollment_cohort.compare_expected_and_actual_result(response_body, message_key,
                                                                         create_wave_cohort_success_message)
        self.logger.info(f"{message_key} key exist with value as {create_wave_cohort_success_message}")
        assert self.enrollment_cohort.verify_key_exist_with_valid_value_type(response_body, wave_id_key, value_type=int)
        self.logger.info(f"{message_key} key exist with some Valid Value")

        new_wave_id = response_body[wave_id_key]

        # verify newly created wave cohort details
        wave_details_response = self.enrollment_cohort.get_wave_details(basic_auth, new_wave_id)
        wave_details_response_body = self.enrollment_cohort.get_content(wave_details_response)

        assert self.enrollment_cohort.validate_wave_cohort_details(wave_details_response_body, new_wave_id, ec_code,
                                                                   wave_name, experience_type)

        # edit wave cohort
        updated_ec_code = f'{ec_code}_new'
        updated_wave_name = f'{wave_name}_new'
        experience_type = 'Multiclient'
        response = self.enrollment_cohort.edit_wave_cohort(basic_auth, new_wave_id, updated_ec_code, updated_wave_name,
                                                           experience_type)
        response_body = self.enrollment_cohort.get_content(response)
        self.logger.info(response_body)

        status_code = self.enrollment_cohort.get_status_code(response)
        assert response.status_code == status_code

        assert self.enrollment_cohort.compare_expected_and_actual_result(response_body, success_key, true_value)
        self.logger.info(f"{success_key} key exist with value as {true_value}")
        assert self.enrollment_cohort.compare_expected_and_actual_result(response_body, message_key,
                                                                         edit_wave_cohort_success_message)

        # verify edited wave cohort details
        wave_details_response = self.enrollment_cohort.get_wave_details(basic_auth, new_wave_id)
        wave_details_response_body = self.enrollment_cohort.get_content(wave_details_response)
        status_code = self.enrollment_cohort.get_status_code(response)
        assert response.status_code == status_code
        assert self.enrollment_cohort.validate_wave_cohort_details(wave_details_response_body, new_wave_id,
                                                                   updated_ec_code, updated_wave_name, experience_type)

        # Delete wave cohort
        delete_wave_response = self.enrollment_cohort.delete_wave_cohort(access_token=basic_auth, del_wave_id=new_wave_id)
        delete_wave_response_body = self.enrollment_cohort.get_content(delete_wave_response)
        self.logger.info(response_body)

        status_code = self.enrollment_cohort.get_status_code(delete_wave_response)
        assert delete_wave_response.status_code == status_code

        assert self.enrollment_cohort.compare_expected_and_actual_result(delete_wave_response_body, success_key,
                                                                         true_value)
        self.logger.info(f"{success_key} key exist with value as {true_value}")
        assert self.enrollment_cohort.compare_expected_and_actual_result(delete_wave_response_body, message_key,
                                                                         delete_wave_cohort_success_message)

    def test_create_edit_del_wave_cohort_multiclient_success(self, basic_auth):
        """
        (Enrollment Cohort) Create, deactivate, activate and delete the test user(s) along with all
        required validations
        """
        # create single client cohort
        ec_code = random_word(15)
        wave_name = 'Automation Cohort'
        experience_type = 'Multiclient'
        response = self.enrollment_cohort.create_wave_cohort(basic_auth, ec_code, wave_name, experience_type)
        response_body = self.enrollment_cohort.get_content(response)
        self.logger.info(response_body)

        status_code = self.enrollment_cohort.get_status_code(response)
        assert response.status_code == status_code

        assert self.enrollment_cohort.compare_expected_and_actual_result(response_body, success_key, true_value)
        self.logger.info(f"{success_key} key exist with value as {true_value}")
        assert self.enrollment_cohort.compare_expected_and_actual_result(response_body, message_key,
                                                                         create_wave_cohort_success_message)
        self.logger.info(f"{message_key} key exist with value as {create_wave_cohort_success_message}")
        assert self.enrollment_cohort.verify_key_exist_with_valid_value_type(response_body, wave_id_key, value_type=int)
        self.logger.info(f"{message_key} key exist with some Valid Value")

    def test_create_edit_del_wave_cohort_b2c_success(self, basic_auth):
        """
        (Enrollment Cohort) Create, deactivate, activate and delete the test user(s) along with all
        required validations
        """
        # create single client cohort
        ec_code = random_word(15)
        wave_name = 'Automation Cohort'
        experience_type = 'B2C'
        response = self.enrollment_cohort.create_wave_cohort(basic_auth, ec_code, wave_name, experience_type)
        response_body = self.enrollment_cohort.get_content(response)
        self.logger.info(response_body)

        status_code = self.enrollment_cohort.get_status_code(response)
        assert response.status_code == status_code

        assert self.enrollment_cohort.compare_expected_and_actual_result(response_body, success_key, true_value)
        self.logger.info(f"{success_key} key exist with value as {true_value}")
        assert self.enrollment_cohort.compare_expected_and_actual_result(response_body, message_key,
                                                                         create_wave_cohort_success_message)
        self.logger.info(f"{message_key} key exist with value as {create_wave_cohort_success_message}")
        assert self.enrollment_cohort.verify_key_exist_with_valid_value_type(response_body, wave_id_key, value_type=int)
        self.logger.info(f"{message_key} key exist with some Valid Value")

    @pytest.mark.skip()
    def test_users_in_wave_cohort(self, basic_auth):
        """
        (Enrollment Cohort) Create, deactivate, activate and delete the test user(s) along with all
        required validations
        """
        # create single client cohort
        response = self.enrollment_cohort.get_wave_details_user(basic_auth, users_wave_id)
        response_body = self.enrollment_cohort.get_content(response)
        self.logger.info(response_body)
        assert response.status_code == STATUS_CODE_GOOD

        assert self.enrollment_cohort.compare_expected_and_actual_result(response_body, success_key, true_value)
        self.logger.info(f"{success_key} key exist with value as {true_value}")
        assert self.enrollment_cohort.compare_expected_and_actual_result(response_body[data_key]['users'][0],
                                                                         'email', wave_email_id)
        assert self.enrollment_cohort.compare_expected_and_actual_result(response_body[data_key]['users'][0],
                                                                         'user_name', wave_email_id)
        assert self.enrollment_cohort.verify_key_exist_with_valid_value_type(response_body[data_key]['users'][0],
                                                                             'firstname')
        assert self.enrollment_cohort.verify_key_exist_with_valid_value_type(response_body[data_key]['users'][0],
                                                                             'lastname')

    def test_component_in_wave_cohort(self, basic_auth):
        """
        (Enrollment Cohort) Create, deactivate, activate and delete the test user(s) along with all
        required validations
        """
        # create single client cohort
        response = self.enrollment_cohort.get_waves_components_details(basic_auth, wave_id)
        response_body = self.enrollment_cohort.get_content(response)
        self.logger.info(response_body)
        assert response.status_code == STATUS_CODE_GOOD

        assert self.enrollment_cohort.compare_expected_and_actual_result(response_body, success_key, true_value)
        self.logger.info(f"{success_key} key exist with value as {true_value}")
        assert self.enrollment_cohort.verify_key_exist_with_valid_value_type(response_body['components'][0],
                                                                             'course_id', int)
        assert self.enrollment_cohort.verify_key_exist_with_valid_value_type(response_body['components'][0], 'due_date')

    def test_create_wave_cohort_failure(self, basic_auth):
        """
        (Enrollment Cohort)
        """
        ec_code = 'cl_of_230101_46'
        wave_name = 'Automation Cohort'
        experience_type = 'Single Client'

        # create single client cohort
        response = self.enrollment_cohort.create_wave_cohort(basic_auth, ec_code, wave_name, experience_type)
        response_body = self.enrollment_cohort.get_content(response)
        self.logger.info(response_body)
        status_code = self.enrollment_cohort.get_status_code(response)
        assert response.status_code == CONFLICT_RESPONSE_STATUS_CODE_409

        assert self.enrollment_cohort.compare_expected_and_actual_result(response_body, success_key, false_value)
        assert self.enrollment_cohort.compare_expected_and_actual_result(response_body, message_key,
                                                                         create_wave_cohort_fail_message)

    @pytest.mark.skip()
    def test_upload_transfer_user(self, basic_auth):
        """
        (Enrollment Cohort)
        """
        # create single client cohort
        response = self.enrollment_cohort.upload_participants_file(basic_auth)
        response_body = self.enrollment_cohort.get_content(response)
        transaction_id = self.enrollment_cohort.get_transaction_id(response_body)
        response = self.enrollment_cohort.user_uploading_got_completed(transaction_id, basic_auth)
        assert self.enrollment_cohort.check_if_pending(response, transaction_id, transaction_status_key, basic_auth)

        self.enrollment_cohort.create_transfer_users_file(sheet_name='transfer cohort users',
                                                          target_ec_code=target_ec_code)

        response = self.enrollment_cohort.validate_transfer_users_file(basic_auth)
        response_body = self.enrollment_cohort.get_content(response)
        self.logger.info(response_body)
        assert response.status_code == STATUS_CODE_GOOD

        response = self.enrollment_cohort.upload_transfer_users_file(basic_auth, enrolled_session_program_id)
        response_body = self.enrollment_cohort.get_content(response)
        self.logger.info(response_body)
        assert response.status_code == STATUS_CODE_GOOD

        transaction_id = self.enrollment_cohort.get_transaction_id(response_body)
        response = self.enrollment_cohort.user_uploading_got_completed(transaction_id, basic_auth)

        response = self.enrollment_cohort.get_enrollment_cohort_waves(access_token=basic_auth, p_id=enrolled_session_program_id)
        response_body = self.enrollment_cohort.get_content(response)
        status_code = self.enrollment_cohort.get_status_code(response)

        assert STATUS_CODE_GOOD == status_code
        self.logger.info(f"status code: {status_code}")

        assert self.enrollment_cohort.compare_expected_and_actual_result(response_body[data_key][0], user_count_key, user_count)
        assert self.enrollment_cohort.compare_expected_and_actual_result(response_body[data_key][0], wave_id_key, wave_id)
        assert self.enrollment_cohort.verify_key_exist_with_valid_value_type(response_body[data_key][1], user_count_key, int)
        assert self.enrollment_cohort.verify_key_exist_with_valid_value_type(response_body[data_key][1], wave_id_key, int)

    def test_validate_transfer_user_empty_sheet_failure(self, basic_auth):
        # create single client cohort
        self.enrollment_cohort.create_transfer_users_file(sheet_name='abc', ec_code_column=False)

        response = self.enrollment_cohort.validate_transfer_users_file(basic_auth)
        response_body = self.enrollment_cohort.get_content(response)
        self.logger.info(response_body)
        assert response.status_code == BAD_REQUEST_STATUS_CODE_400

        assert self.enrollment_cohort.compare_expected_and_actual_result(response_body[errors_key][0], message_key,
                                                                         validate_wave_cohort_fail_message_1)
        assert self.enrollment_cohort.compare_expected_and_actual_result(response_body[errors_key][1], message_key,
                                                                         validate_wave_cohort_fail_message_2)
        assert self.enrollment_cohort.compare_expected_and_actual_result(response_body[errors_key][2], message_key,
                                                                         validate_wave_cohort_fail_message_3)

    def test_validate_transfer_user_missing_text_failure(self, basic_auth):

        # # create single client cohort
        self.enrollment_cohort.create_transfer_users_file(sheet_name='transfer cohort users', ec_code='abc',
                                                          valid_sheet=False)

        response = self.enrollment_cohort.validate_transfer_users_file(basic_auth)
        response_body = self.enrollment_cohort.get_content(response)
        self.logger.info(response_body)

        assert response.status_code == BAD_REQUEST_STATUS_CODE_400
        assert self.enrollment_cohort.compare_expected_and_actual_result(response_body[errors_key][0], 'column',
                                                                         'transfer cohort users: target cohort ec_code')
        assert self.enrollment_cohort.compare_expected_and_actual_result(response_body[errors_key][0], 'value', 'null')
        assert self.enrollment_cohort.compare_expected_and_actual_result(
            response_body[errors_key][0], 'message',
            'Text missing / too short / too long [ allowed limit : 1 - 255 chars ]')

    def test_validate_transfer_user_missing_cohort_columns_failure(self, basic_auth):
        """
        Validate error when sheet doesn't have correct column value
        """
        self.enrollment_cohort.create_transfer_users_file(valid_sheet=False, sheet_name='transfer cohort users',
                                                          ec_code_column=False, ec_code='abc')
        response = self.enrollment_cohort.validate_transfer_users_file(basic_auth)
        response_body = self.enrollment_cohort.get_content(response)
        self.logger.info(response_body)
        assert response.status_code == BAD_REQUEST_STATUS_CODE_400
        assert self.enrollment_cohort.compare_expected_and_actual_result(
            response_body[errors_key][0], 'message',
            'target cohort ec_code columns are missing in sheet transfer cohort users')
