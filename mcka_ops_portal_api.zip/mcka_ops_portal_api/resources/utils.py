import random
import string


def build_request_headers(access_token, content_type="application/json"):
    request_header = {
        "Authorization": f"Bearer {access_token}",
        "content_type": content_type,
        "x-tenant": "a0000000-b111-c111-d111-e11111111111"
    }
    return request_header


def random_word(length):
    letters = string.ascii_lowercase
    return "".join(random.choice(letters) for i in range(length))
