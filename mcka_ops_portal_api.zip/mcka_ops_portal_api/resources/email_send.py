import email
from datetime import datetime
from email.utils import formataddr
from smtplib import SMTP_SSL, SMTPException
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
import logging
import sys


class EmailSend:

    log = logging.getLogger()
    DATETIME_FORMAT = '{0.day:0>2}-{0.month:0>2}-{0.year} {0.hour:0>2}:{0.minute:0>2}:{0.second:0>2}'.format

    def send_email(self):
        """
        This method will send an email to the targeted recipients
        """
        SENDER = 'automationtesting_&_EWs@mckinsey.com'
        self.log.info("In send_email")
        msg = MIMEMultipart('alternative')
        msg['Subject'] = f"OpsPortal Regression Test Automation Report {self.DATETIME_FORMAT(datetime.now())}"
        msg['From'] = formataddr(("AutomationCOE", SENDER))
        recipients = ["roopal_kulshreshtha@external.mckinsey.com", "khurram_shahzad@external.mckinsey.com"]
        msg['To'] = ", ".join(recipients)
        BODY_TEXT = "Hi All,"
        BODY_HTML = """
            <html>
                <head>
                    <meta charset="UTF-8">
                </head>
                <body>
                    <!--[if mso]>
                        <table>
                            <tr>
                                <td>
                    <![endif]-->
                    <p>Dear Team,</p>
                    <p>Please find the link of
                        <a href='https://animated-adventure-82gr8my.pages.github.io/dev/'> allure report </a> with the results of latest execution!
                    </p>
                    <!--[if mso]>
                        <table>
                    <![endif]-->
                    <!--[if mso]>
                        </table>
                    <![endif]-->
                    <p>Thank you,</p>
                    <p>Automation Team</p>
                </body>
            </html>"""
        part1 = MIMEText(BODY_TEXT, 'plain')
        part2 = MIMEText(BODY_HTML, 'html')
        msg.attach(part1)
        msg.attach(part2)
        try:
            with SMTP_SSL("email-smtp.us-east-1.amazonaws.com", 465) as server:
                server.login("AKIASBIQ5UCLVNL5RUFB", "BBRiNeBFdThoMZzo/nYidbluieZt/abG6IQ7XB4UXfkL")

                self.log.info("Triggering Email to ")
                server.sendmail("automationtesting_&_EWs@mckinsey.com", recipients, msg.as_string())
                server.close()
                self.log.info("Email sent!")
        except SMTPException as e:
            self.log.info(f"Error: {e}")


email = EmailSend()
email.send_email()
