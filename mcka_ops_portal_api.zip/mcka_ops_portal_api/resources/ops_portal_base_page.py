"""
Ops portal base class for page objects
"""
import requests
from ..config import *
import json
import random
import string


class OpsPortalBase(object):
    """
    Base class for page objects.
    """

    def __init__(self):
        """
        Initializing the session.
        """
        self.session = requests.session()

    @staticmethod
    def verify_keys_exist_with_valid_value_type(response_body, keys_list, value_type=str):
        """
        verify each entry exit in response body with valid value and type
        :return (bool) True if all entries valid
        """
        for key in keys_list:
            value = response_body[key]
            if value and isinstance(value, value_type):
                continue
            raise Exception(RESULTS_NOT_FOUND.format(key))

        return True

    @staticmethod
    def _get_random_strings():
        random_string_f = ''.join(random.choices(string.ascii_uppercase + string.digits, k=2))
        random_string_s = ''.join(random.choices(string.ascii_uppercase + string.hexdigits, k=2))
        return random_string_f, random_string_s

    @staticmethod
    def verify_key_exist_with_valid_value_type(response_body, key, value_type=str):
        """
        verify each entry exit in response body with valid value and type
        :return (bool) True if all values matched
        """
        value = response_body[key]
        if not value and not isinstance(value, value_type):
            raise Exception(RESULTS_NOT_FOUND.format(key))
        return True

    @staticmethod
    def verify_value_exist_in_a_list(value, list_values):
        """
        validate value exist in a list
        :return (bool) True if exist
        """
        if value not in list_values:
            raise Exception(RESULTS_NOT_FOUND.format(value))
        return True

    @staticmethod
    def verify_value_not_exist(response_body, key, value=''):
        """
        validate value is empty
        :return (bool) True if not exist
        """
        result = response_body[key]
        if result != value:
            raise Exception(RESULTS_FOUND.format(result))
        return True

    def compare_expected_and_actual_results(self, response_body, keys, values_to_match):
        """
        base page method
        compare expected result with actual result
        :return (bool) True if matches
        """
        for key, value in zip(keys, values_to_match):
            self.compare_expected_and_actual_result(response_body, key, value)
            Log.info(f"{key} key found having value as: {value}")
        return True

    @staticmethod
    def compare_expected_and_actual_result(response_body, expected_key, actual):
        """
        base page method
        compare expected result with actual result
        :return (bool) True if matches
        """
        expected = response_body.get(expected_key)
        results_matched = actual == expected or actual in expected
        if not results_matched:
            raise Exception(FAILED_TO_MATCH_VALUES.format(expected, actual))
        return results_matched

    @staticmethod
    def compare_expected_and_actual_values(expected, actual):
        """
        base page method
        compare expected result with actual result
        :return (bool) True if matches
        """
        results_matched = actual == expected or actual in expected
        if not results_matched:
            raise Exception(FAILED_TO_MATCH_VALUES.format(expected, actual))
        return results_matched

    @staticmethod
    def verify_entry(response_body, value, bool_val):
        """
        compare entry with name
        :return (bool) True if matched
        """
        entry_value = response_body[value]
        if entry_value != bool_val:
            raise Exception(FAILED_TO_FIND_VALUE_IN_RESPONSE.format(value, response_body))
        return True

    def verify_entries(self, response_body, keys, bool_val):
        for each in keys:
            self.verify_entry(response_body, each, bool_val)
        return True

    @staticmethod
    def get_status_code(response):
        """
        get response
        :return status code
        """
        return response.status_code

    @staticmethod
    def get_content(response):
        """
        get response
        :return python object
        """
        return json.loads(response.text)

    @staticmethod
    def get_transaction_id(response_body):
        return response_body['transaction_id']

    def _check_response(self, response, email):
        """
        Check whether a response was successful.
        """
        if response.status_code != 200:
            raise Exception(f'API request failed with following error code: {str(response.status_code)} and text: '
                            f'{str(response.status_code)} with user email {email}')

    def _get_headers(self, token):
        return {
            'accept': 'application/json, text/plain, */*',
            'accept-language': 'en-GB,en-US;q=0.9,en;q=0.8',
            'accept-encoding': 'gzip, deflate, br',
            'authorization': f'Bearer {token}',
            'x-tenant': 'a0000000-b111-c111-d111-e11111111111'
        }

    def _lti_headers(self, token):
        return {
            'accept': 'application/json, text/plain, */*',
            'accept-language': 'en-GB,en-US;q=0.9,en;q=0.8',
            'accept-encoding': 'gzip, deflate, br',
            'authorization': f'Token {token}',
            'x-tenant': 'a0000000-b111-c111-d111-e11111111111'
        }

    def _post_headers(self, cookie, token):
        headers = {
            'accept': 'application/json',
            'accept-encoding': 'gzip, deflate, br',
            'accept-language': 'en',
            'content-type': 'application/json',
            'x-tenant': 'a0000000-b111-c111-d111-e11111111111'
        }
        if cookie:
            headers.update(cookie)
        if token:
            headers.update({'authorization': f'Bearer {token}'})
        return headers

    @staticmethod
    def _put_headers(cookie, token):
        headers = {
            'accept': '*/*',
            'accept-encoding': 'gzip, deflate, br',
            'accept-language': 'en',
            'Content-Type': 'application/json',
            'x-tenant': 'a0000000-b111-c111-d111-e11111111111',
            'Connection': 'keep-alive',

        }
        if cookie:
            headers.update(cookie)
        if token:
            headers.update({'authorization': f'Bearer {token}'})
        return headers

    def _get(self, url, token, verify_response_string="", email="", allow_redirects=True):
        """
        Make a GET request to the server.
        Make the response to fail if verification string is not present in the response
        """
        with self.session.get(
                url,
                verify=False,
                headers=self._get_headers(token),
                allow_redirects=allow_redirects
        ) as response:
            if verify_response_string:
                if verify_response_string not in response.text:
                    self._check_response(response, email=email)
                    raise Exception(f'{verify_response_string} does not present in available response text, '
                                    f'code: {response.status_code}, text: {response.text} and email is {email}')
                if response.status_code == 402:
                    raise Exception(f'API request failed with following error code: {str(response.status_code)} '
                                    f'text: {response.text} and user email is {email}')
        return response

    def _get_lti(self, url, token, verify_response_string="", email="", allow_redirects=True):
        """
        Make a GET request to the server.
        Make the response to fail if verification string is not present in the response
        """
        with self.session.get(
                url,
                verify=False,
                headers=self._lti_headers(token),
                allow_redirects=allow_redirects
        ) as response:
            if verify_response_string:
                if verify_response_string not in response.text:
                    self._check_response(response, email=email)
                    raise Exception(f'{verify_response_string} does not present in available response text, '
                                    f'code: {response.status_code}, text: {response.text} and email is {email}')
                if response.status_code == 402:
                    raise Exception(f'API request failed with following error code: {str(response.status_code)} '
                                    f'text: {response.text} and user email is {email}')
        return response

    def _post(self, url, params, cookie, token='', verify_response_string="", email="", allow_redirects=True):
        """
        Make a POST request to the server.
        Skips SSL verification and sends the CSRF cookie.
        """
        with self.session.post(
                url,
                json=params,
                verify=False,
                headers=self._post_headers(cookie, token),
                allow_redirects=allow_redirects
        ) as response:
            if verify_response_string:
                if verify_response_string not in response.text:
                    self._check_response(response, email=email)
                    raise Exception(f'{verify_response_string} does not present in available response text, '
                                    f'code: {response.status_code}, text: {response.text} and email is {email}')
                if response.status_code == 402:
                    raise Exception(f'API request failed with following error code: {str(response.status_code)} '
                                    f'text: {response.text} and user email is {email}')
        return response

    def _post_lti(self, url, params, token='', verify_response_string="", email="", allow_redirects=True):
        """
        Make a POST request to the server.
        """
        with self.session.post(
                url,
                json=params,
                verify=False,
                headers=self._lti_headers(token),
                allow_redirects=allow_redirects
        ) as response:
            if verify_response_string:
                if verify_response_string not in response.text:
                    self._check_response(response, email=email)
                    raise Exception(f'{verify_response_string} does not present in available response text, '
                                    f'code: {response.status_code}, text: {response.text} and email is {email}')
                if response.status_code == 402:
                    raise Exception(f'API request failed with following error code: {str(response.status_code)} '
                                    f'text: {response.text} and user email is {email}')
        return response

    def _put(self, url, params, cookie, token='', verify_response_string="", email="", allow_redirects=True):
        """
        Make a POST request to the server.
        Skips SSL verification and sends the CSRF cookie.
        """
        with self.session.put(
                url,
                json=params,
                verify=False,
                headers=self._put_headers(cookie, token),
                allow_redirects=allow_redirects
        ) as response:
            if verify_response_string:
                if verify_response_string not in response.text:
                    self._check_response(response, email=email)
                    raise Exception(f'{verify_response_string} does not present in available response text, '
                                    f'code: {response.status_code}, text: {response.text} and email is {email}')
                if response.status_code == 402:
                    raise Exception(f'API request failed with following error code: {str(response.status_code)} '
                                    f'text: {response.text} and user email is {email}')
        return response

    def _patch_lti(self, url, params, token='', verify_response_string="", email="", allow_redirects=True):
        """
        Make a POST request to the server.
        Skips SSL verification and sends the CSRF cookie.
        """
        with self.session.patch(
                url,
                json=params,
                verify=False,
                headers=self._lti_headers(token),
                allow_redirects=allow_redirects
        ) as response:
            if verify_response_string:
                if verify_response_string not in response.text:
                    self._check_response(response, email=email)
                    raise Exception(f'{verify_response_string} does not present in available response text, '
                                    f'code: {response.status_code}, text: {response.text} and email is {email}')
                if response.status_code == 402:
                    raise Exception(f'API request failed with following error code: {str(response.status_code)} '
                                    f'text: {response.text} and user email is {email}')
        return response

    def _put_lti(self, url, params, token='', verify_response_string="", email="", allow_redirects=True):
        """
        Make a POST request to the server.
        Skips SSL verification and sends the CSRF cookie.
        """
        with self.session.put(
                url,
                json=params,
                verify=False,
                headers=self._lti_headers(token),
                allow_redirects=allow_redirects
        ) as response:
            if verify_response_string:
                if verify_response_string not in response.text:
                    self._check_response(response, email=email)
                    raise Exception(f'{verify_response_string} does not present in available response text, '
                                    f'code: {response.status_code}, text: {response.text} and email is {email}')
                if response.status_code == 402:
                    raise Exception(f'API request failed with following error code: {str(response.status_code)} '
                                    f'text: {response.text} and user email is {email}')
        return response

    def _delete(self, url, token='', verify_response_string="", email="", allow_redirects=True):
        """
        Make a POST request to the server.
        Skips SSL verification and sends the CSRF cookie.
        """
        with self.session.delete(
                url,
                verify=False,
                headers=self._get_headers(token),
                allow_redirects=allow_redirects
        ) as response:
            if verify_response_string:
                if verify_response_string not in response.text:
                    self._check_response(response, email=email)
                    raise Exception(f'{verify_response_string} does not present in available response text, '
                                    f'code: {response.status_code}, text: {response.text} and email is {email}')
                if response.status_code == 402:
                    raise Exception(f'API request failed with following error code: {str(response.status_code)} '
                                    f'text: {response.text} and user email is {email}')
        return response

    def _delete_lti(self, url, token='', verify_response_string="", email="", allow_redirects=True):
        """
        Make a POST request to the server.
        Skips SSL verification and sends the CSRF cookie.
        """
        with self.session.delete(
                url,
                verify=False,
                headers=self._lti_headers(token),
                allow_redirects=allow_redirects
        ) as response:
            if verify_response_string:
                if verify_response_string not in response.text:
                    self._check_response(response, email=email)
                    raise Exception(f'{verify_response_string} does not present in available response text, '
                                    f'code: {response.status_code}, text: {response.text} and email is {email}')
                if response.status_code == 402:
                    raise Exception(f'API request failed with following error code: {str(response.status_code)} '
                                    f'text: {response.text} and user email is {email}')
        return response

    @staticmethod
    def get_list_of_json_key(list, r_key, c_key='', c_key_value=''):
        """
        This method is used to get the program id's
        based on course type
        """
        list_of_values = []
        if c_key == "" and c_key_value == "":
            for item in list:
                list_of_values.append(item[r_key])
        else:
            for value in list:
                if value[c_key] == c_key_value:
                    list_of_values.append(value[r_key])

        return list_of_values

    def complete_now_process_queue(self, transaction_id, access_token):
        payload = {
            "transaction_id": transaction_id,
            "should_append_config_ids": true_value,
            "should_use_excel_data_for_password_change": true_value,
            "update_name": true_value,
            "update_lang": true_value,
            "wave_id": program_wave_id
        }
        response = self._put(
            f'{ADMIN_BASE_URL}api/v2/automation/course_ops/auto_enrollment/{transaction_id}', payload, cookie='',
            token=access_token
        )
        return response

    def validate_user_uploading_response(self, response, transaction_id, status):
        self.compare_expected_and_actual_result(response, transaction_id_key, transaction_id)
        if not response[status] in ["PROCESSING", "COMPLETED"]:
            raise Exception(FAILED_TO_MATCH_VALUES.format(response[status], "PROCESSING or COMPLETED"))
        return True

    def check_if_pending(self, details, transaction_id, status, access_token):
        if details[status] == "PENDING":
            response = self.complete_now_process_queue(transaction_id, access_token)
            if not STATUS_CODE_GOOD == response.status_code:
                raise Exception(FAILED_TO_MATCH_VALUES.format(STATUS_CODE_GOOD, response.status_code))
            return True
        else:
            return self.validate_user_uploading_response(details, transaction_id, status=transaction_status_key)
