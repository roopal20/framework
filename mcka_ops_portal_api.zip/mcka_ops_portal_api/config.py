import logging
import requests
import random

from .resources import *

SESSION = requests.session()
APP_URL = f'{ADMIN_BASE_URL}'
# ACCESS_TOKEN = " "
TOTAL_ROWS = 'totalRows'
DOCEBO_SUCCESS = 'docebo_success'
CONFIG_ID = 'config_id'
PROGRAM_ID = 'program_id'
DOCEBO = 'docebo'
Log = logging.getLogger()

# Excel Upload Parameters
pre_fix = 'Test'
post_fix = 'MAY22'
course_type = 'elearning'
lp_name = 'Test Automation Program'
lp_desc = 'This is a LP for the KS automation program'
lp_level = 'Landing Page 3'
expert_name = 'mckinsey@example.com'
connected = 'yes'
ch_type = 'custom'
ch_empty = 1
ch_sort = 'date_desc'

# Learning plan upload Error messages###
ERR_MESSAGE_LP_LEVEL_BLANK = "Level must be only one of ['Landing Page 0', 'Landing Page 0 (RTL)'," \
                             " 'Landing Page 1', 'Landing Page 1 (RTL)', 'Landing Page 2a'," \
                             " 'Landing Page 2a (RTL)', 'Landing Page 2b', 'Landing Page 2b (RTL)'," \
                             " 'Landing Page 3', 'Landing Page 3 (RTL)']"
ERR_MESSAGE_BLANK = "Text missing / too short / too long [ allowed limit : 1 - 255 chars ]"
ERR_MESSAGE_ID_MISMATCH = "Config ID does not match with other sheets."
ERR_MULTIPLE_MESSAGE = "Only one value allowed per sheet for this column."
ERR_CHANNEL_SORT_VALUES = "Channel sort must be only one of ['name_asc', 'name_desc', 'date_asc', 'date_desc']"
ERR_CONNECTED_VALUES_ALLOWED = "Connected must be only one of ['yes', 'no']"
ERR_LP_LEVEL_VALUES_ALLOWED = "Level must be only one of ['Landing Page 0', 'Landing Page 0 (RTL)'," \
                              " 'Landing Page 1', 'Landing Page 1 (RTL)', 'Landing Page 2a'," \
                              " 'Landing Page 2a (RTL)', 'Landing Page 2b', 'Landing Page 2b (RTL)'," \
                              " 'Landing Page 3', 'Landing Page 3 (RTL)']"
ERR_COURSE_TYPE_MESSAGE = "Course Type must be only one of ['elearning', 'classroom']"
ERR_LP_DESCRIPTION_BLANK_MESSAGE = "Text missing / too short / too long [ allowed limit : 1 - 1000 chars ]"

# Status Codes List
STATUS_CODE_GOOD = 200
STATUS_CODE_201 = 201
CONFLICT_RESPONSE_STATUS_CODE_409 = 409
INTERNAL_SERVER_500 = 500
STATUS_CODE_401_UNAUTHORIZED = 401
BAD_REQUEST_STATUS_CODE_400 = 400
REQUESTED_PAGE_NOT_FOUND_STATUS_CODE = 404

# Exception Messages
CALLER_TRACE = '{0}::{1} Line:{2}'
FAILED_TO_CLICK_ERROR = 'Failed to click on element - {} - {}'
FAILED_TO_MATCH_VALUES = 'Failed to Match expected  {}, with actual {}'
FAILED_TO_FIND_VALUE_IN_RESPONSE = 'Failed to Find {} in response {}'
UNABLE_TO_LOAD = 'Unable to load {} within given time span'
RESULTS_NOT_FOUND = 'Either value doest not exist or issue with type matching for key: {}'
RESULTS_FOUND = 'value doest exist for key: {}'
RESPONSE_BODY = 'Response Body is empty.'

# Replication Related Constants
unique_config_id = "test_ops_replication"
over_range_config_id = "this_is_for_testing_purpose_only"
empty_config_id = ''
course_types = ["elearning", "classroom"]
channel_name = CHANNEL_NAME
assets_types = ["PDF", "Image", "PowerPoint", "Video"]

# Json Keys
success_key = "success"
limit_exceeded_key = "limit_exceeded"
message_key = "message"
column_key = "column"
unique_key = "unique"
program_id_key = "program_id"
test_users_key = "test_users"
default_experience_key = "default_experience"
experience_key = "experience"
groups_key = "groups"
valid_key = "valid"
name_key = "name"
replicated_key = "replicated"
stage_key = "stage"
data_key = 'data'
count_key = 'count'
errors_key = "errors"
total_key = "total"
failed_key = "failed"
done_key = "done"
passed_key = "passed"
session_key = "id_session"
courses_value_key = 'courses'
session_value_key = 'all_sessions'
course_session_key = "course_sessions"
course_type_key = 'course_type'
course_id_key = 'idCourse'
delete_session_key = "delete_session"
delete_event_key = "delete_event"
instructors_key = "users"
event_key = "events"
delta_key = "delta"
eop_key = "eop"
docebo_url_key = 'docebo_url'
last_refreshed_key = 'last_refreshed'
error_key_key = 'error-key'
error_key = 'error'
errors_key = 'errors'
languages_key = 'languages'
text_key = 'text'
is_published_key = 'is_published'
id_key = 'id'
code_key = 'code'
highest_group_number_key = 'highest_group_number'
lowest_group_number_key = 'lowest_group_number'
assignments_key = 'assignments'
assignment_name_key = 'assignment_name'
total_rows_key = 'total_rows'
successful_rows_key = 'successful_rows'
failed_rows_key = 'failed_rows'
created_at_key = 'created_at'
filename_key = 'filename'
new_users_key = 'new_users'
existing_users_key = 'existing_users'
logged_in_key = 'logged_in'
never_logged_in_key = 'never_logged_in'
inactive_users_key = 'inactive_users'
user_key = 'user'
password_key = 'password'
language_key = 'language'
branch_key = 'branch'
in_progress_key = 'in_progress'
wave_id_key = 'wave_id'
wave_name_key = 'wave_name'
ec_code_key = 'ec_code'
experience_type_key = 'experience_type'
user_count_key = 'user_count'

# json values to compare
raw_message = "similar ID already exists"
message = "{0} {1}"
success_message = "SUCCESS"
failed_status = 'FAILED'
out_of_range = "Config id length must be in range"
no_config_id = "The requested URL was not found on the server. If you entered the URL manually please check your " \
               "spelling and try again."
false_value = False
true_value = True
invalid_value = "INVALID"
valid_value = "VALID"
default_experience_value = "Landing Page 0"
landing_page_value = "Landing Page 3"
platform_value = 'https://mckinseysandbox.docebosaas.com/login'
stage_value = "STAGE_REPLICATED"
enrolled_users_value_zero = 0
participant_users_value_zero = 0
error_message = "Usernames should be distinct"
username_value = "username"
course_type_list = ["classroom", "elearning"]
event_name_text = 'abcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyza' \
    'bcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzab' \
    'cdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyz"'

docebo_lms_url = DOCEBO_LMS_URL
content_management_lp_id = CONTENT_MANAGEMENT_LP_ID
content_management_lp_code = CONTENT_MANAGEMENT_LP_CODE
content_management_copy_course_id = CONTENT_MANAGEMENT_COPY_COURSE_ID
update_content_management_course = UPDATE_CONTENT_MANAGEMENT_COURSE
refresh_content_payload = {"update": True, "content_management": True}
validation_passed = {'success': True, 'message': 'validation Passed'}
copy_component_payload = {"lp_config_id": f"{content_management_lp_code}", "new_component_title": "Copy of_Course ILT"}
copy_component_success_message = \
    'A copy of {} component shell was successfully created and linked to this Learning Plan'
component_code_already_exists_message = 'Component code already exists. Please enter a new Component code.'
existing_component_name = {"new_component_code": f"Copy of_ILT01 - {content_management_lp_code}"}
lengthy_copy_component_code = {"new_component_code": f"Copy of_ILT0123456789101234567892321321342134213432343234213123123 - {content_management_lp_code}"}
# incorrect_copy_componente_code = {"new_component_code": f"Copy of_ILT01 - {content_management_lp_code}"}
copy_component_code_without_lp = {"new_component_code": "Copy of_ILT01 -"}
incorrect_copy_component_message = 'Copy of_ILT01 - does not include Learning Plan Config id. Please try again.'
lengthy_copy_component_message = 'Copy of_ILT01 - does not include Learning Plan Config id. Please try again.'
completed_message = 'COMPLETED'
pending_message = 'PENDING'
validation_passed_message = 'validation Passed'
course_not_found = 'Course id not found'

course_code_text = 'course_code'
program_update_payload = {
    "additional_fields": [{"id": "14", "key": "Portfolio", "slug": "portfolio", "value": "Digital and Analytics (DnA)"}
                          ],
    "code": f"Copy of_ILT010467 - {content_management_lp_code}",
    "credits": "0.00",
    "description": "Join this optional webinar to review the course goals, expectations, and syllabus.",
    "eop": "",
    "id": update_content_management_course,
    "is_published": 0,
    "lang_label": "English",
    "name": "Copy of_Course ILT"
}
courses_languages = {
    "ar": {
        "code": "arabic",
        "description": "Arabic",
        "browsercode": "ar",
        "is_rtl": True,
        "description_translated": "Arabic"
    },
    "nl": {
        "code": "dutch",
        "description": "Dutch",
        "browsercode": "nl",
        "is_rtl": False,
        "description_translated": "Dutch"
    },
    "en": {
        "code": "english",
        "description": "English",
        "browsercode": "en",
        "is_rtl": False,
        "description_translated": "English"
    },
    "fr": {
        "code": "french",
        "description": "French",
        "browsercode": "fr",
        "is_rtl": False,
        "description_translated": "French"
    },
    "de": {
        "code": "german",
        "description": "German",
        "browsercode": "de",
        "is_rtl": False,
        "description_translated": "German"
    },
    "ja": {
        "code": "japanese",
        "description": "Japanese",
        "browsercode": "ja",
        "is_rtl": False,
        "description_translated": "Japanese"
    },
    "ko": {
        "code": "korean",
        "description": "Korean",
        "browsercode": "ko",
        "is_rtl": False,
        "description_translated": "Korean"
    },
    "pl": {
        "code": "polish",
        "description": "Polish",
        "browsercode": "pl",
        "is_rtl": False,
        "description_translated": "Polish"
    },
    "pt-br": {
        "code": "portuguese-br",
        "description": "Portuguese BR",
        "browsercode": "pt-br",
        "is_rtl": False,
        "description_translated": "Portuguese BR"
    },
    "ru": {
        "code": "russian",
        "description": "Russian",
        "browsercode": "ru",
        "is_rtl": False,
        "description_translated": "Russian"
    },
    "zh": {
        "code": "simplified_chinese",
        "description": "Simplified Chinese",
        "browsercode": "zh",
        "is_rtl": False,
        "description_translated": "Simplified Chinese"
    },
    "es-419": {
        "code": "spanish_latam",
        "description": "Spanish LATAM",
        "browsercode": "es-419",
        "is_rtl": False,
        "description_translated": "Spanish LATAM"
    },
    "th": {
        "code": "thai",
        "description": "Thai",
        "browsercode": "th",
        "is_rtl": False,
        "description_translated": "Thai"
    },
    "vi": {
        "code": "vietnamese",
        "description": "Vietnamese",
        "browsercode": "vi",
        "is_rtl": False,
        "description_translated": "Vietnamese"
    }
}

# test user management
en_lang = 'English'
delete_user_message = 'test user deleted successfully'

# Wave cohort
users_wave_id = USERS_WAVE_ID
target_ec_code = TARGET_EC_CODE
wave_email_id = WAVE_EMAIL_ID
program_wave_id = PROGRAM_WAVE_ID
user_count = USER_COUNT

create_wave_cohort_success_message = 'Enrollment wave added successfully'
create_wave_cohort_fail_message = 'Enrollment wave already exists'
edit_wave_cohort_success_message = 'Wave updated successfully'
delete_wave_cohort_success_message = 'Wave deleted successfully'

validate_wave_cohort_fail_message_1 = 'Missing transfer cohort users sheet(s)'
validate_wave_cohort_fail_message_2 = 'Unrecognized sheet abc'
validate_wave_cohort_fail_message_3 = 'All sheets are empty.'

# Replicated Program
rep_config_id = REP_CONFIG_ID
parent_id_keys = ["is_project_id_valid", "project_id_status", "original_project_id_status"]
parent_id_values = values = [true_value, valid_value, valid_value]

# program having 31 channels
lp_config_id_of_31_courses = LP_CONFIG_ID_OF_31_COURSES

# program having 181 traning materials and less than 30 courses
lp_config_id_with_181_components = LP_CONFIG_ID_WITH_181_COMPONENTS

# program having 11 traning materials in one course
lp_config_id_with_11_training_materials_inside_a_course = LP_CONFIG_ID_WITH_11_TMS

# Program having channel
config_id_value = session_key

# Channel content info
assets_ids = ASSETS_IDS
assets_types_ids = ASSETS_TYPES_IDS
assets_types_info = ASSETS_TYPES_INFO

config_id = CONFIG_ID_NO
channel_id = CHANNEL_ID
lp_config_id = LP_CONFIG_ID
source_channel_name = CHANNEL_NAME
channel_id_value = CHANNEL_ID_VALUE
program_id = PROGRAM_ID_NO
program_id_sync_users = PROGRAM_ID_SYNC_USERS
project_id_keys = ["is_project_id_valid", "project_id_status", "original_project_id_status"]
project_id_values = [false_value, invalid_value, invalid_value]
program_with_empty_session = PROGRAM_WITH_EMPTY_SESSION
sync_user_failed_program_id = SYNC_USER_FAILED_PROGRAM_ID
sync_user_failed_course_id = SYNC_USER_FAILED_COURSE_ID
enrolled_session_program_id = ENROLLED_SESSION_PROGRAM_ID
wave_id = WAVE_ID
enrolled_session_program_name = ENROLLED_SESSION_PROGRAM_NAME

# Program having no channel
program_with_no_channel = PROGRAM_WITH_NO_CHANNEL
config_id_without_channel = CONFIG_ID_WITHOUT_CHANNEL
lp_config_id_without_channel = LP_CONFIG_ID_WITHOUT_CHANNEL

# already replicated program
program_id_already_rep = PROGRAM_ID_ALREADY_REP
config_id_alr_rep = CONFIG_ID_ALREADY_REP
lp_config_id_alr_rep = LP_CONFIG_ID_ALREADY_REP

# groupwork groups
new_group_work = NEW_GROUP_WORK
move_user_lp = MOVE_USER_LP
file_text = 'file'
move_user_error_message = 'Selected group already has 15 members in some assignments. Please make sure selected group' \
                          ' has less than 15 members in all assignments'
group_assignment_name = 'submit::Test_Automation_Assignment[GW]'

# Program with No Course
lp_config_id_no_course = LP_CONFIG_ID_NO_COURSE
invalid_project_id = "test"
valid_project_id = SCORM_RELEASE_ID
project_id_api = "/elucidat/validate_project_id/"
rep_base_url = f'{ADMIN_BASE_URL}replication/'
channel_api = f'{ADMIN_BASE_URL}api/overview/content/channel/'
scorm_api = "/scorms"
api_keyword = "dat/unique_config_id/"
report_api = f'{ADMIN_BASE_URL}api/report/program/'
programs = f'{ADMIN_BASE_URL}api/program/course_prod?search=&page=0&stage='
new_project_id = SCORM_RELEASE_ID
old_program_api = f'{ADMIN_BASE_URL}api/dat/unique_config_id/'

# Modification
is_imported_from_docebo_key = 'is_imported_from_docebo'
new_config_id_key = 'new_config_id'
transaction_id_key = 'transaction_id'
transaction_status_key = 'transaction_status'
status_key = 'status'
update_key = 'update'
enrolled_users_key = 'enrolled_users'
participant_users_key = 'participant_users'
mod_base_url = f'{ADMIN_BASE_URL}api/'
edit_program = f'{ADMIN_BASE_URL}api/dat/course_prod/edit_program_code'
edit_program_final = f'{ADMIN_BASE_URL}api/automation/course_prod/edit_program_code'

# User Management
client_value = 'R10'
pass_value = 'OneAcademy!1'
message_value = "File validation successful"
existing_user = "ntst_user2aeb@mailinator.com"
empty_user_message = "No data found in sheet."
invalid_sheet_message = "Unrecognized sheet invalid"
sheet_name = 'bulk unenroll'
file_validation_message = 'File validation successful'
invalid_sheet = "Unrecognized sheet invalid"

# json values to compare
modify_program_error_message = 'The program with this name already exists. Please search the home page with this Config' \
                               ' ID to make any updates to this program.'

# Assignment Management
assignment_name = 'submit::Test_Automation_Assignment[GW]'
error_download_new_assignmnet = 'No new assignments to download, please click on Refresh and try again'
error_no_rows_message = 'No rows found for evaluation update (all rows are already evaluated)'
error_invalid_grade_value = 'Value must be a number or empty'
error_different_grade_status = "Different grade status found for single groupwork"
error_missing_instructor_name = 'Instructor Username is missing'
error_invalid_grade_status = 'Grade Status must be passed or failed for rows to be evaluated'
error_decimal_value = 'Grade value should not be in decimal'
error_no_grades_modification = 'No grades found for modification'
instructor_username = 'khurram_shahzad@external.mckinsey.com'
grade_status = 'passed'
metadata_file = 'metadata.xlsx'
validate_metadata_file = 'validate_metadata.xlsx'
grade_value = 85

# workshop management
wm_base_api = 'api/lp/course_ops/workshop_management/'

# get_course_id_wm_endpoint = f'{ADMIN_BASE_URL}{wm_base_api}1296'
get_course_id_wm_endpoint = f'{ADMIN_BASE_URL}{wm_base_api}{program_id_sync_users}'
new_session_endpoint = f'{ADMIN_BASE_URL}{wm_base_api}course/'
# count_session_endpoint = f'{ADMIN_BASE_URL}{wm_base_api}1296/course_details/'
count_session_endpoint = f'{ADMIN_BASE_URL}{wm_base_api}{program_id_sync_users}/course_details/'
program_id_url = f'{ADMIN_BASE_URL}{wm_base_api}{program_id}'
no_session_endpoint = f'{ADMIN_BASE_URL}{wm_base_api}{program_with_empty_session}'
session_endpoint = f'{ADMIN_BASE_URL}{wm_base_api}session/'
get_venues_endpoint = f'{ADMIN_BASE_URL}api/dat/workshop_management/venues'
create_event_endpoint = f'{ADMIN_BASE_URL}api/lp/course_ops/workshop_management/session/'
update_session_endpoint = f'{ADMIN_BASE_URL}api/lp/course_ops/workshop_management/session/'
update_event_endpoint = f'{ADMIN_BASE_URL}api/lp/course_ops/workshop_management/event/'
instructor_endpoint = f'{ADMIN_BASE_URL}/api/workshop_management/search/instructors'
# sync_user_endpoint = f'{ADMIN_BASE_URL}api/workshop_management/sync_users/1296'
# create_user_endpoint = f'{ADMIN_BASE_URL}api/automation/course_prod/test_users_creation/1296'
# delete_user_endpoint = f'{ADMIN_BASE_URL}api/automation/course_prod/test_users_creation/'
sync_user_endpoint = f'{ADMIN_BASE_URL}api/workshop_management/sync_users/{program_id_sync_users}'
sync_user_failed_endpoint = f'{ADMIN_BASE_URL}api/workshop_management/sync_users/{sync_user_failed_program_id}'
create_user_endpoint = f'{ADMIN_BASE_URL}api/automation/course_prod/test_users_creation/{program_id_sync_users}'
delete_user_endpoint = f'{ADMIN_BASE_URL}api/automation/course_prod/test_users_creation/'
# count_session_endpoint_sync_user = f'{ADMIN_BASE_URL}api/lp/course_ops/workshop_management/3762/course_details/'
count_session_endpoint_sync_user = f'{ADMIN_BASE_URL}api/lp/course_ops/workshop_management/{program_id_sync_users}/course_details/'
# get_course_of_id_sync_lp = f'{ADMIN_BASE_URL}api/lp/course_ops/workshop_management/3762'
get_course_of_id_sync_lp = f'{ADMIN_BASE_URL}api/lp/course_ops/workshop_management/{program_id_sync_users}'
webinar_management_endpoint = \
    f'{ADMIN_BASE_URL}api/automation/course_ops/webinar_management/{sync_user_failed_program_id}'
get_course_of_id_sync_lp_failed_endpoint = f'{ADMIN_BASE_URL}api/lp/course_ops/workshop_management/{sync_user_failed_program_id}'
count_session_endpoint_sync_user_failed = \
    f'{ADMIN_BASE_URL}api/lp/course_ops/workshop_management/{sync_user_failed_program_id}/course_details/'
progress_api_endpoint = f'{ADMIN_BASE_URL}/api/progress/'
get_course_of_id_sync_lp_enrollment = f'{ADMIN_BASE_URL}api/lp/course_ops/workshop_management/{enrolled_session_program_id}'
count_session_endpoint_sync_user_enrollment = f'{ADMIN_BASE_URL}api/lp/course_ops/workshop_management/{enrolled_session_program_id}/course_details/'
sync_user_enrollment = f'{ADMIN_BASE_URL}api/workshop_management/sync_users/{enrolled_session_program_id}'
manage_users_file_url = f'{ADMIN_BASE_URL}api/dat/validate/course_ops/webinar_management'

# content management endpoints
view_component_endpoint = f'{ADMIN_BASE_URL}api/content_management/course/{content_management_copy_course_id}'
updated_component_endpoint = f'{ADMIN_BASE_URL}api/content_management/course/'
refresh_content_endpoint = \
    f'{ADMIN_BASE_URL}api/overview/components/{content_management_lp_id}?update=true&content_management=true'
cm_languages_endpoint = f'{ADMIN_BASE_URL}api/service/active_languages'
validate_copy_component_endpoint = \
    f'{ADMIN_BASE_URL}api/content_management/course/clone/lp/{content_management_lp_id}/validate'
update_component_code = f'{ADMIN_BASE_URL}api/content_management/course/update/{content_management_copy_course_id}'
update_eop_tag_endpoint = f'{ADMIN_BASE_URL}api/overview/component/program_id/{content_management_lp_id}/course_id/' \
    f'{update_content_management_course}/update'
incorrect_update_eop_tag_endpoint = f'{ADMIN_BASE_URL}api/overview/component/program_id/{content_management_lp_id}' \
                                    f'/course_id/123/update'
check_component_eop_endpoint = f'{ADMIN_BASE_URL}api/content_management/course/{update_content_management_course}'
cm_copy_component_endpoint = f'{ADMIN_BASE_URL}/api/content_management/course/clone' \
                             f'/{content_management_copy_course_id}/lp/{content_management_lp_id}'
update_program = f'{ADMIN_BASE_URL}api/content_management/course/update/{update_content_management_course}'

# group work
without_assignment_and_groups_endpoint = \
    f'{ADMIN_BASE_URL}api/dat/course_ops/groupwork_groups/{content_management_lp_id}'
new_groups_endpoint = \
    f'{ADMIN_BASE_URL}api/dat/course_ops/groupwork_groups/{sync_user_failed_program_id}'
without_groups_and_with_assignment_endpoint = f'{ADMIN_BASE_URL}api/dat/course_ops/groupwork_groups/4078'
with_groups_and_assignment_endpoint = f'{ADMIN_BASE_URL}api/dat/course_ops/groupwork_groups/{program_id}'

# workshop management session types
session_types = ["Manual", "Attendance based"]
event_types = ["Video", "Venue"]
venues_names = VENUS_LOCATION
message_value_event = "Error while processing the requested operation"
message_value_session = "Required params are missing."
create_user_lp_ids = ["3795"]

# LTI Journals
lti_token_url = f'{ADMIN_BASE_URL}api/lti/journal/token'
existing_lti_url = f'{LTI_BASE_URL}api/learning-plans/?page=1&search='
lti_lp_config_url = f'{ADMIN_BASE_URL}api/overview/content/lp/{enrolled_session_program_name}'
lti_docebo_lp_id = DOCEBO_LP_ID_LTI
lti_program_name = LTI_PROGRAM_NAME
lti_journal_title = f"{LTI_PROGRAM_NAME}_JO"
lti_invalid_message = 'There is an issue connecting with Docebo'
lti_program_not_found = 'Program ID not found'
lti_program_name_key = 'program_name'
lti_docebo_lp_id_key = 'docebo_lp_id'
lti_num_components_key = 'num_components'
lti_details_key = 'details'
lti_config_id_key = 'config_id'
lti_has_more_key = 'hasMore'
lti_rows_key = 'totalRows'
lti_lp_id_key = 'learning_plan_id'
lti_lp_id = LTI_LP_ID
existing_docebo_lti_lp_id = EXISTING_DOCEBO_LTI_LP_ID
lti_duplicate_error = 'This learning plan already contains a journal. Please select a different learning plan or edit the existing journal in this learning plan'
